AntiSpam 
 by Zoxc

AntiSpam is a plugin which removes the messages from all the annoying spam bots.
It utilizes lord2800's Bayesian filtering code to do this. It will also remove
the join and leave messages for the bots.

Due to the way it works, joined messages for players are delayed by 8 seconds and
initial messages are delayed by 3 seconds.

Microsoft Visual C++ 2010 Redistributable Package is required to use this.

You can find the source for this at: https://github.com/Zoxc/AntiSpam

- Enjoy spam free playing