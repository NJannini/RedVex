#pragma once
#include <windows.h>
#include <string>
#include "IModule.h"
#include "IPacket.h"
#include "IProxy.h"
#include ".\\Utilities\\PacketDefs.h"
#include ".\\Utilities\\xmlParser.h"
#include ".\\Utilities\\Automate.h"

using namespace std;

#pragma warning (disable:4996) // typesafe string manipulation warnings

class EnterChat :
	public IModule,
	public XMLNode
{
public:
	EnterChat();
	~EnterChat();
	EnterChat(IProxy* proxy,ModuleKind kind);
	void __stdcall Destroy();
	void _stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void _stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void _stdcall Update();
	
	static EnterChat* BNCS;
	static EnterChat* Data;

	static bool bBNCSConnected;
	static bool bBNCSAuthPassed;
	static bool bEnterChat;
	static bool bSendClick;
	static bool bGoHome;
	static bool bInChat;
	static int nEnterDelay;

	static HWND hD2Wnd;
	static HANDLE hEnterChat;

	static string sXMLFile;
	static string sXMLSection;
	static string sTitle;
	static string sChannel;
	
	// XMLNode Structs
	XMLNode xMainNode;
	XMLNode xData;	
	XMLNode xProfile;
	XMLNode xOption;

	enum DATA_ACTIONS {
		CREATE,
		LOAD,
		UPDATE,
	};

	void mBox(char* szMsg,char *szTitle);
	bool InitXML(char* szFile,char*szSection);
	bool DataHandler(int nAction);
	bool Str2Bool(const char* szBool);
	int Str2Int(const char* szInt);
	void Reset();
	
	Automate* _auto;

private:
	IProxy* _proxy;
	ModuleKind _kind;
};
