#include "EnterChat.h"

EnterChat* EnterChat::BNCS;
EnterChat* EnterChat::Data;

bool EnterChat::bBNCSConnected = false;
bool EnterChat::bBNCSAuthPassed = false;
bool EnterChat::bEnterChat = false;
bool EnterChat::bSendClick = false;
bool EnterChat::bGoHome = false;
bool EnterChat::bInChat = false;

int EnterChat::nEnterDelay = NULL;

HWND EnterChat::hD2Wnd;
HANDLE EnterChat::hEnterChat;

string EnterChat::sXMLFile;
string EnterChat::sXMLSection;
string EnterChat::sTitle;
string EnterChat::sChannel;

DWORD WINAPI EnterChatThread(LPVOID lpParameter)
{
	while(true)
	{
		if( EnterChat::bSendClick == true )
		{
			// Delay before clicking enter chat
			if(EnterChat::nEnterDelay <= 500)
			{
				Sleep( 500 );
			} else {
				Sleep( EnterChat::nEnterDelay );
			}
			if( EnterChat::bBNCSConnected == true && EnterChat::bInChat == true )
			{
				EnterChat::bGoHome = true;
				EnterChat::Data->_auto->SendClick( EnterChat::sTitle.c_str(), EnterChat::Data->_auto->LEFT_CLICK, 90, 470 );
				EnterChat::bSendClick = false;
				TerminateThread( EnterChat::hEnterChat, 0 );
				CloseHandle( EnterChat::hEnterChat );
				Sleep(50);
				return 0;
			} else {
				EnterChat::bSendClick = false;
				TerminateThread( EnterChat::hEnterChat, 0 );
				CloseHandle( EnterChat::hEnterChat );
				Sleep(50);
				return 0;
			}
		} else {
			EnterChat::bSendClick = false;
			TerminateThread( EnterChat::hEnterChat, 0 );
			CloseHandle( EnterChat::hEnterChat );
			Sleep(50);
			return 0;
		}
	}
	Sleep(50);
	return 0;
}

EnterChat::EnterChat()
{
	// Empty
}

EnterChat::~EnterChat()
{
	// Empty
}

EnterChat::EnterChat(IProxy* proxy,ModuleKind kind) :
	_proxy(proxy),
	_kind(kind)
{
	switch( _kind )
	{
		case ChatModule:
		{
			EnterChat::bBNCSConnected = true;
			EnterChat::Data->InitXML("EnterChat.xml","Default");
		}
		break;
	}
}

void __stdcall EnterChat::Destroy()
{
	if( EnterChat::BNCS == this )
	{
		EnterChat::bBNCSConnected = false;
		EnterChat::bBNCSAuthPassed = false;
	}
	delete this;
}

void EnterChat::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>( packet->GetData() );
	UINT iPacket;
	if( GameModule == _kind )
	{
		iPacket = bytes[0];
	}
	if( ChatModule == _kind )
	{
		iPacket = bytes[1];
	
		// 0x10
		if( iPacket == SID_LEAVECHAT )
		{
			// left chat
			EnterChat::bInChat = false;
			EnterChat::bSendClick = false;
			EnterChat::bGoHome = false;
		}

		// 0x0c
		if(iPacket == SID_JOINCHANNEL)
		{
			// D2's First Join
			if(bytes[4] == 0x05 && EnterChat::bGoHome == true)
			{
				/*
				0x00: NoCreate join 
				0x01: First join 
				0x02: Forced join
				0x05: D2 first join
				*/
				int iChanLen = (int)EnterChat::sChannel.length();
				iChanLen++;
				
				char* szChannel = new char[iChanLen];
				sprintf( szChannel, "%s", EnterChat::sChannel.c_str() );

				int iLen = packet->GetSize();
				iLen = iLen - 10;
				iLen = iLen + iChanLen;

				unsigned char* buffer = new unsigned char[iLen];

				int offset = 0;
				
				buffer[offset++] = 0xff;
				buffer[offset++] = 0x0c;
				buffer[offset++] = 0x00 + iLen;
				buffer[offset++] = 0x00;
				buffer[offset++] = 0x02;
				buffer[offset++] = 0x00;
				buffer[offset++] = 0x00;
				buffer[offset++] = 0x00;

				for (int i = 0; szChannel[i] != '\0'; i++)
				{
						buffer[offset++] = szChannel[i];
				}

				buffer[offset++] = 0x00;

				// Rewrite the packet
				packet->SetData( buffer, iLen);
				EnterChat::bGoHome = false;
				delete[] buffer;
			}
		}

	}
	if( RealmModule == _kind )
	{
		iPacket = bytes[2];
	}
}

void EnterChat::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>( packet->GetData() );
	UINT iPacket;
	if( GameModule == _kind )
	{
		iPacket = bytes[0];
	}
	if( ChatModule == _kind )
	{
		iPacket = bytes[1];

		// 0x0A
		if( iPacket == SID_ENTERCHAT )
		{
			// in chat
			EnterChat::bInChat = true;
		}

		// 0x46
		if( iPacket == SID_NEWS_INFO )
		{
			if( EnterChat::bEnterChat == true )
			{
				EnterChat::bSendClick = true;
				EnterChat::hEnterChat = CreateThread( 0, 0, EnterChatThread, 0, 0, 0 );
			}
		}

		// 0x51
		if( iPacket == SID_AUTH_CHECK )
		{
			unsigned long dwResult =  *(unsigned long *)( bytes + 4 );
			switch( dwResult )
			{
				// 0x0000
				case AUTH_PASSED:
				{
					// success let's continue forward
					EnterChat::bBNCSAuthPassed = true;
					EnterChat::Data->InitXML("EnterChat.xml","Default");
				}
				break;

				// Anything but success
				default:
				{
					// problem turn things off
					EnterChat::bBNCSAuthPassed = false;
				}
				break;
			}
		}
	}
	if( RealmModule == _kind )
	{
		iPacket = bytes[2];
	}
}

void EnterChat::Update()
{
	// Empty
}

void EnterChat::mBox(char* szMsg,char *szTitle)
{
	::MessageBoxA(NULL,szMsg, szTitle,MB_OK);
}

bool EnterChat::InitXML(char* szFile,char*szSection)
{
	bool bReturn = false;
	Reset();

	EnterChat::sXMLFile.assign(szFile);
	EnterChat::sXMLSection.assign(szSection);

	while( EnterChat::Data->DataHandler( LOAD ) != true )
	{
		EnterChat::Data->DataHandler( CREATE );
	}
	return bReturn;
}

bool EnterChat::DataHandler(int nAction)
{
	bool bReturn = false;
	switch( nAction )
	{
		case CREATE:
		{
			EnterChat::Data->xMainNode = EnterChat::Data->openFileHelper( EnterChat::sXMLFile.c_str() );
			EnterChat::Data->xData = EnterChat::Data->xMainNode.addChild( "xData" );
			EnterChat::Data->xData.addAttribute( "version", "1.0" );
			EnterChat::Data->xData.addAttribute( "load", EnterChat::sXMLSection.c_str() );
			EnterChat::Data->xProfile = EnterChat::Data->xData.addChild( EnterChat::sXMLSection.c_str() );
			EnterChat::Data->xProfile.addAttribute( "title", "Diablo II" );
			EnterChat::Data->xOption = EnterChat::Data->xProfile.addChild( "EnterChat" );
			EnterChat::Data->xOption.addAttribute( "value", "true" );
			EnterChat::Data->xOption.addAttribute( "delay", "1000" );
			EnterChat::Data->xOption.addAttribute( "channel", "Bounty Hunters" );
			EnterChat::Data->xMainNode.writeToFile( EnterChat::sXMLFile.c_str() );
			bReturn = true;
		}
		break;
		case LOAD:
		{
			EnterChat::Data->xMainNode = EnterChat::Data->openFileHelper( EnterChat::sXMLFile.c_str() );
			int nCount = EnterChat::Data->xMainNode.nChildNode();
			if( nCount <= 0 )
			{
				bReturn = false;
			} else {
				EnterChat::Data->xMainNode = EnterChat::Data->openFileHelper( EnterChat::sXMLFile.c_str() );
				EnterChat::Data->xData = EnterChat::Data->xMainNode.getChildNode( "xData" );
				EnterChat::Data->xProfile = EnterChat::Data->xData.getChildNode( EnterChat::Data->xData.getAttribute( "load" ) );
				EnterChat::sXMLSection.assign( EnterChat::Data->xProfile.getName() );

				// Set the window title
				EnterChat::sTitle.assign( EnterChat::Data->xProfile.getAttribute( "title" ) );

				EnterChat::Data->xOption = EnterChat::Data->xProfile.getChildNode( "EnterChat" );	

				// Set the enterchat value
				EnterChat::bEnterChat = Str2Bool( EnterChat::Data->xOption.getAttribute( "value" ) );

				// Set the enterchat delay
				EnterChat::nEnterDelay = Str2Int( EnterChat::Data->xOption.getAttribute( "delay" ) );

				// Set the channel string
				EnterChat::sChannel.assign( const_cast<char*>( EnterChat::Data->xOption.getAttribute( "channel" ) ) );
				bReturn = true;
			}
		}
		break;
		case UPDATE:
		{
			bReturn = false;
		}
		break;
	}
	return bReturn;
}


bool EnterChat::Str2Bool(const char* szBool)
{
	if( ( stricmp( szBool, "1" ) == 0 ) || ( stricmp( szBool, "true" ) == 0 ) || ( stricmp( szBool, "yes" ) == 0 ) )
	{
		return true;;
	} else {
		return false;
	}
}

int EnterChat::Str2Int(const char* szInt)
{
	int nReturn;
	if( isdigit( atoi( szInt ) ) )
	{
		nReturn = atoi( szInt );
	} else {
		nReturn = 500;
	}
	return nReturn;
}

void EnterChat::Reset()
{
	EnterChat::bEnterChat = false;
	EnterChat::bSendClick = false;
	EnterChat::bGoHome = false;
	EnterChat::bInChat = false;

	EnterChat::nEnterDelay = NULL;

	EnterChat::sXMLFile.clear();
	EnterChat::sXMLSection.clear();
	EnterChat::sTitle.clear();
	EnterChat::sChannel.clear();
}