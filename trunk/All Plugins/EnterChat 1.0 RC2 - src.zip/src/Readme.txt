Title: EnterChat 1.0 (RC2)
Author: Leo-X
Released:11/09/2007
Updated: 11/12/2007

Instructions:
1) Drop EnterChat.dll into your plugins directory
2) Next load and start redvex then run Diablo II and click the button to login, this will generate an xml file named EnterChat.xml in your redvex folder.
2) Shutdown and close redvex and close diablo II.
3) Open up and edit EnterChat.xml
4) If the EnterChat.xml file cannot be found unload all other plugins and run EnterChat by itself once so that it can generate the xml file correctly.

EnterChat.xml Explanation:
1) Ignore and leave this alone: <?xml version="1.0" encoding="ISO-8859-1"?>
2) The "load" string in the line <xData version="1.0" load="Default"> tells the plugin what profile section to get and use.
- so if that line said load="Default" it would look for <Default> and load it and all data within <Default>
*Note: Make sure if you open a tag such as <Default> that you also close it </Default>
3) The Section names should be a name that corrisponds to the Account name you wish to logon to.
4) Everything else should be pretty self explanitory if it is not let me know, basically just change the channel name and set value to true;
5) Again as with all automated plugins we need to know what title your D2 client will be using so please make sure that is filled in correctly.

Notes:
98.0% Done
1% = need to check stability and find any bugs.
1% = add the extra commands, to load a new profile and set a new home channel

Example EnterChat.xml file:
<?xml version="1.0" encoding="ISO-8859-1"?>
<xData version="1.0" load="Default">
	<Default title="Diablo II">
		<EnterChat value="true" delay="500" channel="Diablo II"/>
	</Default>
</xData>

[Changlog]
11/17/2007
~ Minor update to fix bug related to plugin locking up if d2 was not run before redvex/plugins.
~ Several other minor adjustments to mirror changes made to the Autologon plugin
* If this seems to be stable from now on I will start adding commands soon.

11/14/2007
+ Added a hardcoded minimum delay of 200 if you try to use a value less then 200 it will default to 200.
+ Added a mousemove method prior to sending clicks.
~ Cleaned up the Automation class.
~ Cleaned up the thread that sends the click to enterchat a little.

11/12/2007
~ Tested on 2 pc's the 100% cpu bug cannot be replicated by me anymore, if anyone experiences this please let me know(it should be fixed).
+ Added the delay value to the xml file, it is in ms meaning 1000 = 1 second also note that any number works here and anything else other then a number will default it to 500(about half a second).
- Cleaned up code removed unused realm/game related plugin statics.
* Moved revision forward to RC2.

11/09/2007
~ Bug fix

11/09/2007
+ Initial release date.

Changelog Guide: 
+ addition.
- removal.
~ update.
* note.
