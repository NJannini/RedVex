/*
+	Title: Automate class
+	Author: LordVader
+	Updated: 11/05/2007
*/
#pragma once
#include <windows.h>
#include <winable.h>

//#pragma warning (disable:4996) // typesafe string manipulation warnings
#pragma warning (disable:4018) // signed/unsigned mismatch warnings

class Automate
{
public:
	enum MOUSE_ACTION {
		LEFT_CLICK,
		MIDDLE_CLICK,
		RIGHT_CLICK,
		DOUBLE_LCLICK,
		DOUBLE_MCLICK,
		DOUBLE_RCLICK,
	};
	inline HWND Window(const char* szTitle);
	inline void Block(const char* szTitle,bool bState);
	inline void SendClick(const char* szTitle, int nSide, int X, int Y);
	inline void SendInput(const char* szTitle, char szKey[]);
	inline void SendKey(const char* szTitle, UINT vKey);
private:
protected:
};

HWND Automate::Window(const char* szTitle)
{
	HWND hReturn;
	hReturn = FindWindowA( 0, szTitle );
	return hReturn;
}

void Automate::Block(const char *szTitle,bool bState)
{
	HWND hWnd = Window(szTitle);
	SendMessageA(hWnd,BlockInput(bState),0,0);
}

void Automate::SendClick(const char *szTitle,int nSide, int X, int Y)
{
	HWND hWnd = Window(szTitle);
	LPARAM Pos = MAKELPARAM(X, Y);
	SendMessage( hWnd, WM_MOUSEMOVE, 0, Pos );
	Sleep(50);
	switch(nSide)
	{
		case LEFT_CLICK:
		{
			SendMessage( hWnd, WM_LBUTTONDOWN, MK_LBUTTON, Pos );
			SendMessage( hWnd, WM_LBUTTONUP, MK_LBUTTON, Pos );
			Sleep(50);
		}
		break;
		case MIDDLE_CLICK:
		{
			SendMessage( hWnd, WM_MBUTTONDOWN, MK_MBUTTON, Pos );
			SendMessage( hWnd, WM_MBUTTONUP, MK_MBUTTON, Pos );
			Sleep(50);
		}
		break;
		case RIGHT_CLICK:
		{
			SendMessage( hWnd, WM_RBUTTONDOWN, MK_RBUTTON, Pos );
			SendMessage( hWnd, WM_RBUTTONUP, MK_RBUTTON, Pos );
			Sleep(50);
		}
		break;
		case DOUBLE_LCLICK:
		{
			SendMessage( hWnd, WM_LBUTTONDOWN, MK_LBUTTON, Pos );
			SendMessage( hWnd, WM_LBUTTONUP, MK_LBUTTON, Pos );
			Sleep(50);
			SendMessage( hWnd, WM_LBUTTONDOWN, MK_LBUTTON, Pos );
			SendMessage( hWnd, WM_LBUTTONUP, MK_LBUTTON, Pos );
			Sleep(50);
		}
		break;
		case DOUBLE_MCLICK:
		{
			SendMessage( hWnd, WM_MBUTTONDOWN, MK_MBUTTON, Pos );
			SendMessage( hWnd, WM_MBUTTONUP, MK_MBUTTON, Pos );
			Sleep(50);
			SendMessage( hWnd, WM_MBUTTONDOWN, MK_MBUTTON, Pos );
			SendMessage( hWnd, WM_MBUTTONUP, MK_MBUTTON, Pos );
			Sleep(50);
		}
		break;
		case DOUBLE_RCLICK:
		{
			SendMessage( hWnd, WM_RBUTTONDOWN, MK_RBUTTON, Pos );
			SendMessage( hWnd, WM_RBUTTONUP, MK_RBUTTON, Pos );
			Sleep(50);
			SendMessage( hWnd, WM_RBUTTONDOWN, MK_RBUTTON, Pos );
			SendMessage( hWnd, WM_RBUTTONUP, MK_RBUTTON, Pos );
			Sleep(50);
		}
		break;
	}
}

void Automate::SendInput(const char* szTitle,char szKey[])
{
	HWND hWnd = Window(szTitle);
    for(int i = 0 ; i < strlen( szKey ) ; i++)
    {
		if( isupper( szKey[i] ) ) // If is uppercase.
        {
			SendMessage( hWnd, WM_KEYDOWN, VK_SHIFT, 0 );
			Sleep(50);
			SendMessage( hWnd, WM_CHAR, (WPARAM)szKey[i], 0 ); 
			Sleep(50);
			SendMessage( hWnd, WM_KEYUP, VK_SHIFT, 0 );
			Sleep(50);
		} else {
			SendMessage( hWnd,WM_CHAR,(WPARAM)szKey[i], 0 );
			Sleep(50);
		}
    }
}

void Automate::SendKey(const char* szTitle, UINT vKey)
{
	HWND hWnd = Window(szTitle);
	SendMessage( hWnd, WM_KEYDOWN, vKey, 0 );
	SendMessage( hWnd, WM_KEYUP, vKey, 0 );
	Sleep(50);
}