#include <windows.h>
#include "EnterChat.h"
#include "PluginTypes.h"
#include "IModule.h"

PluginInfo Info;
bool bLoaded;

int __stdcall DllMain(HINSTANCE instance, int reason, void* reserved)
{
	if(bLoaded != true)
	{
		EnterChat::Data = new EnterChat();
		bLoaded = true;
	}
	return 1;
}

void __stdcall FreePlugin(PluginInfo* Info)
{
   //Cleanup Stuff
}

IModule* __stdcall CreateModule(IProxy* proxy, ModuleKind kind)
{
	switch(kind)
	{
		case ChatModule: 
		{ 
			EnterChat::BNCS = new EnterChat(proxy,kind);
			return EnterChat::BNCS; 
		} 
		break;
	}

	return 0;
}


extern "C"
{
	__declspec(dllexport) PluginInfo* __stdcall InitPlugin(RedVexInfo* Funcs)
	{ 
		Info.Name = "EnterChat v1.0 RC2";
		Info.Author = "Leo-X";
		Info.SDKVersion = 3;
		Info.Destroy = (DestroyPlugin)&FreePlugin;
		Info.Create = &CreateModule;
		return &Info;
	}
}