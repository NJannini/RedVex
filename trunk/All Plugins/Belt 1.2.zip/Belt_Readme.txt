Belt.dll

A potion drinker / chicken plugin for RedVex by Turlok!

This plugin can automatically drink potions for you and your merc.
This plugin can automatically TP and go to town on low life.
This plugin can automatically exit the game on low life.
This plugin can block flash attacks.
This plugin removes the built-in delay for taking TPs.
This plugin detects server latency and warns you.

************************************************************

Installing Belt.dll:
Step 1: Put Belt.dll into your Plugins folder
Step 2: Put Belt.ini into your RedVex folder
Step 3: Edit and save Belt.ini
Step 4: Update RedVex
Step 5: High-Five! Your done!

************************************************************

in-game commands:

Commands
--------------
.belt	-> displays your current count of all Potion types and TPs
.town	-> toggles auto-town for this game
.exit	-> toggles auto-exit for this game
.block	-> toggles flash protection (if no one is flashing you, it's best to leave this off)
