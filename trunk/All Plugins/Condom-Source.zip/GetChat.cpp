#include "Condom.h"
#include "Ipacket.h"
#include "Iproxy.h"
#include <cctype>

/* This function will detect what you typed and process it */
bool Condom::GetChat(const char* playerName, char* accountName, short status, bool shithead, const char* text,int playerID)
{
	char name[48];
	char output[4138];
	char reference[16];

	//spam filter

	char referenceText[4138];

	bool filter=false;
	int length=int(strlen(text));
	for(int x=0;x<length;x++)
		referenceText[x]=toupper(text[x]);
	for (std::list<Account>::iterator a = _filterList.begin(); a != _filterList.end(); a++){
		if(!filter){
			char*x=strstr(referenceText,a->accountName);
			if(x!=NULL){
				filter=true;
				strcpy_s(referenceText,sizeof(referenceText),a->accountName);
			}
		}
	}

	//end spam filter

	const char*statusMark;
	if(strcmp(playerName,_hero.name))
		switch(status){
			case 0: statusMark="�c9"; break;
			case 1: statusMark="�c2"; break;
			case 2: statusMark="�c1"; break;
		}
	else
		statusMark="�c4";
	if(accountName[0]!='\0'){
		for(int x=0;x<16;x++)
			reference[x]=toupper(accountName[x]);
		if(strcmp(reference,"TURLOK")==0){
			if(shithead)
				sprintf(name,"%s%s (�c8%s%s) �c;[PK]�c0: ",statusMark,playerName,accountName,statusMark);
			else
				sprintf(name,"%s%s (�c8%s%s)�c0: ",statusMark,playerName,accountName,statusMark);
		}
		else{
			if(shithead)
				sprintf(name,"%s%s (%s) �c;[PK]�c0: ",statusMark,playerName,accountName);
			else
				sprintf(name,"%s%s (%s)�c0: ",statusMark,playerName,accountName);
		}
	}
	else{
		if(shithead)
			sprintf(name,"%s%s �c;[PK]�c0: ",statusMark,playerName);
		else
			sprintf(name,"%s%s�c0: ",statusMark,playerName);
	}
	sprintf(output,"%s%s",name,text);
	if(!filter || playerID==_hero.id || !_spamFilter)
		Chat("",false,output);
	else{
		squelch(playerID);
		Chat(_chatName,false,"�c9%s has been squelched by the spam filter (�c8%s�c9)",playerName,referenceText);
	}
	return true;
}