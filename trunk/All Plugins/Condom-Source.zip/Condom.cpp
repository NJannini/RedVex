#include "Condom.h"
#include "IProxy.h"
#include "IPacket.h"
#include <windows.h>
#include <shlwapi.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#pragma comment(lib, "Shlwapi.lib")
#include "Item.h"
#include "ItemReader.h"
#include "BitField.h"
using namespace std;

Condom::Condom(IProxy* proxy) :
	_state(ChickenState_InTown),
	_life(1),
	_safeLife(1),
	_maxLife(1),
	_baseMaxLife(1),
	_lifePercent(100),
	_mana(1),
	_maxMana(1),
	_manaPercent(1),
	_mercLife(100),
	_quantity(0),
	_inStash(0),
	_justClosed(0),
	_dontSpam(0),
	_hasBO(0),
	_hasOak(0),
	_hasWolf(0),
	_hasBear(0),
	_blueEmpty(0),
	_purpleEmpty(0),
	_redEmpty(0),
	_joined(0),
	_blockFlash(0),
	_exit(0),
	lastLeave(0),
	lastDrink(0),
	lastMerc(0),
	statusPulse(0),
	_targetStage(0),
	_joinCount(0),
	lastChicken(0),
	_teleSelect(0),
	_lastFlash(0),
	_proxy(proxy)
{
	//lets do this here instead
			strcpy(_currentTargetName,"NULL");
			_currentTarget=9;
			_joinCount=0;
			_town.id = 0; // Reset our home town
			_life=1;
			_maxLife=1;
			_safeLife=1;
			_baseMaxLife=1;
			_lifePercent=100;
			_mana=1;
			_maxMana=1;
			_manaPercent=100;
			_bonusOff=1;
			_mercLife=100;
			_quantity=0;
			_inStash=0;
			_justClosed=0;
			_dontSpam=0;
			_hasBO=0;
			_hasOak=0;
			_hasWolf=0;
			_hasBear=0;
			_dirtyFix=1; // Quit/w BO Bnet Failure Fix
			_flashing=0; //multiplier for flash delays
	//kk
	char path[MAX_PATH];
   GetCurrentDirectory(sizeof(path), path);
   strcat_s(path, "/Condom.ini");
   _chickenTown = GetPrivateProfileInt("Chicken", "ChickenTown", 0, path);
   _chickenExit = GetPrivateProfileInt("Chicken", "ChickenExit", 0, path);
   _chickenPing = GetPrivateProfileInt("Chicken", "ChickenPing", 0, path);
   _chickenMerc = GetPrivateProfileInt("Chicken", "ChickenMerc", 0, path);
   _townIron = GetPrivateProfileInt("Chicken", "TownOnIronMaiden", 0, path);
   _townMercIron = GetPrivateProfileInt("Chicken", "TownOnMercIronMaiden", 0, path);
   _townHostile = GetPrivateProfileInt("Chicken", "TownOnHostile", 3000, path);
   _townDirect = GetPrivateProfileInt("Chicken", "TownOnDirectAttack", 0, path);
   _townCoord = GetPrivateProfileInt("Chicken", "TownOnCOORDAttack", 0, path);
   _TPPK = GetPrivateProfileInt("Other", "TPPKMode", 0, path);
   _blockFlash = GetPrivateProfileInt("Other", "FlashProtection", 0, path);
   _drinker = GetPrivateProfileInt("Potions", "AutoPot", 0, path);
   _parseText = GetPrivateProfileInt("Messages", "ParseText", 0, path);
   _parseGame = GetPrivateProfileInt("Messages", "ParseGame", 0, path);
   _bossTalk = GetPrivateProfileInt("Messages", "BossTalk", 0, path);
   _pecho = GetPrivateProfileInt("Messages", "PotionEchoes", 0, path);
   _secho = GetPrivateProfileInt("Messages", "StatusEchoes", 0, path);
   _wecho = GetPrivateProfileInt("Messages", "WarningEchoes", 0, path);
   _lecho = GetPrivateProfileInt("Messages", "LevelEchoes", 0, path);
   _cHide = GetPrivateProfileInt("Other", "HideCorpses", 0, path);
   _shit = GetPrivateProfileInt("Other", "ListPKs", 0, path);
   _aParty = GetPrivateProfileInt("Other", "AutoParty", 0, path);
   _displayStatus = GetPrivateProfileInt("Messages", "DisplayStatus", 0, path);
   _spamFilter = GetPrivateProfileInt("Messages", "SpamFilter", 0, path);
   drink_delay = GetPrivateProfileInt("Potions", "DrinkDelay", 3000, path);
   _chickenHealth = GetPrivateProfileInt("Chicken", "ChickenLife", 60, path);
   _exitHealth = GetPrivateProfileInt("Chicken", "ExitLife", 50, path);
   _exitMerc = GetPrivateProfileInt("Chicken", "ExitMerc", 10000, path);
   _exitPing = GetPrivateProfileInt("Chicken", "ExitPing", 10, path);
   _lifepot = GetPrivateProfileInt("Potions", "PotLife", 80, path);
   _manapot = GetPrivateProfileInt("Potions", "PotMana", 20, path);
   _juvepot = GetPrivateProfileInt("Potions", "RejuveLife", 70, path);
   merc_life = GetPrivateProfileInt("Potions", "MercPotLife", 80, path);
   merc_juve = GetPrivateProfileInt("Potions", "MercRejuveLife", 30, path);
//end read settings
	_hero.id = 0;
	_hero.name[0] = '\0';
	_hero.level = 0;
	_hero.inTown = true;
	_chatName = "�c4Condom";
	for(int x=0;x<8;x++)
		_targets[x]=0;
	getShitList();
	getShitListP();
	getFilter();
}

void __stdcall Condom::Destroy()
{
	delete this;
}
/*Condom::~Condom()
{

}*/

void Condom::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>(packet->GetData());
	int packetId = bytes[0];
	switch (packetId)
	{
	/*case 0x3C://selecting a skillz
		{
			short skillId = *reinterpret_cast<const short*>(bytes + 1);
			if(skillId==54)
			{
				//Chat(_chatName,false,"TeleportSelected!");
				_selectTeleport=true;
			}
			else
			{
				//Chat(_chatName,false,"Something NOT Teleport Selected!");
				_selectTeleport=false;
			}
		}
	break;*/
	/*case 0x0f://sending right-click
		{
			if(_teleSelect)
			{
				packet->SetFlag(IPacket::PacketFlag_Dead);
				short x = *reinterpret_cast<const short*>(bytes + 1);
				short y = *reinterpret_cast<const short*>(bytes + 3);
				teleTarg(x,y);
				teleCast(x,y);
				teleTarg(x,y);
				teleCast(x,y);
				teleTarg(x,y);
				teleCast(x,y);
				teleTarg(x,y);
				teleCast(x,y);
				//Resynch();
			}
		}
		break;*/
	case 0x59: //Get Id
		{
			const char* playerName = reinterpret_cast<const char*>(bytes + 6);
			int playerId = *reinterpret_cast<const int*>(bytes + 1);
			if(!strcmp(_hero.name,playerName)){
				_hero.id=playerId;
				for(int x=0;x<8;x++){
					if(_targets[x]==playerId){
						_currentTarget=x;
						x=9;
					}
				}
			}
		}
		break;
	case 0x21: // Skill Updates
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 3);
			int skillId = bytes[7];
			short skillbase = *reinterpret_cast<const short*>(bytes + 8);
			short skillbonus = *reinterpret_cast<const short*>(bytes + 10);
			int skillLvl = skillbase+skillbonus;
			Skill thisSkill;
			strcpy(thisSkill.name,convertAttack(skillId));
			thisSkill.type=typeAttack(skillId);
			thisSkill.level=skillLvl;
			thisSkill.base=skillbase;
			thisSkill.bonus=skillbonus;
			thisSkill.owner=playerId;
			_skillPool.push_back(thisSkill);
			Chat(_chatName,false,"Detected a Skill");
		}
	case 0x5D: //changing relations
		{
			int request = bytes[1];
			int action = bytes[2];
			int Id = *reinterpret_cast<const int*>(bytes + 3);
			int party=65535;
			if(request == 0x04)
				if(action == 0x01)
				{
					for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
						if(Id==i->id)
						{
							//i->status=2;
							i->isHostile=true;
							party=i->party;
							break;
						}
					for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
						if(i->party==party && party!=65535 && party!=-1)
						{
							//i->status=2;
							i->isHostile=true;
							break;
						}
				}
		}
		break;
	/*case 0x5E: //party requests
		{
			int request = bytes[1];
			int Id = *reinterpret_cast<const int*>(bytes + 2);
			int party=65535;
			if(request == 0x08)
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					if(Id==i->id)
					{
						i->status=1;
						party=i->party;
						break;
					}
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					if(i->party==party && party!=65535 && party!=-1)
					{
						i->status=1;
						break;
					}
			}
			if(request == 0x09)
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					if(i->status==1)
						i->status=0;
				_hero.party=65535;
			}
		}
		break;*/
	case 0x15: //sending text
		{
			const char* text = reinterpret_cast<const char*>(bytes + 3);
			if (OnChat(text))
			{
				packet->SetFlag(IPacket::PacketFlag_Virtual);
			}
		}
	break;
	case 0x4f://closing object
		{
			short Id = *reinterpret_cast<const int*>(bytes + 1);
			if(bytes[1]==0x02 && _viewing)
				 packet->SetFlag(IPacket::PacketFlag_Virtual);
			if(Id==18)//close stash
			{
				_inStash=false;
				_justClosed=true;
				_dontSpam=true;
				//Chat(_chatName,false,"stash is now closed");
			}
			if(Id==23)//close cube
			{
				_inStash=false;
				_justClosed=true;
				_dontSpam=true;
			}
		}
		break;
	/*case 0x69://you are leaving the game
		{
			//Chat("",false,"Read 0x69");
			strcpy(_currentTargetName,"NULL");
			_currentTarget=0;
			_joinCount=0;
			_town.id = 0; // Reset our home town
			clearPots();
			//Chat("",false,"Cleared Pots");
			_life=1;
			_maxLife=1;
			_baseMaxLife=1;
			_lifePercent=100;
			_mana=1;
			_maxMana=1;
			_manaPercent=1;
			_mercLife=100;
			_quantity=0;
			_inStash=0;
			_justClosed=0;
			_dontSpam=0;
			_hasBO=0;
			_hasOak=0;
			_hasWolf=0;
			_hasBear=0;
		}
		break;*/
	case 0x68:
		{
			// store off the player's name for future reference
			const char* playerName = reinterpret_cast<const char*>(bytes + 21);
			strcpy_s(_hero.name, sizeof(_hero.name), playerName);
		}
		break;
	case 0x1D://swap body item
		{
			//player has swapped equipment, reset life max...
			_maxLife=_baseMaxLife;
			_safeLife=_baseMaxLife;
			_safeMana=_mana;
			_maxMana=_mana;
		}
		break;
	case 0x1C://remove body item
		{
			//player has removed equipment, reset life max...
			_maxLife=_baseMaxLife;
			_safeLife=_baseMaxLife;
			_safeMana=_mana;
			_maxMana=_mana;
		}
		break;
	case 0x03://player run
		{
			short playerX = *reinterpret_cast<const short*>(bytes + 1);
			short playerY = *reinterpret_cast<const short*>(bytes + 3);
			_hero.xPos=playerX;
			_hero.yPos=playerY;
			//Chat(_chatName, false, "�c1Hero at �c8(%u,%u)",_hero.xPos,_hero.yPos);
		}
		break;
	case 0x01://player walk
		{
			short playerX = *reinterpret_cast<const short*>(bytes + 1);
			short playerY = *reinterpret_cast<const short*>(bytes + 3);
			_hero.xPos=playerX;
			_hero.yPos=playerY;
			//Chat(_chatName, false, "�c1Hero at �c8(%u,%u)",_hero.xPos,_hero.yPos);
		}
		break;
	case 0x3f:
		{
			int soundId = *reinterpret_cast<const short*>(bytes + 1);
			switch(soundId)	
			{
			case 0x1e: //numpad 5 'bye' -> fast tp and hostile
				{
					if(_TPPK){
					_state = ChickenState_OpeningTp;
					_hostile = true;
					CastTp();
					}
				}
				break;
			case 0x20: //numpad 7 'retreat' -> fast tp without hostile
				{
					_state = ChickenState_OpeningTp;
					_hostile = false;
					CastTp();
				}
				break;
			case 0x19: //numpad 0 'help' -> open tp
				{
					_state = ChickenState_Ready;
					_hostile = false;
					CastTp();
				}
				break;
			case 0x1a: //numpad 1 'follow me' -> change target
				{
					if(_TPPK && !_players.empty()){
						packet->SetFlag(IPacket::PacketFlag_Virtual);
						char tclass[12];
						int tlvl;
						strcpy(_currentTargetName,"NULL");
						if(_currentTarget<8)
							removeMark(_targets[_currentTarget]);
						_currentTarget++;
						if(_currentTarget>=8)
							_currentTarget=0;
						for(int x=_currentTarget;x<=8;x++){
							if(_targets[x]){
								_currentTarget=x;
								x=9;
							}else if(x>=8)
								x=-1;
						}
						for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
							if(i->id==_targets[_currentTarget]){
								if(i->id!=_hero.id){
									tlvl = i->level;
									strcpy(tclass,i->type);
									_targetParty=i->party;
									strcpy(_currentTargetName,i->name);
									markPlayer(i->id);
									Chat(_chatName,false,"�c1Targeting �c8%s �c1[�c9Level �c8%u �c9%s�c1]", _currentTargetName,tlvl,tclass);
								}
								else
									Chat(_chatName,false,"�c1Target �c8OFF");
							}
					}
				}
				break;
			case 0x1f: //numpad 6 'die' -> Left-Attack
				{
					if(_TPPK){
						short tX,tY;
						bool vis=false;
						packet->SetFlag(IPacket::PacketFlag_Virtual);
						if(_currentTarget<8){
							for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
							{
								if (i->id == _targets[_currentTarget])//Find Target's location
								{
									tX=i->xPos;
									tY=i->yPos;
									vis=i->visible;
								}
							}
						}
						if(vis){
							UseLeftSkillOnLocation(tX,tY);
							Chat(_chatName, false, "�c1Left-Attacking �c8%s", _currentTargetName);
						}
						else
							Chat(_chatName, false, "�c8%s �c1is out of range", _currentTargetName);
					}
				}
			break;
			case 0x1b: //numpad 5 'this is for you' -> Right-Attack
				{
					if(_TPPK){
						short tX,tY;
						bool vis=false;
						packet->SetFlag(IPacket::PacketFlag_Virtual);
						if(_currentTarget<8){
							for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
							{
								if (i->id == _targets[_currentTarget])//Find Target's location
								{
									tX=i->xPos;
									tY=i->yPos;
									vis=i->visible;
								}
							}
						}
						if(vis){
							UseRightSkillOnLocation(tX,tY);
							Chat(_chatName, false, "�c1Right-Attacking �c8%s", _currentTargetName);
						}
						else
							Chat(_chatName, false, "�c8%s �c1is out of range", _currentTargetName);
					}
				}
			break;
			}
		}
		break;
	}
}

void Condom::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	_newPing=GetTickCount();
	//Chat(_chatName,false,"Ping: %u",_ping-_lastPing);
	_ping=_newPing-_lastPing;
	_lastPing=_newPing;
	const unsigned char* bytes = static_cast<const unsigned char*>(packet->GetData());
	int packetId = bytes[0];

	switch (packetId)
	{
		case 0x0A: //Player Lost Sight
		{
			if(bytes[1]==0x00)//this is a player
			{
				int playerId = *reinterpret_cast<const int*>(bytes + 2);
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
				{
					if(playerId==i->id)
						i->visible=false;
				}
			}
		}
		break;
		case 0x5C: //Player Leave Game
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 1);
			for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
			{
				if(playerId == i->id && i->here)
				{
					i->here=false;
					i->visible=false;
					Player LeftGame;
					LeftGame.id=playerId;
					LeftGame.shithead=i->shithead;
					strcpy(LeftGame.type,i->type);
					LeftGame.level=i->level;
					strcpy_s(LeftGame.name,sizeof(LeftGame.name),i->name);
					if(strcmp(i->account,"\0"))
						strcpy(LeftGame.account,i->account);
					else
						strcpy(LeftGame.account,"?");
					_Leave.push_back(LeftGame);
					lastLeave=GetTickCount();
					//Chat("",false,"Made it through 'Player Leave 0x5c'");
				}
			}
		}
	break;
		case 0x75: //About Player
		{
			int Id=*reinterpret_cast<const int*>(bytes + 1);
			short level=*reinterpret_cast<const short*>(bytes + 7);
			short partyId = *reinterpret_cast<const short*>(bytes + 5);
			short relations = *reinterpret_cast<const short*>(bytes + 9);
			short inParty = *reinterpret_cast<const short*>(bytes + 11);
			if(Id==_hero.id)
			{
				if(partyId!=_hero.party){ _hero.party=partyId;}
			}
			for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
			{
				if(p->id==Id)
				{
					if(relations>=0x08){ p->isHostile=true; }else{ p->isHostile=false;}
					if(partyId!=p->party){ p->party=partyId;}
					if(p->level<level)
					{
						p->level++;
						if(_lecho)
						{
							if(strcmp(p->name,_hero.name))
							{
								if(p->level<9)
									Chat(_chatName,false,"�c8%s �c:has reached level �c8%u",p->name,p->level);
								else
									Chat(_chatName,false,"�c8%s �c1has reached level �c8%u",p->name,p->level);
							}
							else
								Chat(_chatName,false,"�c:You have reached level �c8%u",p->level);
						}
					}
				}
			}
		}
		break;
		case 0x76: //Player In View
			{
				int Id=*reinterpret_cast<const int*>(bytes + 2);
				if(bytes[1]==0x00)
				{
					if(_currentTarget<8){
						if(Id==_targets[_currentTarget] && Id!=_hero.id)
							markPlayer(Id);
					}
				}
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(Id==p->id)
						p->visible=true;
				}
			}
			break;
		case 0x8B: //Party status
			{
				int playerId = *reinterpret_cast<const int*>(bytes + 1);
				int status = bytes[5];
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(p->id==playerId && p->shithead==false)
					{
						switch(status){
						case 0x00: 
							{
								if(_aParty)
									partyInvite(playerId); 
								break;
							}
						case 0x01: /*nothing*/break;
						case 0x02:
							{
								if(_aParty)
									partyAccept(playerId);
								break;
							}
						}
					}
				}
			}
		break;
		/*case 0x7F://party info update
			{
				int Id = *reinterpret_cast<const int*>(bytes + 4);
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
					if(p->id==Id)
						p->status=1;
			}
			break;*/
		case 0x60://teleport info
			{
				int state = bytes[1];
				int areaId = bytes[2];
				int Id = *reinterpret_cast<const int*>(bytes + 3);
				if(state==0x05)
				{
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					spoofTP(0x00,areaId,Id);
				}
				if(state==0x07)
				{
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					spoofTP(0x03,areaId,Id);
				}
			}
			break;
		case 0xAC://npc add
			{
				if(bytes[11]==0 && _cHide)//deadmonster
					packet->SetFlag(IPacket::PacketFlag_Virtual);
			}
			break;
		case 0x69://npcmode
			{
				if(bytes[5]==0x08 && _cHide)
				{
					int Id=*reinterpret_cast<const int*>(bytes + 1);
					freeze(Id);
				}
				if(bytes[5]==0x09 && _cHide)
				{
					int Id=*reinterpret_cast<const int*>(bytes + 1);
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					unfreeze(Id);
				}
			}
			break;
		case 0x07://MapAdd
		{
			short readX = *reinterpret_cast<const short*>(bytes + 1) * 5;
			short readY = *reinterpret_cast<const short*>(bytes + 3) * 5;
			short readID = bytes[5]; // 109 = Harrogoth, 103 = Pandemonium, 75 = Kurast, 40 = Lut, 1 = Rogue
			if (readID == 109 || readID == 103 || readID == 75 || readID == 40 || readID == 1) { // If it is not one of these, we are not even close to town.
				if (readID != _town.id) { // If our previous stored town is not the current one, update the values (should receive several rapidly).
					_town.id = readID;
					_town.minX = readX;
					_town.minY = readY;
					_town.maxX = readX;
					//Chat(_chatName, false, "�c8MapAdd New Town: �c#%u / %u �c8in �c9%u", readX, readY, readID);
					_town.maxY = readY;
				} else { // Same town as before, make sure values are consistent.
					if (readX < _town.minX) {
						_town.minX = readX;
						//Chat(_chatName, false, "�c8MapAdd Lower X: �c#%u / %u �c8in �c9%u", readX, readY, readID);
					}
					if (readX > _town.maxX) {
						_town.maxX = readX;
						//Chat(_chatName, false, "�c8MapAdd Higher X: �c#%u / %u �c8in �c9%u", readX, readY, readID);
					}
					if (readY < _town.minY) {
						_town.minY = readY;
						//Chat(_chatName, false, "�c8MapAdd Lower Y: �c#%u / %u �c8in �c9%u", readX, readY, readID);
					}
					if (readY > _town.maxY) {
						_town.maxY = readY;
						//Chat(_chatName, false, "�c8MapAdd Higher Y: �c#%u / %u �c8in �c9%u", readX, readY, readID);
					}
				}
				// Now, let's double-check to make sure where we are.
				/*if (_hero.xPos >= _town.minX && _hero.xPos <= _town.maxX && _hero.yPos >= _town.minY && _hero.yPos <= _town.maxY) {
					_hero.inTown = true;
					Chat(_chatName, false, "�c#Now in town.",_hero.xPos,_hero.yPos);
				} else {
					_hero.inTown = false;
					Chat(_chatName, false, "�c1Not in town.",_hero.xPos,_hero.yPos);
				}*/
			}
		}
		break;
	case 0x78: //Accepted Trade
		{
			//Chat(_chatName,false,"In trade screen, clearing pots");
			_inStash=true;
			/*for (int x=0;x<16;x++)//clear the potions, dorkus malorkus!
			{
				BeltItems[x].pot=Error;
				BeltItems[x].id=0;
			}*/
		}
		break;
	case 0x26: //Player Talking
		{
			if(_parseText){
				const char* playerName;
				int charNameOffset;
				const char*text;
				char message[4138];
				char upMessage[4138];
				const char*fmessage;
				char accountName[16];
				short status=0;
				bool shithead=false;
				bool squelched=false;
				int playerID=0;
				if(bytes[1]==0x01)//general
				{
					playerName = reinterpret_cast<const char*>(bytes + 10);
					charNameOffset = int(strlen((char*)playerName))+11;
					text = reinterpret_cast<const char*>(bytes + charNameOffset);
					strcpy(message,text);
					for(int x=0;x<int(strlen(message));x++)
					{
						upMessage[x]=toupper(message[x]);
						if(message[x]=='%')
							message[x]='p';
					}
					fmessage=message;
					for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
					{
						if(strcmp(playerName,p->name)==0)
						{
							if(!strcmp(upMessage,p->lastSpoken))
								p->spoken++;
							else
								p->spoken=0;
							if(p->spoken>=4 && p->id!=_hero.id && _spamFilter){
								squelched=true;
								Chat(_chatName,false,"�c9%s has been squelched by the spam filter (�c8SPAMMING�c9)",playerName);
								squelch(p->id);
							}
							strcpy(p->lastSpoken,upMessage);
							strcpy(accountName,p->account);
							status=p->status;
							shithead=p->shithead;
							playerID=p->id;
							break;
						}
					}
					if(!squelched){
						if (GetChat(playerName,accountName,status,shithead,fmessage,playerID))
						{
							packet->SetFlag(IPacket::PacketFlag_Virtual);
						}
					}
					else
						packet->SetFlag(IPacket::PacketFlag_Virtual);
					shithead=false;
				}
			}
		}
	break;
	case 0x77://open object
		{
			if(bytes[1]==0x0c && _viewing)
				packet->SetFlag(IPacket::PacketFlag_Virtual);
			if(bytes[1]==1)//player wants to trade
			{
				_inStash=true;
			}
			if(bytes[1]==21)//open cube
			{
				_inStash=true;
			}
			if(bytes[1]==16)//open stash
			{
				_inStash=true;
				//Chat(_chatName,false,"Stash is now open");
			}
			if(bytes[1]==13)//complete trade
			{
				_inStash=false;
				_justClosed=true;
				_viewing=false;
			}
			if(bytes[1]==12)//refuse trade
			{
				_inStash=false;
				_justClosed=true;
				_viewing=false;
				/*
				for (int x=0;x<16;x++)//clear the potions, dorkus malorkus!
				{
					BeltItems[x].pot=Error;
					BeltItems[x].id=0;
				}*/
			}
			if(bytes[1]==6)//unaccept trade
			{
				/*for (int x=0;x<16;x++)//clear the potions, dorkus malorkus!
				{
					BeltItems[x].pot=Error;
					BeltItems[x].id=0;
				}*/
			}
			if(bytes[1]==5)//trade accepted
			{
				_inStash=false;
				_justClosed=true;
				_viewing=false;
				//_dontSpam=true;
			}
		}
		break;
	case 0x96:
		{
			unsigned char* buffer = new unsigned char[packet->GetSize()];
			memcpy(buffer, packet->GetData(), packet->GetSize());
			void* data = reinterpret_cast<void*>(buffer);
			BitField field(data, sizeof(data));
			WORD xPos = (WORD)(*(DWORD*)(&bytes[2])>>7);
			WORD yPos = (WORD)(*(DWORD*)(&bytes[4])>>7);
			_hero.xPos=xPos;
			_hero.yPos=yPos;
			//Chat(_chatName,false,"Arriving at %u,%u",xPos,yPos);
			if (_hero.xPos >= _town.minX && _hero.xPos <= _town.maxX && _hero.yPos >= _town.minY && _hero.yPos <= _town.maxY) {
				if(!_hero.inTown)
				{
					_hero.inTown = true;
					if(_secho)
						Chat(_chatName, false, "�c:Now inside Town.",_hero.xPos,_hero.yPos);
				}
			} else {
				if(_hero.inTown)
				{
					_hero.inTown = false;
					if(_secho)
						Chat(_chatName, false, "�c1Outside of Town.",_hero.xPos,_hero.yPos);
				}
			}
			delete[] buffer;
		}
		break;
	case 0x9c:
		{
			unsigned char* buffer = new unsigned char[packet->GetSize()];
			memcpy(buffer, packet->GetData(), packet->GetSize());
			item thisItem = ItemReader::ItemReader().Read(buffer);
			delete[] buffer;
			//Chat(_chatName,false,"Item Action: %u , Item Destination: %u , Item Container: %u , Item String: %s",thisItem.Action, thisItem.Destination, thisItem.Container, thisItem.BaseItem.c_str());
			if (_stricmp(thisItem.BaseItem.c_str(), "tbk") == 0)
			{
				//Chat(_chatName, false, "Item destination: %i, Item container: %i", thisItem.Destination, thisItem.Container);
				if (thisItem.Action == PutInContainer && thisItem.Destination == Unspecified && thisItem.Container == Inventory)
				{
					TownPortalBook = thisItem;
				}
			}
			if(thisItem.Action == PutInContainer || thisItem.Action == PutInBelt){ //Add Inventory Items
				if(strcmp(thisItem.BaseItem.c_str(), "tsc") == 0)
					(thisItem.Action == PutInContainer) ? invAdd(thisItem.Id,tpScroll,false) : invAdd(thisItem.Id,tpScroll,true);
				if(_strnicmp(thisItem.BaseItem.c_str(), "mp", 2) == 0)
					(thisItem.Action == PutInContainer) ? invAdd(thisItem.Id,mPot,false) : invAdd(thisItem.Id,mPot,true);
				if(_strnicmp(thisItem.BaseItem.c_str(), "hp", 2) == 0)
					(thisItem.Action == PutInContainer) ? invAdd(thisItem.Id,hPot,false) : invAdd(thisItem.Id,hPot,true);
				if(_strnicmp(thisItem.BaseItem.c_str(), "rv", 2) == 0)
					(thisItem.Action == PutInContainer) ? invAdd(thisItem.Id,jPot,false) : invAdd(thisItem.Id,jPot,true);
			}
			if(thisItem.Action == RemoveFromContainer || thisItem.Action == RemoveFromBelt || thisItem.Action == DropToGround || (thisItem.Container!=0 && thisItem.Container!=2)) //Remove Inventory Items
				invRem(thisItem.Id);
		}
		break;
	case 0x5a: // Player Updates
		{
			bool pker=false;
			bool foundName=false;
			bool foundAccount=false;
			int action = bytes[1];
			int playerId = *reinterpret_cast<const int*>(bytes+3);
			const char* playerName = reinterpret_cast<const char*>(bytes + 8);
			const char* accountName = reinterpret_cast<const char*>(bytes + 24);
			char aRef[16];
			char nRef[16];
			int playerLevel;
			char type[16];
			for(int x=0;x<16;x++)
				aRef[x]=tolower(accountName[x]);
			for(int x=0;x<16;x++)
				nRef[x]=tolower(playerName[x]);
			if(action==0x00 || action==0x02 || action==0x03)//only when joining/leaving do we assign accountNames or shitlist
			{
				//check players against list && PKs
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(!strcmp(playerName,p->name))//found player on list
					{
						playerLevel=p->level;
						strcpy_s(p->account,sizeof(p->account),accountName);
						strcpy_s(p->aRef,sizeof(p->aRef),aRef);
						strcpy_s(p->nRef,sizeof(p->nRef),nRef);
						strcpy_s(type,sizeof(type),p->type);
						for (std::list<Account>::iterator a = _shitList.begin(); a != _shitList.end(); a++)//check account against shitlist
						{
							//Chat("",false,"Checking %s against List:%s",p->aRef,a->accountName);
							if(!strcmp(p->aRef,a->accountName))
							{
								p->shithead=true;
								pker=true;
								foundAccount=true;
							}
						}
						for (std::list<Account>::iterator b = _shitListP.begin(); b != _shitListP.end(); b++)//check name against shitlist
						{
							if(!strcmp(p->name,b->accountName))
							{
								p->shithead=true;
								pker=true;
								foundName=true;
							}
						}
						if(pker)//this is definatly a pk!
						{
							if(!foundAccount)//his account isnt marked though?!
								shitAdd(accountName);//mark his account on list as well
							if(!foundName)//his name isnt marked though?!
								shitAddP(playerName);//mark his name on list as well
						}
					}
				}
			}
			//now onto actions
			if (action == 0x02) //Player Joined
			{
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)//get hero's account name
				{
					if(strcmp(playerName,p->name)==0)
					{
						strcpy(p->account,accountName);
						strcpy(p->aRef,aRef);
						strcpy(p->nRef,nRef);
					}
				}
				/*if(!strcmp(aRef,"turlok"))
				{
					char haha[100];
					sprintf(haha,"It's Turlok! It's really him! Make love to me, %s - PLEASE!",playerName);
					Speak(haha);
				}*/
				if(_parseGame)
				{
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					if(strcmp(playerName,_hero.name))//dont bother tagging yourself
					{
						if(!pker)
							Chat("",false,"�c4%s (%s) has joined the game. [�c9Level �c8%u �c9%s�c4]",playerName,accountName,playerLevel,type);
						else
							Chat("",false,"�c1%s (%s) �c1has joined the game. [�c9Level �c8%u �c9%s�c1]",playerName,accountName,playerLevel,type);
					}
				}
			}
			// if a player is leaving the game then find out their name and
			// remove them from the module's list of in-game players
			if (action == 0x03)
			{
				//Chat("",false,"Made it to 'Leave Game message 0x03'");
				lastLeave=GetTickCount();
				RemovePlayer(playerName);
				if(_parseGame)
				{
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					if(!pker)
						Chat("",false,"�c4%s (%s) has left the game. [�c9Level �c8%u �c9%s�c4]",playerName,accountName,playerLevel,type);
					else
						Chat("",false,"�c1%s (%s) �c1has left the game. [�c9Level �c8%u �c9%s�c1]",playerName,accountName,playerLevel,type);
				}
			}
			//player dropped; same story
			if (action == 0x00)
			{
				lastLeave=GetTickCount();
				RemovePlayer(playerName);
				if(_parseGame)
				{
					packet->SetFlag(IPacket::PacketFlag_Virtual);
					if(!pker)
						Chat("",false,"�c4%s (%s) was dropped from the game. [�c9Level �c8%u �c9%s�c4]",playerName,accountName,playerLevel,type);
					else
						Chat("",false,"�c1%s (%s) �c1was dropped from the game. [�c9Level �c8%u �c9%s�c1]",playerName,accountName,playerLevel,type);
				}
			}
			if (action == 0x06)
			{
				if (_stricmp(playerName, _hero.name) == 0)
				{
					_state = ChickenState_InTown;
				}
			}
			if (action == 0x07) //p2p relations
			{
				//Chat(_chatName,false,"p2p relation!");
				/*if (bytes[2] == 0x02)
				{//teaming
					//Chat(_chatName,false,"teaming!");
					if (bytes[7] == 0x07 /*|| bytes[7] == 0x08*//*) //party
					{
						//Chat(_chatName,false,"party!");
						for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
						{
							//Chat(_chatName,false,"%u : %u",playerId,p->id);
							if(playerId == p->id)
							{
								p->status=1;
								break;
							}
						}
					}
				}*/
				if (bytes[2] == 0x08) //nasty
				{
					//Chat(_chatName,false,"nasty!");
					if (bytes[7] == 0x03) //hostile
					{
						//Chat(_chatName,false,"hostile!");
						for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
						{
						//	Chat(_chatName,false,"%u : %u",playerId,p->id);
							if(playerId == p->id)
							{
								if (_shit && !p->shithead)
								{
									Account name;
									strcpy(name.accountName,p->name);
									_shitListP.push_back(name);
									shitAddP(p->name);
									p->shithead=true;
									if (strcmp(p->account,"\n") && strcmp(p->account,""))
									{
										Account temp;
										strcpy(temp.accountName,p->aRef);
										_shitList.push_back(temp);
										shitAdd(p->aRef);
										p->shithead=true;
									}
								}
								p->isHostile=true;
								//p->status=2;
								break;
							}
						}
					}
				}
				if (bytes[2] == 0x09) //remove
				{
					//Chat(_chatName,false,"remove!");
					if (bytes[7] == 0x09) //leave party
					{
						//Chat(_chatName,false,"leave party!");
						for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
						{
						//	Chat(_chatName,false,"%u : %u",playerId,p->id);
							if(playerId == p->id && p->status != 2)
							{
								p->status=0;
								break;
							}
						}
					}
				}
				if (bytes[2] == 0x00) //neutral
				{
					//Chat(_chatName,false,"neutral!");
					if (bytes[7] == 0x04) //unhostile
					{
						//Chat(_chatName,false,"unhostile!");
						for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
						{
						//	Chat(_chatName,false,"%u : %u",playerId,p->id);
							if(playerId == p->id)
							{
								p->status=0;
								break;
							}
						}
					}
				}
			}
		}
		break;
	case 0x81://merc assign
		{
			int ownerId=*reinterpret_cast<const int*>(bytes + 4);
			int mercId=*reinterpret_cast<const int*>(bytes + 8);
			if(ownerId==_hero.id)
			{
				if(_secho)
					Chat(_chatName, false, "�c:Merc Detected");
				_mercId = mercId;
				_mercLife = 100;
				_haveMerc=true;
			}
		}
	break;
	case 0x22://update skill status (get TP book quantity (in your face, BitField!))
		{
			if(bytes[7]==220)//is this tp book?
			{
				_quantity=bytes[9];
				if(!_justClosed && !_inStash)
				{
					if(!_dontSpam)
					{
						if(_secho)
							Chat(_chatName, false, "�c:Town Portal Book: �c8%u",_quantity);
						if(!_quantity)
							if(_wecho)
								Chat(_chatName, false, "�c1Warning: out of TPs!");
					}
					else
						_dontSpam=false;
				}
				else
					_justClosed=false;
			}
		}
		break;
	case 0xA7://curse assign
		{
			int targetId = *reinterpret_cast<const int*>(bytes + 2);
			int skillId = bytes[6];
			if(!bytes[1] && targetId==_hero.id && skillId==0x66)//no delays now
				packet->SetFlag(IPacket::PacketFlag_Virtual);
			if(!bytes[1] && targetId==_hero.id && skillId==55)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: you have been cursed with �c8Iron Maiden");
				if(_townIron)
				{
					_state = ChickenState_OpeningTp;
					_hostile = false;
					CastTp();
				}
			}
			if(bytes[1]==0x01 && targetId==_mercId && skillId==55)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: your merc has been cursed with �c8Iron Maiden");
				if(_townMercIron)
				{
					_state = ChickenState_OpeningTp;
					_hostile = false;
					CastTp();
				}
			}
		}
	break;
	case 0xA8://aura cover
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			int skillId = bytes[7];
			if(!bytes[1] && playerId==_hero.id && skillId==0xAE)
			{
				/*if(_secho)
					Chat(_chatName, false, "�c:STATESET: �c8Whirl Wind");*/
				_whirl=true;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==32)
			{
				if(_secho)
					Chat(_chatName, false, "�c:Bonus Life Modifier: �c8Battle Orders");
				_hasBO=true;
				_maxLife=_safeLife;
				_maxMana=_safeMana;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==149)
			{
				if(_secho)
					Chat(_chatName, false, "�c:Bonus Life Modifier: �c8Oak Sage");
				_hasOak=true;
				_maxLife=_safeLife;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==139)
			{
				if(_secho)
					Chat(_chatName, false, "�c:Bonus Life Modifier: �c8Wolf Form");
				_hasWolf=true;
				_maxLife=_safeLife;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==140)
			{
				if(_secho)
					Chat(_chatName, false, "�c:Bonus Life Modifier: �c8Bear Form");
				_hasBear=true;
				_maxLife=_safeLife;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==16)
				if(_secho)
					Chat(_chatName, false, "�c:Bonus Damage Modifier: �c8Enchant");
		}
		break;
	case 0xA9://aura remove
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			int skillId = bytes[6];
			if(!bytes[1] && playerId==_hero.id && skillId==0xAE)
			{
				/*if(_wecho)
					Chat(_chatName, false, "�c:STATECLEAR: �c8Whirl Wind");*/
				_whirl=false;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==32)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: �c8Battle Orders �c1has worn off");
				_bonusOff=true;
				_hasBO=false;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==149)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: �c8Oak Sage �c1has worn off");
				_bonusOff=true;
				_hasOak=false;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==139)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: �c8Wolf form �c1has worn off");
				_bonusOff=true;
				_hasWolf=false;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==140)
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: �c8Bear form �c1has worn off");
				_bonusOff=true;
				_hasBear=false;
			}
			if(!bytes[1] && playerId==_hero.id && skillId==16)
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: �c8Enchant �c1has worn off");
			if(!bytes[1] && playerId==_hero.id && skillId==55)
				if(_secho)
					Chat(_chatName, false, "�c:Curse: �c8Iron Maiden �c:has worn off");
			if(bytes[1]== 0x01 && playerId==_mercId && skillId==55)
				if(_secho)
					Chat(_chatName, false, "�c:Merc curse: �c8Iron Maiden �c:has worn off");
		}
		break;
	case 0x1e://update base stat as word
		{
			int attCode = bytes[1];
			int part1 = bytes[2];
			int part2 = bytes[3];
			if(attCode==MaxLife)
			{
				if(part1)
				{
					//it will flag this value for druids... at least with 0x80
					if(part1>=0x80)
					{
						part1-=0x80;
						_baseMaxLife=(part1 << 8) | bytes[3];
						//Chat(_chatName,false,"Your life was flagged with 0x80!");
					}
					else
						_baseMaxLife = *reinterpret_cast<const short*>(bytes + 2);
					_life=_baseMaxLife;
					_maxLife=_baseMaxLife;
					_safeLife=_baseMaxLife;
					_lifePercent=(float(_life)/float(_maxLife))*100;
					//Chat(_chatName,false,"Base Life: %u",_baseMaxLife);
					//Chat(_chatName,false,"Lifea: %u/%u [%u percent]",_life,_maxLife,_lifePercent);
				}
				else
				{
					_baseMaxLife = part2;
					_life=_baseMaxLife;
					_maxLife=_baseMaxLife;
					_safeLife=_baseMaxLife;
					_lifePercent=(float(_life)/float(_maxLife))*100;
					//Chat(_chatName,false,"Lifeb: %u/%u [%u percent]",_life,_maxLife,_lifePercent);
				}
			}
		}
		break;
	case 0x1f://update base stat as dword
		{
			int attCode = bytes[1];
			int part1 = bytes[2];
			int part2 = bytes[3];
			int part3 = bytes[4];
			int part4 = bytes[5];
			if(attCode==MaxLife)
			{
				if(part1)
				{
					if(part1>=0x80)//remove 0x80..damn this flag!
					{
						_baseMaxLife=part2+part3*256+part4*2*256;
						//Chat(_chatName,false,"Your life was flagged with 0x80!");
					}
					else
						_baseMaxLife = *reinterpret_cast<const int*>(bytes + 2);
					_life=_baseMaxLife;
					_maxLife=_baseMaxLife;
					_safeLife=_baseMaxLife;
					_lifePercent=(float(_life)/float(_maxLife))*100;
					//Chat(_chatName,false,"Lifec: %u/%u [%u percent]",_life,_maxLife,_lifePercent);
				}
				else
				{
					/*if(part2>=0x80)//remove 0x80..damn this flag!
					{
						_baseMaxLife=part3+part4*256;
						//Chat(_chatName,false,"Your life was flagged with 0x80!");
					}
					else*/
					_baseMaxLife = part2+part3*256+part4*2*256;
					_life=_baseMaxLife;
					_maxLife=_baseMaxLife;
					_safeLife=_baseMaxLife;
					_lifePercent=(float(_life)/float(_maxLife))*100;
					//Chat(_chatName,false,"Lifed: %u/%u [%u percent]",_life,_maxLife,_lifePercent);
				}
				//Chat(_chatName,false,"Base Life: %u",_baseMaxLife);
			}
		}
		break;
	case 0x5b:
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 3);
			int playerLevel = *reinterpret_cast<const short*>(bytes + 24);
			const char* playerName = reinterpret_cast<const char*>(bytes + 8);
			int playerType = bytes[7];
			bool pker=false;
			bool alreadybeenhere=false;
			char type[16];
			char nRef[16];
			for(int x=0;x<16;x++)
				nRef[x]=tolower(playerName[x]);
			for (std::list<Account>::iterator a = _shitListP.begin(); a != _shitListP.end(); a++)
				if(!strcmp(playerName,a->accountName))
					pker=true;
			for(int x=0;x<8;x++){
				if(_targets[x]==0)
				{
					//Chat(_chatName,false,"Added %u to _targets",playerId);
					_targets[x]=playerId;
					if(playerId==_hero.id)
						_currentTarget=x;
					x=8;
				}
			}
			// a player has entered the game; if they are the hero then store
			// off additional information about them (like their level and id)
			if (strcmp(playerName, _hero.name) == 0)
			{
				_joined = true;
				_hero.id = playerId;
				_hero.level = playerLevel;
				_currentArea = 1;//Default Area will be Rogue Encampment.
				_lastPing=GetTickCount();
			}
			for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
			{
				if(!strcmp(playerName, p->name))
				{
					alreadybeenhere=true;
					p->here=true;
					p->id=playerId;
					p->level=playerLevel;
					p->status=0;
				}	
			}
			if(!alreadybeenhere)
				AddPlayer(playerName, playerLevel, playerId, playerType, pker);
			if(!_joined)
			{
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(!strcmp(p->name,playerName))
					{
						strcpy_s(type,sizeof(type),p->type);
						strcpy_s(p->nRef,sizeof(p->nRef),nRef);
					}
				}
				if(_parseGame)
				{
					if(!pker)
						Chat("",false,"�c4%s is already in the game. [�c9Level �c8%u �c9%s�c4]",playerName,playerLevel,type);
					else
						Chat("",false,"�c1%s �c1is already in the game. [�c9Level �c8%u �c9%s�c1]",playerName,playerLevel,type);
				}
			}
		}
		break;
	case 0x82:
		{
			int portalId = *reinterpret_cast<const int*>(bytes + 21);
			int playerId = *reinterpret_cast<const int*>(bytes + 1);

			// the server is notifying us about a town portal that has just come
			// into view/existance; if this town portal belongs to the hero and 
			// the module is trying to open a tp, then use this tp
			if (playerId == _hero.id && _state == ChickenState_OpeningTp)
			{
				UsePortal(portalId);
				_state = ChickenState_UsingTp;
			}
		}
		break;
	/*case 0x03://possible solution
		{
			short area = *reinterpret_cast<const int*>(bytes + 6);
			short act = bytes[1];
			Chat("Act", false, "%u",act+1);
			Chat("Area", false, "%u",area);
		}
		break;*/
	case 0x0d://player stop info
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			short playerX = *reinterpret_cast<const short*>(bytes + 7);
			short playerY = *reinterpret_cast<const short*>(bytes + 9);
			int lifeP = bytes[12];
			if(lifeP>100)
				lifeP=100;
			/*Chat("Player Stop", false, "ID:%u",playerId);
			Chat("Player Stop", false, "X:%u",playerX);
			Chat("Player Stop", false, "Y:%u",playerY);*/
			for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
				{
					if (i->id == playerId)//Find Player whos Stopped and update location
					{
						i->xPos=playerX;
						i->yPos=playerY;
						i->lifeP=lifeP;
						i->visible=true;
					}
				}
		}
		break;
	case 0x0f://player move info
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			short playerX = *reinterpret_cast<const short*>(bytes + 7);
			short playerY = *reinterpret_cast<const short*>(bytes + 9);
			/*Chat("Player Move", false, "ID:%u",playerId);
			Chat("Player Move", false, "X:%u",playerX);
			Chat("Player Move", false, "Y:%u",playerY);*/
			for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
				{
					if (i->id == playerId)//Find Player whos Moving and update location
					{
						i->xPos=playerX;
						i->yPos=playerY;
						i->visible=true;
					}
				}
		}
		break;
	case 0x95://Get Current Health/Mana
		{
			_mana = ~bytes[4];
			_mana |= 0xC0;
			_mana = ~_mana;
			_mana = ((_mana << 8) | bytes[3]) << 1;
			_life = bytes[2];
			if (_life >= 0x80)
				_life -= 0x80;
			_life = (_life << 8) | bytes[1];
			if(_mana>=_maxMana)
			{
				_maxMana=_mana;
				if(!_hasBO)
					_safeMana=_mana;
			}
			if(_baseMaxLife>_maxLife)//if we see max life drop below its base, use base for now
				_maxLife=_baseMaxLife;
			if(_life>=_maxLife)//if we see life reach a higher value than current max, it becomes the new max
			{
				_maxLife=_life;
				if(!_hasBO && !_hasOak && !_hasBear && !_hasWolf)//if there are no modifiers, record safty life
					_safeLife=_life;
			}
			//If bonuses are removed, be sure to reassign max health:
			if(_bonusOff){
				if(_life>_safeLife)
					_maxLife=_life;
				else
					_maxLife=_safeLife;
				if(_mana>_safeMana)
					_maxMana=_mana;
				else
					_maxMana=_safeMana;
				_bonusOff=false;
			}
			_lifePercent=(float(_life)/float(_maxLife))*100;
			_manaPercent=(float(_mana)/float(_maxMana))*100;
			//Chat(_chatName,false,"Lifee: %u/%u [%u percent]",_life,_maxLife,_lifePercent);
			if(_life<_maxLife && _dirtyFix)
			{
				_life=1;
				_maxLife=1;
				_safeLife=1;
				_lifePercent=100;
				_mana=1;
				_maxMana=1;
				_safeMana=1;
				_manaPercent=100;
				_dirtyFix=0;
				//Chat(_chatName,false,"Dirty Fix!");
			}
			//Chat(_chatName, false, "�c1Mana:%u / %u [S}%u [P}%u",_mana,_maxMana,_safeMana,_manaPercent);
			//Chat(_chatName, false, "�c1Life:%u / %u [B}%u [S}%u [P}%u",_life,_maxLife,_baseMaxLife,_safeLife,_lifePercent);
			if(_lifePercent<=_exitHealth && _chickenExit && _life>0 && !_hero.inTown)//exit the game at this value
			{
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: Life below �c8%u percent!",_exitHealth);
				Exit();
				_exit=true;
			}
			if(_lifePercent<=_chickenHealth && _chickenTown && !_hero.inTown)//chicken to town at this value
			{
				_hero.inTown=true;
				if(_wecho)
					Chat(_chatName, false, "�c1Warning: Life below �c8%u percent!",_chickenHealth);
				_state = ChickenState_OpeningTp;
				_hostile = false;
				CastTp();
			}
		}
		break;
	case 0x4C: //Player attacks object
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			int targetId = *reinterpret_cast<const int*>(bytes + 10);
			short skillId = *reinterpret_cast<const short*>(bytes+6);
			char playerName[16];
			bool dodge=false;
			int uId = bytes[1];
			//Chat(_chatName, false, "Attacker Id:%u Target Id:%u heroId:%u",playerId,targetId,_hero.id);
			//if a player is direct-attacking the hero, chicken to town
			if(_bossTalk){
			if (skillId==164 /*andariel spray*/)
				Chat("�c4Andariel",false,"�c5Die slowly, human!");
			if (skillId==201 /*anderial bolt*/)
				Chat("�c4Andariel",false,"�c5Breathe in the pain!");
			if (skillId==334 /*mephisto missile*/)
				Chat("�c4Mephisto",false,"�c2The orb of hate will consume you!");
			if (skillId==193 /*diablo lightning*/)
				Chat("�c4Diablo",false,"�c1Step into the light!");
			if (skillId==194 /*diablo cold*/)
				Chat("�c4Diablo",false,"�c1Be frozen!");
			if (skillId==195 /*diablo fire*/)
				Chat("�c4Diablo",false,"�c1Hell cannot contain my fury!");
			if (skillId==197 /*diablo hellfiretorch*/)
				Chat("�c4Diablo",false,"�c1Burn!");
			if (skillId==199 /*diablo prison*/)
				Chat("�c4Diablo",false,"�c1Be contained, mortal!");
			if (skillId==284 /*baal taunt*/)
				Chat("�c4Baal",false,"�c8My brothers will not have died in vain!");
			if (skillId==286 /*baal spawn*/)
				Chat("�c4Baal",false,"�c8Quit gawking, you cross-eyed brat!  We shall close those eyes for you!");
			if (skillId==315 /*baal tentacle*/)
				Chat("�c4Baal",false,"�c8I'll take a break from violating anime girls with these to choke the life out of you!");
			if (skillId==316 /*baal nova*/)
				Chat("�c4Baal",false,"�c8I am Destruction!");
			if (skillId==317 /*baal inferno*/)
				Chat("�c4Baal",false,"�c8I will sap your strength!");
			if (skillId==318 /*baal cold missile*/)
				Chat("�c4Baal",false,"�c8Get back, fiend!");
			}
			if(uId==0x00){//lets make sure this relates to a player *merc fix* *shrine fix*
			if (targetId == _hero.id)
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
				{
					if (i->id == playerId)//make sure the attacker is a player and get his name
					{
						dodge=true;
						strcpy(playerName, i->name);
					}
				}
				if(dodge)
				{
					if(!_hero.inTown && _townDirect && GetTickCount()-lastChicken>500 && !(/*Enchant*/ skillId==52 || /*Holy Bolt*/ skillId==101 || /*Barbarian Cries*/ skillId==138 || skillId==149 || skillId==155))
					{
						lastChicken=GetTickCount();
						Chat(_chatName, false, "�c1Warning: Direct-Attacked by �c8%s �c4[�c9%s�c4]",playerName,convertAttack(skillId));
						_state = ChickenState_OpeningTp;
						_hostile = false;
						CastTp();
					}
				}
			}
			}
		}
		break;
	case 0x4D: //player attacking location
		{
			int uId = bytes[1];
			int playerId = *reinterpret_cast<const int*>(bytes + 2);
			short targetX = *reinterpret_cast<const short*>(bytes + 11);
			short targetY = *reinterpret_cast<const short*>(bytes + 13);
			int skillId = *reinterpret_cast<const int*>(bytes + 6);
			char playerName[16];
			bool dodge=false;
			if(uId==0x00){//lets make sure this relates only to players *fix merc aa* *fix shrine drop*
			if(targetX==_hero.xPos && targetY==_hero.yPos) //if player is attacking your position...
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					{
						if (i->id == playerId)//make sure the attacker is a player and get his name
						{
							i->visible=true;
							dodge=true;
							strcpy(playerName, i->name);
						}
					}
				if(dodge)
				{
					if(!_hero.inTown && _townCoord && GetTickCount()-lastChicken>500 && !(/*Enchant*/ skillId==52 || /*Holy Bolt*/ skillId==101 || /*Barbarian Cries*/ skillId==138 || skillId==149 || skillId==155))
					{
						lastChicken=GetTickCount();
						Chat(_chatName, false, "�c1Warning: Your location tile is being attacked by �c8%s �c4[�c9%s�c4]",playerName,convertAttack(skillId));
						_state = ChickenState_OpeningTp;
						_hostile = false;
						CastTp();
					}
				}
			}
			}
		}
		break;
	case 0x8C: //relationship status changed
		{
			int playerId = *reinterpret_cast<const int*>(bytes + 1);
			int playerId2 = *reinterpret_cast<const int*>(bytes + 5);
			int relations = bytes[9];
			//If a player changes relationship with the hero, and the result includes hostile
			//we will chicken to town if not already there
			if (playerId == _hero.id && relations >= 0x08)
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					if(i->id==playerId2)
						i->isHostile=true;
				if(!_hero.inTown && _townHostile && GetTickCount()-lastChicken>500)
				{
					lastChicken=GetTickCount();
					Chat(_chatName, false, "�c1Warning: Hostile Player!");
					_state = ChickenState_OpeningTp;
					_hostile = false;
					CastTp();
				}
			}
			else if(playerId ==_hero.id && relations < 0x08)
			{
				for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
					if(i->id==playerId2)
						i->isHostile=false;
			}
		}
		break;
	case 0x8D: //party Assign
	{
		int playerId = *reinterpret_cast<const int*>(bytes + 1);
		short partyId = *reinterpret_cast<const short*>(bytes + 5);
		for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
		{
			if(i->id==playerId)
			{
				i->party=partyId;
				/*if(partyId!=65535 && partyId!=-1 && partyId==_hero.party)
					i->status=1;*/
				if(_currentTarget<8)
					if(i->id==_targets[_currentTarget])
						_targetParty=partyId;
			}
		}
		if(playerId==_hero.id)
		{
			_hero.party=partyId;
		/*	for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
				if(i->party==partyId)
					i->status=1;*/
		}
	}
	break;
	case 0x0C://comp takes dmg
	{
		if(bytes[1]==1)
		{
			int compId = *reinterpret_cast<const int*>(bytes + 2);
			if(_mercId==compId)//if this is your merc, update his life
			{
				_mercLife = float(bytes[8]*100/125);
				//Chat(_chatName, false, "�c1Mercenary Life:�c8%u",_mercLife);
			}
		}
	}
	break;
	case 0x6D://comstop
	{
		int compId = *reinterpret_cast<const int*>(bytes + 1);
		if(_mercId==compId)//if this is your merc, update his life
			{
				_mercLife = float(bytes[9]*100/128);
				//Chat(_chatName, false, "�c1Mercenary Life:�c8%u",_mercLife);
			}
	}
	break;
	case 0x15:
		{
			bool swap=false;
			int unitType = bytes[1];
			if (unitType == 0)
			{
				int playerId = *reinterpret_cast<const int*>(bytes + 2);
				short xPos1 = bytes[6];
				short xPos2 = bytes[7];
				short xPos = (xPos2 << 8) | xPos1;
				short yPos1 = bytes[8];
				short yPos2 = bytes[9];
				short yPos = (yPos2 << 8) | yPos1;
				if(playerId == _hero.id)
				{
					_hero.xPos = xPos;
					_hero.yPos = yPos;
					if (_hero.xPos >= _town.minX && _hero.xPos <= _town.maxX && _hero.yPos >= _town.minY && _hero.yPos <= _town.maxY) {
						if(!_hero.inTown)
						{
							swap=true;
							_hero.inTown = true;
							if(_secho)
								Chat(_chatName, false, "�c:Now inside Town.",_hero.xPos,_hero.yPos);
						}
					} else {
						if(_hero.inTown)
						{
							swap=true;
							_hero.inTown = false;
							if(_secho)
								Chat(_chatName, false, "�c1Outside of Town.",_hero.xPos,_hero.yPos);
						}
					}
					//Chat("Chicken", false, "yPos: %u", xPos);
					//Chat("Chicken", false, "yPos: %u", yPos);
				}
				// the given player has changed position; if that player is the hero
				// and the module is currently trying to use the tp, then this means
				// that the hero has entered town and should hostile everyone
				if (playerId == _hero.id && _state == ChickenState_UsingTp)
				{			
					if (_hero.level >= 9 && _hostile)
					{
						HostileParty();
					}
					_state = ChickenState_InTown;
					_hostile = false;
				}
			}
			//flash protection
			int id = *reinterpret_cast<const int*>(bytes + 2);
			if (id == _hero.id)
			{
				if (_blockFlash)
				{
					unsigned char* buffer = new unsigned char[packet->GetSize()];
					memcpy(buffer, packet->GetData(), packet->GetSize());
					buffer[10] = 0x00;
						packet->SetData(buffer, packet->GetSize());
					delete[] buffer;
				}
			}
			//flash protection end
		}
		break;
	}
}

void Condom::Update()
{
	if(GetTickCount()-_lastFlash>50)
	{
		//Chat(_chatName,false,"FlashSequenceCheck");
		for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
		{
			if(GetTickCount()-i->_lastFlash>75*_flashing && i->flashTarget)
			{
				flash(i->id);
				i->_lastFlash=GetTickCount();
				//Chat(_chatName,false,"Flashed %s",i->name);
			}
		}
		_lastFlash=GetTickCount();
	}
	if(_ping>_exitPing && _chickenPing && _joined && !_hero.inTown)
	{
		if(_wecho)
			Chat(_chatName, false, "�c1Warning: Exiting due to Ping above �c8%u!",_exitPing);
		Exit();
	}
	if(GetTickCount()-lastLeave>500 && !_Leave.empty())
	{
		lastLeave=GetTickCount();
		for (std::list<Player>::iterator i = _Leave.begin(); i != _Leave.end(); i++)
		{
			for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
			{
				if(p->id==i->id)
				{
					p->here=false;
					p->visible=false;
				}
			}
			if(!i->shithead)
				Chat("",false,"�c4%s (%s) has \"�c8silent-exited�c4\" the game. [�c9Level �c8%u �c9%s�c4]",i->name,i->account,i->level,i->type);
			else
				Chat("",false,"�c1%s (%s) �c1has \"�c8silent-exited�c1\" the game. [�c9Level �c8%u �c9%s�c1]",i->name,i->account,i->level,i->type);
			_Leave.erase(i);
			break;
		}
	}
	if(_lifePercent<=_exitHealth && _chickenExit && _life>0 && !_hero.inTown)//exit the game at this value
	{
		_exit=true;
		if(_wecho)
			Chat(_chatName, false, "�c1Warning: Life below �c8%u percent!",_exitHealth);
		Exit();
	}
	if(_exit)
		Exit();
	if(_drinker){
	if (_lifePercent <= _juvepot)
		if (GetTickCount() - lastDrink > drink_delay)
			if(!_hero.inTown)
				Drink(jPot);
	if (_lifePercent <= _lifepot)
		if (GetTickCount() - lastDrink > drink_delay)
			if(!_hero.inTown)
				Drink(hPot);
	if (_manaPercent <= _manapot)
		if (GetTickCount() - lastDrink > drink_delay)
			if(!_hero.inTown)
				Drink(mPot);
	if (_mercLife < _exitMerc && _chickenMerc && !_hero.inTown)
	{
		if(_wecho)
			Chat(_chatName, false, "�c1Warning: Mercenary health below �c8%u percent!",_exitMerc);
		Exit();
	}
	if (_mercLife < merc_juve)
		if (GetTickCount() - lastMerc > drink_delay*1.5)
		{
			DrinkMerc(jPot);
			_mercLife=100;
		}
	if (_mercLife < merc_life)
		if (GetTickCount() - lastMerc > drink_delay*1.5)
		{
			DrinkMerc(hPot);
			_mercLife=100;
		}
	}
	for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
		{
			if(i->party!=65535 && i->party!=-1 && i->party==_hero.party)
			{
				i->status=1;
				i->isHostile=false;
			}
			else if(!i->isHostile)
				i->status=0;
			else
				i->status=2;
		}
	if(GetTickCount()-statusPulse>500)
	{
		statusPulse=GetTickCount();
		for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
		{
			if(p->visible && p->id!=_hero.id && p->here)
			{
				char name[16];
				strcpy(name,p->name);
				for(int x=strlen(name);x<15;x++)
					strcat(name," ");
				const char* statusMark;
				switch(p->status){
					case 0: statusMark="�c9"; break;
					case 1: statusMark="�c2"; break;
					case 2: statusMark="�c1"; break; }
				const char* status2Mark;
				if(p->lifeP>=90)
					status2Mark="�c3";
				else if(p->lifeP>=80)
					status2Mark="�c:";
				else if(p->lifeP>=40)
					status2Mark="�c9";
				else if(p->lifeP<40)
					status2Mark="�c1";
				char overhead[4096];
				if(p->id!=_currentTarget)
					sprintf(overhead,"%s%s�c9   �c4-{%s%3.3d�c8%%�c4}-",statusMark,name,status2Mark,p->lifeP);
				else
					sprintf(overhead,"�c8->%s%s�c9   �c4-{%s%3.3d�c8%%�c4}-",statusMark,name,status2Mark,p->lifeP);
				if(_displayStatus)
				{
					if(!p->shithead)
						OverheadDisplay(p->id,0x00,overhead);
					else
					{
						char overhead2[4096];
						sprintf(overhead2,"�c;[PK]               %s",overhead);
						OverheadDisplay(p->id,0x00,overhead2);
					}
				}
			}
		}
	}
}

void Condom::CastTp()
{
	if(invSearch(tpScroll,true,&useInventory,&useId)){
		useInventory ? InvInteract(useId) : BeltInteract(useId);
		invRem(useId);
		useId=0;
		if(_secho)
			Chat(_chatName, false, "�c:Opening Portal [�c8scroll�c:]");
	}
	else{
		if(_quantity)
		{
			InvInteract(TownPortalBook.Id);
			if(_secho)
				Chat(_chatName, false, "�c:Opening Portal [�c8book�c:]");
		}
		else
			if(_wecho)
				Chat(_chatName, false, "�c1Warning: out of TPs!");
	}
}

void Condom::UsePortal(int portalId)
{
	// use the town portal object
	UseObject(2, portalId);
	if(_secho)
		Chat(_chatName, false, "�c:Entering Town...");
}

void Condom::UseObject(int objectType, int objectId)
{
	unsigned char buffer[9];
	int offset = 0;
	buffer[offset++] = 0x13;
	*reinterpret_cast<int*>(buffer + offset) = objectType;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = objectId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::InvInteract(int objectId)
{
	int offset = 0;
	unsigned char buffer[13];
	buffer[offset++] = 0x20;
	*reinterpret_cast<int*>(buffer+offset) = objectId;
	offset+= sizeof(int);
	*reinterpret_cast<int*>(buffer+offset) = _hero.xPos;
	offset+= sizeof(int);
	*reinterpret_cast<int*>(buffer+offset) = _hero.yPos;
	offset+= sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::BeltInteract(int objectId)
{
	int offset = 0;
	unsigned char buffer[13];
	buffer[offset++] = 0x26;
	*reinterpret_cast<int*>(buffer+offset) = objectId;
	offset+= sizeof(int);
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::GiveMerc(int objectId)
{
	int offset = 0;
	unsigned char buffer[26];
	buffer[offset++] = 0x26;
	*reinterpret_cast<int*>(buffer+offset) = objectId;
	offset+= sizeof(int);
	buffer[offset++] = 0x01;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::Chat(const char* name, bool whisper, const char* format, ...)
{
	char text[4096];

	va_list arguments;
	va_start(arguments, format);
	vsprintf_s(text, sizeof(text), format, arguments);
	va_end(arguments);	

	int length = static_cast<int>(strlen(text) + strlen(name)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = whisper ? 0x02 : 0x01;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = whisper ? 0x01 : 0x05;

	for (int i = 0; name[i] != '\0'; i++)
	{
		buffer[offset++] = name[i];
	}
	buffer[offset++] = 0x00;

	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	}
	buffer[offset++] = 0x00;

	IPacket* packet = _proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}

void Condom::OverheadDisplay(int id, int type, const char* text)
{
	int length = static_cast<int>(strlen(text)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = 0x05;
	buffer[offset++] = 0x00;
	buffer[offset++] = type;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;

	buffer[offset++] = 0x00;
	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	};
	buffer[offset++] = 0x00;
	
	IPacket* packet = _proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}

void Condom::Speak(const char* text)
{
	if (strlen(text) > 0)
	{
		int size = static_cast<int>(strlen(text)) + 6;
		char* buffer = new char[size];
		int offset = 0;

		buffer[offset++] = 0x15;
		buffer[offset++] = 0x01;
		buffer[offset++] = 0x00;

		for (int i = 0; text[i] != '\0'; i++)
		{
			buffer[offset++] = text[i];
		}
		buffer[offset++] = 0x00;

		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, size);
		_proxy->RelayDataToServer(packet, this);
		delete packet;

		delete[] buffer;
	}
}
void Condom::AddPlayer(const char* playerName, int playerLevel, int playerId, int type, bool shithead)
{
	Player player;
	strcpy_s(player.name, sizeof(player.name), playerName);
	player.id = playerId;
	player.level = playerLevel;
	strcpy(player.account,"\0");
	strcpy(player.aRef,"\0");
	strcpy(player.lastSpoken,"\0");
	player.spoken=0;
	//player.account[0] = '\0';
	player.status = 0;
	player.shithead = shithead;
	player.typeId=type;
	switch(type){
		case 0:strcpy(player.type,"Amazon");break;
		case 1:strcpy(player.type,"Sorceress");break;
		case 2:strcpy(player.type,"Necromancer");break;
		case 3:strcpy(player.type,"Paladin");break;
		case 4:strcpy(player.type,"Barbarian");break;
		case 5:strcpy(player.type,"Druid");break;
		case 6:strcpy(player.type,"Assassin");break;
		default:strcpy(player.type,"Unknown");break;
	}
	player.lifeP=100;
	player.visible=true;
	player.here=true;
	player.isHostile=false;
	player.flashTarget=false;
	player.joinNum=_joinCount++;
	player.party=20;
	for (std::list<Skill>::iterator i = _skillPool.begin(); i != _skillPool.end(); i++)
	{
		if(playerId==i->owner)
		{
			Skill thisSkill;
			thisSkill.base=i->base;
			thisSkill.bonus=i->bonus;
			thisSkill.level=i->level;
			strcpy(thisSkill.name,i->name);
			thisSkill.owner=i->owner;
			thisSkill.type=i->type;
			player.skills.push_back(thisSkill);
			_skillPool.erase(i);
			Chat(_chatName,false,"Added Skill %s Lvl %u[%u+%u] for %s",thisSkill.name,thisSkill.level,thisSkill.base,thisSkill.bonus,playerName);
			break;
		}
	}
	_players.push_back(player);
}

void Condom::RemovePlayer(const char* playerName)
{
	// find the player entry that has the same name as the one provided; remove
	// that entry from the list and break out immediately because there won't
	// be any other players with the same name
	//Chat("",false,"Made it to 'RemovePlayer'");
	int saferef;
	if(!strcmp(playerName,_currentTargetName))
	{
		strcpy(_currentTargetName,"NULL");
		_targets[_currentTarget]=0;
	}
	//Chat("",false,"Sucessfully re-wrote Target");
	for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
	{
		if (strcmp(playerName, i->name) == 0)
		{
			for(int x=0;x<8;x++)
				if(_targets[x]==i->id)
					_targets[x]=0;
			i->here=false;
			i->visible=false;
			i->party=20;
			i->status=0;
			i->isHostile=false;
			i->_lastFlash=GetTickCount();
			if(i->flashTarget)
			{
				_flashing--; //maintain best multiplier
				i->flashTarget=false;
			}
			saferef=i->id;
		}
	}
	//Chat("",false,"Marked player Not Here and Not Visible");
	for (std::list<Player>::iterator l = _Leave.begin(); l != _Leave.end(); l++)
	{
		if (l->id==saferef)
		{
			_Leave.erase(l);
			break;
		}
	}
	//Chat("",false,"Removed Entry from _Leave");
}

void Condom::HostilePlayer(int playerId)
{
	unsigned char buffer[7];
	int offset = 0;
	buffer[offset++] = 0x5d;
	buffer[offset++] = 0x04;
	buffer[offset++] = 0x01;
	*reinterpret_cast<int*>(buffer + offset) = playerId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::HostileParty()
{
	if(_secho)
		Chat(_chatName, false, "�c1Hostile!");
	if(_currentTarget<8){
		for (std::list<Player>::iterator i = _players.begin(); i != _players.end(); i++)
		{
			if ((i->id==_targets[_currentTarget] && i->level>=9) ||(i->id!=_hero.id && i->level>=9 && i->party==_targetParty && _targetParty!=-1 && _targetParty!=65535))
			{
				HostilePlayer(i->id);
				//Chat(_chatName, false, "Hostiling %s", i->name);
			}
		}
	}
}

void Condom::UseRightSkillOnObject(int objectType, int objectId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x0d;
	*reinterpret_cast<int*>(buffer + offset) = objectType;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = objectId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::UseLeftSkillOnObject(int objectType, int objectId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x06;
	*reinterpret_cast<int*>(buffer + offset) = objectType;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = objectId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::UseRightSkillOnLocation(short locX, short locY)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x0C;
	*reinterpret_cast<short*>(buffer + offset) = locX;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = locY;
	offset += sizeof(short);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::UseLeftSkillOnLocation(short locX, short locY)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x05;
	*reinterpret_cast<short*>(buffer + offset) = locX;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = locY;
	offset += sizeof(short);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

const char* Condom::boolToString(int b)
{
	if(b>0) return "On"; else return"Off";
}

bool Condom::Drink(iType type) {
	char typeName[16];
	char sourceName[13];
	switch(type){
		case hPot: strcpy(typeName,"�c1health"); break;
		case mPot: strcpy(typeName,"�c3mana"); break;
		case jPot: strcpy(typeName,"�c;rejuvination"); break;
		default: break;
	}
	if (_life > 1) {
		if(invSearch(type,true,&useInventory,&useId)){
			(useInventory) ? InvInteract(useId) : BeltInteract(useId);
			invRem(useId);
			useId=0;
			useInventory ? strcpy(sourceName,"�c8inventory") : strcpy(sourceName,"�c8belt");
			Chat(_chatName, false, "�c:Drank %s potion �c:from %s",typeName,sourceName);
			lastDrink=GetTickCount();
			return true;
		}
		else{
			if((type==hPot && !_redEmpty) || (type==mPot && !_blueEmpty) || (type==jPot && !_purpleEmpty))
				Chat(_chatName, false, "�c1Warning: out of %s potions",typeName);
			switch(type){
				case hPot: _redEmpty=true; break;
				case mPot: _blueEmpty=true; break;
				case jPot: _purpleEmpty=true; break;
				default: break;
			}
			return false;
		}
	}
	else
		return false;
}

bool Condom::DrinkMerc(iType type) {
	char typeName[16];
	char sourceName[13];
	switch(type){
		case hPot: strcpy(typeName,"�c1health"); break;
		case jPot: strcpy(typeName,"�c;rejuvination"); break;
		default: break;
	}
	if (_life > 1) {
		if(invSearch(type,false,&useInventory,&useId)){
			GiveMerc(useId);
			invRem(useId);
			useId=0;
			strcpy(sourceName,"�c8belt");
			Chat(_chatName, false, "�c:Gave mercenary %s potion �c:from %s",typeName,sourceName);
			lastMerc=GetTickCount();
			return true;
		}
		else{
			if((type==hPot && !_redEmpty) || (type==mPot && !_blueEmpty) || (type==jPot && !_purpleEmpty))
				Chat(_chatName, false, "�c1Warning: couldn't find %s potion�c1 for mercenary",typeName);
			switch(type){
				case hPot: _redEmpty=true; break;
				case jPot: _purpleEmpty=true; break;
				default: break;
			}
			return false;
		}
	}
	else
		return false;
}

void Condom::Exit()
{
	//exit game to server
	unsigned char buffer[1];
	buffer[0] = 0x69;
	IPacket* packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
	//game over from server
	buffer[0] = 0xB0;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
	//unload done from server
	buffer[0] = 0x05;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
	//success from server
	buffer[0] = 0x06;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}

void Condom::freeze(int Id)
{	
	unsigned char buffer[7];
	int offset = 0;
	buffer[offset++] = 0xA7;
	buffer[offset++] = 0x01;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	buffer[offset++] = 0x01;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}
void Condom::unfreeze(int Id)
{
	unsigned char buffer[7];
	int offset = 0;
	buffer[offset++] = 0xA9;
	buffer[offset++] = 0x01;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	buffer[offset++] = 0x01;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}
void Condom::showSet()
{
	Chat(_chatName, false, "�c1ChickenToTown: �c8%s", boolToString(_chickenTown));
	Chat(_chatName, false, "�c1ChickenExit: �c8%s", boolToString(_chickenExit));
	Chat(_chatName, false, "�c1ChickenMerc: �c8%s", boolToString(_chickenMerc));
	Chat(_chatName, false, "�c1PingExit: �c8%s", boolToString(_chickenPing));
	Chat(_chatName, false, "�c1TownOnIronMaiden: �c8%s", boolToString(_townIron));
	Chat(_chatName, false, "�c1TownOnMercIronMaiden: �c8%s", boolToString(_townMercIron));
	Chat(_chatName, false, "�c1TownOnHostile: �c8%s", boolToString(_townHostile));
	Chat(_chatName, false, "�c1TownOnDirectAttack: �c8%s", boolToString(_townDirect));
	Chat(_chatName, false, "�c1TownOnCOORDAttack: �c8%s", boolToString(_townCoord));
	Chat(_chatName, false, "�c1TPPKmode: �c8%s", boolToString(_TPPK));
	if(_drinker)
		Chat(_chatName, false, "�c1AutoPot: �c8%s �c1Drink Delay: �c8%u milliseconds",boolToString(_drinker),drink_delay);
	else
		Chat(_chatName, false, "�c1AutoPot: �c8%s", boolToString(_drinker));
	Chat(_chatName, false, "�c1ParseChatText: �c8%s", boolToString(_parseText));
	Chat(_chatName, false, "�c1ParseGameMessages: �c8%s", boolToString(_parseGame));
	Chat(_chatName, false, "�c1BossAttackMessages: �c8%s", boolToString(_bossTalk));
	Chat(_chatName, false, "�c1StatusMessages: �c8%s", boolToString(_secho));
	Chat(_chatName, false, "�c1WarningMessages: �c8%s", boolToString(_wecho));
	Chat(_chatName, false, "�c1LevelMessages: �c8%s", boolToString(_lecho));
	Chat(_chatName, false, "�c1DisplayStatus: �c8%s", boolToString(_displayStatus));
	Chat(_chatName, false, "�c1SpamFilter: �c8%s", boolToString(_spamFilter));
	Chat(_chatName, false, "�c1HideCorpses: �c8%s", boolToString(_cHide));
	Chat(_chatName, false, "�c1ListPKs: �c8%s", boolToString(_shit));
	Chat(_chatName, false, "�c1AutoParty: �c8%s", boolToString(_aParty));
	if(_chickenTown) Chat(_chatName, false, "�c1ChickenLife: �c8%u percent", _chickenHealth);
	if(_chickenExit) Chat(_chatName, false, "�c1ExitLife: �c8%u percent", _exitHealth);
	if(_chickenMerc) Chat(_chatName, false, "�c1ExitMerc: �c8%u percent", _exitMerc);
	if(_chickenPing) Chat(_chatName, false, "�c1ExitPing: �c8%u", _exitPing);
	if(_drinker)
	{
		Chat(_chatName, false, "�c1PotionMessages: �c8%s", boolToString(_pecho));
		Chat(_chatName, false, "�c1HealthPotLife: �c8%u percent", _lifepot);
		Chat(_chatName, false, "�c1ManaPotMana: �c8%u percent", _manapot);
		Chat(_chatName, false, "�c1RejuvePotLife: �c8%u percent", _juvepot);
		Chat(_chatName, false, "�c1MercHealthPotLife: �c8%u percent", merc_life);
		Chat(_chatName, false, "�c1MercRejuvePotLife: �c8%u percent", merc_juve);
	}
}

void Condom::getFilter()
{
	char line[255];
	ifstream filterList("squelch.txt");
	Account flter; 
	if (filterList.is_open())
	{
		while (! filterList.eof() )
		{
			filterList.getline(line,255);
			strcpy(flter.accountName,line);
			for(int x=0;x<255;x++)
				flter.accountName[x]=toupper(flter.accountName[x]);
			_filterList.push_back(flter);
		}
		filterList.close();
		Chat(_chatName,false,"�c:Spam filter loaded");
	}
	else
		Chat(_chatName, false, "�c1Failed to load spam filter!");
}

void Condom::getShitList()
{
	char line[255];
	Account acnt;
	ifstream myfile ("pkaccount.txt");
	if (myfile.is_open())
	{
		while (! myfile.eof() )
		{
			myfile.getline(line,16);
			strcpy(acnt.accountName,line);
			for(int x=0;x<16;x++)
				acnt.accountName[x]=tolower(acnt.accountName[x]);
			_shitList.push_back(acnt);
		}
		myfile.close();
		Chat(_chatName,false,"�c:PK List Loaded");
	}
	else
		Chat(_chatName, false, "�c1Failed to open pklist!");
	for (std::list<Account>::iterator a = _shitList.begin(); a != _shitList.end(); a++)
	{
		if (!strcmp(a->accountName,"\n") || !strcmp(a->accountName,""))//dont shitlist original players
		{
			_shitList.erase(a);
			break;
		}
	}
}
void Condom::getShitListP()
{
	char line[255];
	Account acnt;
	ifstream myfile ("pkname.txt");
	if (myfile.is_open())
	{
		while (! myfile.eof() )
		{
			myfile.getline(line,16);
			strcpy(acnt.accountName,line);
			_shitListP.push_back(acnt);
		}
		myfile.close();
		Chat(_chatName,false,"�c:PK List Loaded");
	}
	else
		Chat(_chatName, false, "�c1Failed to open pklist!");
	for (std::list<Account>::iterator a = _shitListP.begin(); a != _shitListP.end(); a++)
	{
		if (!strcmp(a->accountName,"\n") || !strcmp(a->accountName,""))//dont shitlist original players
		{
			_shitListP.erase(a);
			break;
		}
	}
}
void Condom::shitAdd(const char*accountName)
{
	Account acnt;
	strcpy(acnt.accountName,accountName);
	_shitList.push_back(acnt);
	ofstream myfile ("pkaccount.txt",ios::app);
	if (myfile.is_open())
	{
		Chat(_chatName, false, "�c8Added %s to PK account list.",accountName);
		myfile << accountName << "\n";
		myfile.close();
	}
	else
		Chat(_chatName, false, "�c1Failed to open PK account list!");
}
void Condom::shitAddP(const char*playerName)
{
	Account acnt;
	strcpy(acnt.accountName,playerName);
	_shitListP.push_back(acnt);
	ofstream myfile ("pkname.txt",ios::app);
	if (myfile.is_open())
	{
		Chat(_chatName, false, "�c8Added %s to PK character list.",playerName);
		myfile << playerName << "\n";
		myfile.close();
	}
	else
		Chat(_chatName, false, "�c1Failed to open PK character list!");
}
void Condom::listPlayers()
{
	for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
	{
		Chat("",false,"�c4%s (%s) [�c9Level �c8%u �c9%s�c4]�c;[%u] %s",p->name,p->account,p->level,p->type,p->id,flashCheck(p->flashTarget));
	}
}
const char* Condom::flashCheck(bool flashing)
{
	if(flashing)
		return "�c8[Flashing]";
	else
		return "�c5[Off]";
}
void Condom::flash(int playerId)
{
	unsigned char buffer[9];

	buffer[0] = 0x4b;
	*reinterpret_cast<int*>(buffer + 1) = 0;
	*reinterpret_cast<int*>(buffer + 5) = playerId;

	IPacket* packet = _proxy->CreatePacket(buffer, sizeof(buffer));
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Condom::spoofTP(int state,int areaId,int Id)
{
	unsigned char buffer[6];
	int offset = 0;
	buffer[offset++] = 0x60;
	buffer[offset++] = state;
	buffer[offset++] = areaId;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}
void Condom::partyInvite(int Id)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x5e;
	buffer[offset++] = 0x06;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Condom::partyAccept(int Id)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x5e;
	buffer[offset++] = 0x08;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Condom::markPlayer(int Id)
{
	unsigned char buffer[13];
	int offset = 0;

	buffer[offset++] = 0xa8;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	buffer[offset++] = 0x0e;
	buffer[offset++] = 0x2f;
	buffer[offset++] = 0x5e;
	buffer[offset++] = 0xef;
	buffer[offset++] = 0x7c;
	buffer[offset++] = 0x15;
	buffer[offset++] = 0xf8;
	buffer[offset++] = 0x0f;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	unsigned char buffer2[6];
	int offset2 = 0;

	buffer2[offset2++] = 0xa7;
	buffer2[offset2++] = 0x00;
	*reinterpret_cast<int*>(buffer2 + offset2) = Id;
	offset2 += sizeof(int);
	buffer2[offset2++] = 0x17;
	IPacket* packet2 = _proxy->CreatePacket(buffer2, offset2);
	_proxy->RelayDataToClient(packet2, this);
	delete packet2;
}
void Condom::removeMark(int Id)
{
	unsigned char buffer[6];
	int offset = 0;

	buffer[offset++] = 0xa9;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	buffer[offset++] = 0x2f;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	unsigned char buffer2[6];
	int offset2 = 0;

	buffer2[offset2++] = 0xa9;
	buffer2[offset2++] = 0x00;
	*reinterpret_cast<int*>(buffer2 + offset2) = Id;
	offset2 += sizeof(int);
	buffer2[offset2++] = 0x17;
	IPacket* packet2 = _proxy->CreatePacket(buffer2, offset2);
	_proxy->RelayDataToClient(packet2, this);
	delete packet2;
}

void Condom::Resynch()
{
	unsigned char buffer[9];

	buffer[0] = 0x4b;
	*reinterpret_cast<int*>(buffer + 1) = 0;
	*reinterpret_cast<int*>(buffer + 5) = _hero.id;

	IPacket* packet = _proxy->CreatePacket(buffer, sizeof(buffer));
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

int Condom::typeAttack(int attack)
{
	switch(attack){ // 0=attack, 1=defend, 2=summon, 3=passive, 4=curse, 5=utility
	 case 6: return 0; break;
	 case 7: return 0; break;
	 case 8: return 4; break;
	 case 9: return 3; break;
	 case 10: return 0; break;
	 case 11: return 0; break;
	 case 12: return 0; break;
	 case 13: return 3; break;
	 case 14: return 0; break;
	 case 15: return 0; break;
	 case 16: return 0; break;
	 case 17: return 4; break;
	 case 18: return 3; break;
	 case 19: return 0; break;
	 case 20: return 0; break;
	 case 21: return 0; break;
	 case 22: return 0; break;
	 case 23: return 3; break;
	 case 24: return 0; break;
	 case 25: return 0; break;
	 case 26: return 0; break;
	 case 27: return 0; break;
	 case 28: return 2; break;//
	 case 29: return 3; break;
	 case 30: return 0; break;
	 case 31: return 0; break;
	 case 32: return 2; break;//
	 case 33: return 3; break;
	 case 34: return 0; break;
	 case 35: return 0; break;
	 case 36: return 0; break;
	 case 37: return 3; break;
	 case 38: return 0; break;
	 case 39: return 0; break;
	 case 40: return 1; break;
	 case 41: return 0; break;
	 case 42: return 0; break;
	 case 43: return 5; break;
	 case 44: return 0; break;
	 case 45: return 0; break;
	 case 46: return 0; break;
	 case 47: return 0; break;
	 case 48: return 0; break;
	 case 49: return 0; break;
	 case 50: return 1; break;
	 case 51: return 0; break;
	 case 52: return 0; break;
	 case 53: return 0; break;
	 case 54: return 5; break;
	 case 55: return 0; break;
	 case 56: return 0; break;
	 case 57: return 0; break;
	 case 58: return 1; break;
	 case 59: return 0; break;
	 case 60: return 0; break;
	 case 61: return 3; break;
	 case 62: return 2; break;//
	 case 63: return 0; break;
	 case 64: return 0; break;
	 case 65: return 3; break;
	 case 66: return 4; break;
	 case 67: return 0; break;
	 case 68: return 1; break;
	 case 69: return 3; break;
	 case 70: return 2; break;//
	 case 71: return 4; break;
	 case 72: return 4; break;
	 case 73: return 5; break;
	 case 74: return 0; break;
	 case 75: return 2; break;//
	 case 76: return 4; break;//
	 case 77: return 4; break;
	 case 78: return 5; break;//
	 case 79: return 3; break;
	 case 80: return 2; break;//
	 case 81: return 4; break;
	 case 82: return 4; break;
	 case 83: return 0; break;
	 case 84: return 0; break;
	 case 85: return 2; break;//
	 case 86: return 4; break;
	 case 87: return 4; break;
	 case 88: return 5; break;//
	 case 89: return 3; break;
	 case 90: return 2; break;//
	 case 91: return 4; break;
	 case 92: return 0; break;
	 case 93: return 0; break;
	 case 94: return 2; break;//
	 case 95: return 2; break;//
	 case 96: return 0; break;
	 case 97: return 0; break;
	 case 98: return 1; break;
	 case 99: return 1; break;
	 case 100: return 1; break;
	 case 101: return 0; break;
	 case 102: return 0; break;
	 case 103: return 1; break;
	 case 104: return 1; break;
	 case 105: return 1; break;
	 case 106: return 0; break;
	 case 107: return 0; break;
	 case 108: return 5; break;
	 case 109: return 1; break;
	 case 110: return 1; break;
	 case 111: return 0; break;
	 case 112: return 0; break;
	 case 113: return 5; break;
	 case 114: return 5; break;
	 case 115: return 5; break;
	 case 116: return 0; break;
	 case 117: return 1; break;
	 case 118: return 0; break;
	 case 119: return 0; break;
	 case 120: return 5; break;
	 case 121: return 0; break;
	 case 122: return 5; break;
	 case 123: return 5; break;
	 case 124: return 5; break;
	 case 125: return 5; break;
	 case 126: return 0; break;
	 case 127: return 3; break;
	 case 128: return 3; break;
	 case 129: return 3; break;
	 case 130: return 5; break;
	 case 131: return 5; break;
	 case 132: return 5; break;
	 case 133: return 0; break;
	 case 134: return 3; break;
	 case 135: return 3; break;
	 case 136: return 3; break;
	 case 137: return 5; break;
	 case 138: return 1; break;
	 case 139: return 0; break;
	 case 140: return 0; break;
	 case 141: return 3; break;
	 case 142: return 5; break;
	 case 143: return 0; break;
	 case 144: return 0; break;
	 case 145: return 3; break;
	 case 146: return 5; break;
	 case 147: return 0; break;
	 case 148: return 3; break;
	 case 149: return 1; break;
	 case 150: return 5; break;//
	 case 151: return 0; break;
	 case 152: return 0; break;
	 case 153: return 3; break;
	 case 154: return 1; break;
	 case 155: return 1; break;
	 case 221: return 2; break;//
	 case 222: return 2; break;//
	 case 223: return 5; break;
	 case 224: return 5; break;
	 case 225: return 0; break;
	 case 226: return 2; break;//
	 case 227: return 2; break;//
	 case 228: return 5; break;
	 case 229: return 0; break;
	 case 230: return 0; break;
	 case 231: return 2; break;//
	 case 232: return 3; break;
	 case 233: return 0; break;
	 case 234: return 0; break;
	 case 235: return 1; break;
	 case 236: return 2; break;//
	 case 237: return 2; break;//
	 case 238: return 5; break;
	 case 239: return 0; break;
	 case 240: return 0; break;
	 case 241: return 2; break;
	 case 242: return 0; break;
	 case 243: return 0; break;
	 case 244: return 0; break;
	 case 245: return 0; break;
	 case 246: return 2; break;//
	 case 247: return 2; break;//
	 case 248: return 0; break;
	 case 249: return 0; break;
	 case 250: return 0; break;
	 case 251: return 0; break;
	 case 252: return 3; break;
	 case 253: return 0; break;
	 case 254: return 0; break;
	 case 255: return 0; break;
	 case 256: return 0; break;
	 case 257: return 0; break;
	 case 258: return 5; break;
	 case 259: return 0; break;
	 case 260: return 0; break;
	 case 261: return 2; break;
	 case 262: return 2; break;
	 case 263: return 3; break;
	 case 264: return 5; break;
	 case 265: return 0; break;
	 case 266: return 1; break;
	 case 267: return 1; break;
	 case 268: return 2; break;//
	 case 269: return 0; break;
	 case 270: return 0; break;
	 case 271: return 2; break;
	 case 272: return 2; break;
	 case 273: return 0; break;
	 case 274: return 0; break;
	 case 275: return 0; break;
	 case 276: return 2; break;
	 case 277: return 1; break;
	 case 278: return 5; break;
	 case 279: return 2; break;//
	 case 280: return 0; break;
		 }
	 return 6;
}

const char* Condom::convertAttack(int attack)
{
	switch(attack){
	 case 0: return "Attack"; break;
	 case 1: return "Kick"; break;
	 case 2: return "Throw"; break;
	 case 3: return "Unsummon"; break;
	 case 4: return "Left Hand Throw"; break;
	 case 5: return "Left Hand Swing"; break;
	 case 6: return "Magic Arrow"; break;
	 case 7: return "Fire Arrow"; break;
	 case 8: return "Inner Sight"; break;
	 case 9: return "Critical Strike"; break;
	 case 10: return "Jab"; break;
	 case 11: return "Cold Arrow"; break;
	 case 12: return "Multiple Shot"; break;
	 case 13: return "Dodge"; break;
	 case 14: return "Power Strike"; break;
	 case 15: return "Poison Javelin"; break;
	 case 16: return "Exploding Arrow"; break;
	 case 17: return "Slow Missiles"; break;
	 case 18: return "Avoid"; break;
	 case 19: return "Impale"; break;
	 case 20: return "Lightning Bolt"; break;
	 case 21: return "Ice Arrow"; break;
	 case 22: return "Guided Arrow"; break;
	 case 23: return "Penetrate"; break;
	 case 24: return "Charged Strike"; break;
	 case 25: return "Plague Javelin"; break;
	 case 26: return "Strafe"; break;
	 case 27: return "Immolation Arrow"; break;
	 case 28: return "Decoy"; break;//
	 case 29: return "Evade"; break;
	 case 30: return "Fend"; break;
	 case 31: return "Freezing Arrow"; break;
	 case 32: return "Valkyrie"; break;//
	 case 33: return "Pierce"; break;
	 case 34: return "Lightning Strike"; break;
	 case 35: return "Lightning Fury"; break;
	 case 36: return "Fire Bolt"; break;
	 case 37: return "Warmth"; break;
	 case 38: return "Charged Bolt"; break;
	 case 39: return "Ice Bolt"; break;
	 case 40: return "Frozen Armor"; break;
	 case 41: return "Inferno"; break;
	 case 42: return "Static Field"; break;
	 case 43: return "Telekinesis"; break;
	 case 44: return "Frost Nova"; break;
	 case 45: return "Ice Blast"; break;
	 case 46: return "Blaze"; break;
	 case 47: return "Fire Ball"; break;
	 case 48: return "Nova"; break;
	 case 49: return "Lightning"; break;
	 case 50: return "Shiver Armor"; break;
	 case 51: return "Fire Wall"; break;
	 case 52: return "Enchant"; break;
	 case 53: return "Chain Lightning"; break;
	 case 54: return "Teleport"; break;
	 case 55: return "Glacial Spike"; break;
	 case 56: return "Meteor"; break;
	 case 57: return "Thunder Storm"; break;
	 case 58: return "Energy Shield"; break;
	 case 59: return "Blizzard"; break;
	 case 60: return "Chilling Armor"; break;
	 case 61: return "Fire Mastery"; break;
	 case 62: return "Hydra"; break;//
	 case 63: return "Lightning Mastery"; break;
	 case 64: return "Frozen Orb"; break;
	 case 65: return "Cold Mastery"; break;
	 case 66: return "Amplify Damage"; break;
	 case 67: return "Teeth"; break;
	 case 68: return "Bone Armor"; break;
	 case 69: return "Skeleton Mastery"; break;
	 case 70: return "Skeleton"; break;//
	 case 71: return "Dim Vision"; break;
	 case 72: return "Weaken"; break;
	 case 73: return "Poison Dagger"; break;
	 case 74: return "Corpse Explosion"; break;
	 case 75: return "Clay Golem"; break;//
	 case 76: return "Iron Maiden"; break;//
	 case 77: return "Terror"; break;
	 case 78: return "Bone Wall"; break;//
	 case 79: return "Golem Mastery"; break;
	 case 80: return "Skeletal Mage"; break;//
	 case 81: return "Confuse"; break;
	 case 82: return "Life Tap"; break;
	 case 83: return "Poison Explosion"; break;
	 case 84: return "Bone Spear"; break;
	 case 85: return "Blood Golem"; break;//
	 case 86: return "Attract"; break;
	 case 87: return "Decrepify"; break;
	 case 88: return "Bone Prison"; break;//
	 case 89: return "Summon Resist"; break;
	 case 90: return "Iron Golem"; break;//
	 case 91: return "Lower Resist"; break;
	 case 92: return "Poison Nova"; break;
	 case 93: return "Bone Spirit"; break;
	 case 94: return "Fire Golem"; break;//
	 case 95: return "Revive"; break;//
	 case 96: return "Sacrifice"; break;
	 case 97: return "Smite"; break;
	 case 98: return "Might"; break;
	 case 99: return "Prayer"; break;
	 case 100: return "Resist Fire"; break;
	 case 101: return "Holy Bolt"; break;
	 case 102: return "Holy Fire"; break;
	 case 103: return "Thorns"; break;
	 case 104: return "Defiance"; break;
	 case 105: return "Resist Cold"; break;
	 case 106: return "Zeal"; break;
	 case 107: return "Charge"; break;
	 case 108: return "Blessed Aim"; break;
	 case 109: return "Cleansing"; break;
	 case 110: return "Resist Lightning"; break;
	 case 111: return "Vengeance"; break;
	 case 112: return "Blessed Hammer"; break;
	 case 113: return "Concentration"; break;
	 case 114: return "Holy Freeze"; break;
	 case 115: return "Vigor"; break;
	 case 116: return "Conversion"; break;
	 case 117: return "Holy Shield"; break;
	 case 118: return "Holy Shock"; break;
	 case 119: return "Sanctuary"; break;
	 case 120: return "Meditation"; break;
	 case 121: return "Fist of Heavens"; break;
	 case 122: return "Fanaticism"; break;
	 case 123: return "Conviction"; break;
	 case 124: return "Redemption"; break;
	 case 125: return "Salvation"; break;
	 case 126: return "Bash"; break;
	 case 127: return "Sword Mastery"; break;
	 case 128: return "Axe Mastery"; break;
	 case 129: return "Mace Mastery"; break;
	 case 130: return "Howl"; break;
	 case 131: return "Find Potion"; break;
	 case 132: return "Leap"; break;
	 case 133: return "Double Swing"; break;
	 case 134: return "Pole Arm Mastery"; break;
	 case 135: return "Throwing Mastery"; break;
	 case 136: return "Spear Mastery"; break;
	 case 137: return "Taunt"; break;
	 case 138: return "Shout"; break;
	 case 139: return "Stun"; break;
	 case 140: return "Double Throw"; break;
	 case 141: return "Increased Stamina"; break;
	 case 142: return "Find Item"; break;
	 case 143: return "Leap Attack"; break;
	 case 144: return "Concentrate"; break;
	 case 145: return "Iron Skin"; break;
	 case 146: return "Battle Cry"; break;
	 case 147: return "Frenzy"; break;
	 case 148: return "Increased Speed"; break;
	 case 149: return "Battle Orders"; break;
	 case 150: return "Grim Ward"; break;//
	 case 151: return "Whirlwind"; break;
	 case 152: return "Berserk"; break;
	 case 153: return "Natural Resist"; break;
	 case 154: return "War Cry"; break;
	 case 155: return "Battle Command"; break;
	 case 221: return "Raven"; break;//
	 case 222: return "Plague Poppy"; break;//
	 case 223: return "Wearwolf"; break;
	 case 224: return "Shape Shifting"; break;
	 case 225: return "Firestorm"; break;
	 case 226: return "Oak Sage"; break;//
	 case 227: return "Spirit Wolf"; break;//
	 case 228: return "Wearbear"; break;
	 case 229: return "Molten Boulder"; break;
	 case 230: return "Arctic Blast"; break;
	 case 231: return "Carrion Vine"; break;//
	 case 232: return "Feral Rage"; break;
	 case 233: return "Maul"; break;
	 case 234: return "Eruption"; break;
	 case 235: return "Cyclone Armor"; break;
	 case 236: return "Heart of the Wolverine"; break;//
	 case 237: return "Dire Wolf"; break;//
	 case 238: return "Rabies"; break;
	 case 239: return "Fire Claws"; break;
	 case 240: return "Twister"; break;
	 case 241: return "Vines"; break;
	 case 242: return "Hunger"; break;
	 case 243: return "Shock Wave"; break;
	 case 244: return "Volcano"; break;
	 case 245: return "Tornado"; break;
	 case 246: return "Spirit of Barbs"; break;//
	 case 247: return "Grizzly Bear"; break;//
	 case 248: return "Fury"; break;
	 case 249: return "Armageddon"; break;
	 case 250: return "Hurricane"; break;
	 case 251: return "Fire Trauma"; break;
	 case 252: return "Claw Mastery"; break;
	 case 253: return "Psychic Hammer"; break;
	 case 254: return "Tiger Strike"; break;
	 case 255: return "Dragon Talon"; break;
	 case 256: return "Shock Field"; break;
	 case 257: return "Blade Sentinel"; break;
	 case 258: return "Burst of Speed"; break;
	 case 259: return "Fists of Fire"; break;
	 case 260: return "Dragon Claw"; break;
	 case 261: return "Charged Sentry"; break;
	 case 262: return "Wake Fire Sentry"; break;
	 case 263: return "Weapon Block"; break;
	 case 264: return "Cloak of Shadows"; break;
	 case 265: return "Cobra Strike"; break;
	 case 266: return "Blade Fury"; break;
	 case 267: return "Fade"; break;
	 case 268: return "Shadow Warrior"; break;//
	 case 269: return "Claws of Thunder"; break;
	 case 270: return "Dragon Tail"; break;
	 case 271: return "Lightning Sentry"; break;
	 case 272: return "Inferno Sentry"; break;
	 case 273: return "Mind Blast"; break;
	 case 274: return "Blades of Ice"; break;
	 case 275: return "Dragon Flight"; break;
	 case 276: return "Death Sentry"; break;
	 case 277: return "Blade Shield"; break;
	 case 278: return "Venom"; break;
	 case 279: return "Shadow Master"; break;//
	 case 280: return "Royal Strike"; break;
	 default: return "Something Lame"; break;
	}
}
void Condom::SelectSkill(int skillId)
{
	unsigned char buffer[9];
	int offset = 0;

	buffer[offset++] = 0x3c;
	*reinterpret_cast<short*>(buffer + offset) = skillId;
	offset += sizeof(short);
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::teleTarg(short x,short y)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x03;
	*reinterpret_cast<short*>(buffer + offset) = x;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = y;
	offset += sizeof(short);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Condom::teleCast(short x,short y)
{
	unsigned char buffer[11];
	int offset = 0;

	buffer[offset++] = 0x15;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = _hero.id;
	offset += sizeof(int);
	*reinterpret_cast<short*>(buffer + offset) = x;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = y;
	offset += sizeof(short);
	buffer[offset++] = 0x01;

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}

void Condom::squelch(int Id)
{
	unsigned char buffer[7];
	int offset = 0;

	buffer[offset++] = 0x5d;
	buffer[offset++] = 0x03;
	buffer[offset++] = 0x01;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}

void Condom::invAdd(int id, iType type, bool belt){
	bool found=false;
	if(belt){
		for (std::list<invItem>::iterator i = _belt.begin(); i != _belt.end(); i++)
			if(id==i->id)
				found=true;
	}
	else{
		for (std::list<invItem>::iterator i = _inventory.begin(); i != _inventory.end(); i++)
			if(id==i->id)
				found=true;
	}
	if(!found){
		invItem thisInv;
		thisInv.id=id;
		thisInv.type=type;
		if(belt)
			invRem(id);
		belt ? _belt.push_back(thisInv) : _inventory.push_back(thisInv);
		//belt ? Chat(_chatName,false,"%u added to belt database.",id) : Chat(_chatName,false,"%u added to inventory database.",id);
		switch(type){
			case hPot: _redEmpty=false; break;
			case mPot: _blueEmpty=false; break;
			case jPot: _purpleEmpty=false; break;
			default: break;
		}
	}
}

void Condom::invRem(int id){
	for (std::list<invItem>::iterator i = _inventory.begin(); i != _inventory.end(); i++)
		if(id==i->id){
			//Chat(_chatName,false,"%u removed from inventory database.",i->id);
			_inventory.erase(i);
			break;
		}
	for (std::list<invItem>::iterator i = _belt.begin(); i != _belt.end(); i++)
		if(id==i->id){
			//Chat(_chatName,false,"%u removed from belt database.",i->id);
			_belt.erase(i);
			break;
		}
}

bool Condom::invSearch(iType type, bool includeInv, bool*useInventory, int*id){
	bool found=false;
	if(includeInv){ //Only check inventory if it's included
		for (std::list<invItem>::iterator i = _inventory.begin(); i != _inventory.end(); i++){
			if(i->type==type){
				*id=i->id;
				*useInventory=true;
				found=true;
			}
		}
	}
	if(!found){ //check belt AFTER inventory
		for (std::list<invItem>::iterator i = _belt.begin(); i != _belt.end(); i++){
			if(i->type==type){
				*id=i->id;
				*useInventory=false;
				found=true;
			}
		}
	}
	return found;
}