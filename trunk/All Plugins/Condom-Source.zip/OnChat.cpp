#include "Condom.h"
#include "Command.h"

/* This function will detect what you typed and process it */
bool Condom::OnChat(const char* text)
{
	Command command(text);
	const char* commandName = command.GetParameter(0);
	const char* param1;
	if(command.GetParameterCount()>1)
		param1 = command.GetParameter(1);
	if (_stricmp(commandName, ".who") == 0)
	{
		listPlayers();
		return true;
	}
	if (_stricmp(commandName, ".flash") == 0)
	{
		if(command.GetParameterCount()>1)
		{
			for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
			{
				if(!strcmp(p->nRef,param1) || !strcmp(p->name,param1))
				{
					if(p->here)
					switch(p->flashTarget){
						case true:{ p->flashTarget=false; _flashing--; Chat(_chatName, false, "�c1%s: �c5Flash Off",p->name);} break;
						case false:{ p->flashTarget=true; _flashing++; Chat(_chatName, false, "�c1%s: �c8Harassing Flash",p->name);} break;
						}
				}
			}
			if(!strcmp("all",param1))
			{
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(p->id!=_hero.id && p->here)
					switch(p->flashTarget){
						//case true:{ Chat(_chatName, false, "�c1%s: �c8Harassing Flash",p->name);} break;
						case false:{ p->flashTarget=true; _flashing++; Chat(_chatName, false, "�c1%s: �c8Harassing Flash",p->name);} break;
						}
				}
			}
			if(!strcmp("off",param1))
			{
				for (std::list<Player>::iterator p = _players.begin(); p != _players.end(); p++)
				{
					if(p->here)
					switch(p->flashTarget){
						case true:{ p->flashTarget=false; _flashing--; Chat(_chatName, false, "�c1%s: �c5Flash Off",p->name);} break;
						//case false:{ Chat(_chatName, false, "�c1%s: �c5Flash Off",p->name);} break;
						}
				}
			}
		}
		else
			Chat(_chatName, false, "�c1Whom?");
		return true;
	}
	if (_stricmp(commandName, ".ninja") == 0)
		SelectSkill(666);
	if (_stricmp(commandName, ".settings") == 0)
	{
		showSet();
		return true;
	}
	if (_stricmp(commandName, ".resynch") == 0)
	{
		Resynch();
		return true;
	}
	/*if (_stricmp(commandName, ".view") == 0)
	{
		spoofTrade(_currentTargetName,_currentTarget);
		_viewing=true;
		return true;
	}*/
	if (_stricmp(commandName, ".display") == 0)
	{
		if(!_displayStatus)
		{
			Chat(_chatName, false, "�c1DisplayStatus: �c8On");
			_displayStatus=true;
		}
		else
		{
			Chat(_chatName, false, "�c1DisplayStatus: �c8Off");
			_displayStatus=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".filter") == 0)
	{
		if(!_spamFilter)
		{
			Chat(_chatName, false, "�c1SpamFilter: �c8On");
			_spamFilter=true;
		}
		else
		{
			Chat(_chatName, false, "�c1SpamFilter: �c8Off");
			_spamFilter=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".list") == 0)
	{
		if(!_shit)
		{
			Chat(_chatName, false, "�c1ListPKs: �c8On");
			_shit=true;
		}
		else
		{
			Chat(_chatName, false, "�c1ListPKs: �c8Off");
			_shit=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".party") == 0)
	{
		if(!_aParty)
		{
			Chat(_chatName, false, "�c1AutoParty: �c8On");
			_aParty=true;
		}
		else
		{
			Chat(_chatName, false, "�c1AutoParty: �c8Off");
			_aParty=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".ctown") == 0)
	{
		if(!_chickenTown)
		{
			Chat(_chatName, false, "�c1ChickenToTown: �c8On");
			_chickenTown=true;
		}
		else
		{
			Chat(_chatName, false, "�c1ChickenToTown: �c8Off");
			_chickenTown=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".cexit") == 0)
	{
		if(!_chickenExit)
		{
			Chat(_chatName, false, "�c1ChickenExit: �c8On");
			_chickenExit=true;
		}
		else
		{
			Chat(_chatName, false, "�c1ChickenExit: �c8Off");
			_chickenExit=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".townim") == 0)
	{
		if(!_townIron)
		{
			Chat(_chatName, false, "�c1TownOnIronMaiden: �c8On");
			_townIron=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TownOnIronMaiden: �c8Off");
			_townIron=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".townmim") == 0)
	{
		if(!_townMercIron)
		{
			Chat(_chatName, false, "�c1TownOnMercIronMaiden: �c8On");
			_townMercIron=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TownOnMercIronMaiden: �c8Off");
			_townMercIron=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".townh") == 0)
	{
		if(!_townHostile)
		{
			Chat(_chatName, false, "�c1TownOnHostile: �c8On");
			_townHostile=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TownOnHostile: �c8Off");
			_townHostile=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".townd") == 0)
	{
		if(!_townDirect)
		{
			Chat(_chatName, false, "�c1TownOnDirectAttack: �c8On");
			_townDirect=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TownOnDirectAttack: �c8Off");
			_townDirect=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".townc") == 0)
	{
		if(!_townCoord)
		{
			Chat(_chatName, false, "�c1TownOnCOORDAttack: �c8On");
			_townCoord=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TownOnCOORDAttack: �c8Off");
			_townCoord=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".tppk") == 0)
	{
		if(!_TPPK)
		{
			Chat(_chatName, false, "�c1TPPKmode: �c8On");
			_TPPK=true;
		}
		else
		{
			Chat(_chatName, false, "�c1TPPKmode: �c8Off");
			_TPPK=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".drink") == 0)
	{
		if(!_drinker)
		{
			Chat(_chatName, false, "�c1AutoPot: �c8On");
			_drinker=true;
		}
		else
		{
			Chat(_chatName, false, "�c1AutoPot: �c8Off");
			_drinker=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".parse") == 0)
	{
		if(!_parseText)
		{
			Chat(_chatName, false, "�c1ParseChatText: �c8On");
			_parseText=true;
		}
		else
		{
			Chat(_chatName, false, "�c1ParseChatText: �c8Off");
			_parseText=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".boss") == 0)
	{
		if(!_bossTalk)
		{
			Chat(_chatName, false, "�c1BossAttackMessages: �c8On");
			_bossTalk=true;
		}
		else
		{
			Chat(_chatName, false, "�c1BossAttackMessages: �c8Off");
			_bossTalk=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".pecho") == 0)
	{
		if(!_pecho)
		{
			Chat(_chatName, false, "�c1PotionMessages: �c8On");
			_pecho=true;
		}
		else
		{
			Chat(_chatName, false, "�c1PotionMessages: �c8Off");
			_pecho=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".secho") == 0)
	{
		if(!_secho)
		{
			Chat(_chatName, false, "�c1StatusMessages: �c8On");
			_secho=true;
		}
		else
		{
			Chat(_chatName, false, "�c1StatusMessages: �c8Off");
			_secho=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".lecho") == 0)
	{
		if(!_lecho)
		{
			Chat(_chatName, false, "�c1LevelMessages: �c8On");
			_lecho=true;
		}
		else
		{
			Chat(_chatName, false, "�c1LevelMessages: �c8Off");
			_lecho=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".wecho") == 0)
	{
		if(!_wecho)
		{
			Chat(_chatName, false, "�c1WarningMessages: �c8On");
			_wecho=true;
		}
		else
		{
			Chat(_chatName, false, "�c1WarningMessages: �c8Off");
			_wecho=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".chide") == 0)
	{
		if(!_cHide)
		{
			Chat(_chatName, false, "�c1HideCorpses: �c8On");
			_cHide=true;
		}
		else
		{
			Chat(_chatName, false, "�c1HideCorpses: �c8Off");
			_cHide=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".block") == 0)
	{
		if(!_blockFlash)
		{
			Chat(_chatName, false, "�c1FlashProtection: �c8On");
			_blockFlash=true;
		}
		else
		{
			Chat(_chatName, false, "�c1FlashProtection: �c8Off");
			_blockFlash=false;
		}
		return true;
	}
	if (_stricmp(commandName, ".clife") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1ChickenLife: �c8%s percent",param1);
		_chickenHealth=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".elife") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1ExitLife: �c8%s percent",param1);
		_exitHealth=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".drinkd") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1Drink Delay: �c8%s milliseconds",param1);
		drink_delay=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".plife") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1HealthPotLife: �c8%s percent",param1);
		_lifepot=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".pmana") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1ManaPotMana: �c8%s percent",param1);
		_manapot=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".pjuve") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1RejuvePotLife: �c8%s percent",param1);
		_juvepot=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".mlife") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1MercHealthPotLife: �c8%s percent",param1);
		merc_life=atoi(param1);
		return true;
	}
	if (_stricmp(commandName, ".mjuve") == 0 && command.GetParameterCount()>1)
	{
		Chat(_chatName, false, "�c1MercRejuvePotLife: �c8%s percent",param1);
		merc_juve=atoi(param1);
		return true;
	}
	return false;
}