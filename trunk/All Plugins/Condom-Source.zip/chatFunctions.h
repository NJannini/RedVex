#include "IProxy.h"
#include "IPacket.h"
#include <stdarg.h>
#include "Condom.h"
/*								Chat(name,true/false,text):
	This function writes text to -only your screen-.  Text appears to have been said by
	name.  It can be a whisper(true) or regular(false) text.  This text can be colored.
*/
void Chat(const char* name, bool whisper, const char* format, ...);

/*								OverheadDisplay(id,type,text):
	This function writes text to -only your screen- above game objects.  You must supply
	object's id, type, and text string.  This text can be colored.
	types:
	0x00 = Player
	0x01 = NPC
	0x02 = Object's like stash, TP, shrines, chests, WP, ETC
	0x04 = (?)Items(?)
	0x05 = Doorway
*/
void OverheadDisplay(int id, int type, const char* text);

/*								Speak(text):
	This function makes your character send text to the screen.  Text appears to all players,
	and cannot be colored.
*/
void Speak(const char* text);

/*								Whisper(name,text):
	This function makes your character send text to another player via @name whisper.  Cannot 
	be colored.
*/
void Whisper(const char* name, const char* text);

/*								Overhead(text):
	This function makes your character send text to an overhead message.  Text appears to all
	players, and cannot be colored.
*/
void Overhead(const char* text);

/*								Talk(id):
	This function sends sound bytes to play to other players in the game.  Parameter id must
	specify a valid d2 sound.
*/
void Talk(short id);

void Chat(const char* name, bool whisper, const char* format, ...)
{
	char text[4096];

	va_list arguments;
	va_start(arguments, format);
	vsprintf_s(text, sizeof(text), format, arguments);
	va_end(arguments);	

	int length = static_cast<int>(strlen(text) + strlen(name)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = whisper ? 0x02 : 0x01;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = whisper ? 0x01 : 0x05;

	for (int i = 0; name[i] != '\0'; i++)
	{
		buffer[offset++] = name[i];
	}
	buffer[offset++] = 0x00;

	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	}
	buffer[offset++] = 0x00;

	IPacket* packet = Condom::_proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}

void OverheadDisplay(int id, int type, const char* text)
{
	int length = static_cast<int>(strlen(text)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = 0x05;
	buffer[offset++] = 0x00;
	buffer[offset++] = type;
	*reinterpret_cast<int*>(buffer + offset) = Id;
	offset += sizeof(int);
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;

	buffer[offset++] = 0x00;
	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	};
	buffer[offset++] = 0x00;
	
	IPacket* packet = _proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}

void Speak(const char* text)
{
	if (strlen(text) > 0)
	{
		int size = static_cast<int>(strlen(text)) + 6;
		char* buffer = new char[size];
		int offset = 0;

		buffer[offset++] = 0x15;
		buffer[offset++] = 0x01;
		buffer[offset++] = 0x00;

		for (int i = 0; text[i] != '\0'; i++)
		{
			buffer[offset++] = text[i];
		}
		buffer[offset++] = 0x00;

		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, size);
		_proxy->RelayDataToServer(packet, this);
		delete packet;

		delete[] buffer;
	}
}

void Whisper(const char* name, const char* text)
{
	if (strlen(text) > 0 && strlen(name) > 0)
	{
		int size = static_cast<int>(strlen(text)) + static_cast<int>(strlen(name)) + 6;
		char* buffer = new char[size];
		int offset = 0;

		buffer[offset++] = 0x15;
		buffer[offset++] = 0x02;
		buffer[offset++] = 0x00;

		for (int i = 0; name[i] != '\0'; i++)
		{
			buffer[offset++] = name[i];
		}
		buffer[offset++] = 0x00;
		for (int i = 0; text[i] != '\0'; i++)
		{
			buffer[offset++] = text[i];
		}
		buffer[offset++] = 0x00;

		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, size);
		_proxy->RelayDataToServer(packet, this);
		delete packet;

		delete[] buffer;
	}
}

void Overhead(const char* text)
{
	if (strlen(text) > 0)
	{
		int size = static_cast<int>(strlen(text)) + 6;
		char* buffer = new char[size];
		int offset = 0;

		buffer[offset++] = 0x14;
		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		for (int i = 0; text[i] != '\0'; i++)
		{
			buffer[offset++] = text[i];
		}

		buffer[offset++] = '\0';
		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, size);
		_proxy->RelayDataToServer(packet, this);
		delete packet;

		delete[] buffer;
	}
}

void Talk(short id)
{
	int offset = 0;
	unsigned char buffer[3];
	buffer[offset++] = 0x3F;
	*reinterpret_cast<short*>(buffer+offset) = id;
	offset+= sizeof(short);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}