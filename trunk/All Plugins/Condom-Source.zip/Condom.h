#pragma once
#include "IModule.h"
#include <list>
#include <map>
#include "Item.h"
#pragma comment(lib, "WS2_32.lib")
#include <windows.h>

class Condom :
	public IModule
{
public:
	Condom(IProxy* proxy);
	//~Condom();

	void _stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void _stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void _stdcall Update();
	void _stdcall Destroy();

private:
	enum ChickenState
	{
		ChickenState_InTown,
		ChickenState_Ready,
		ChickenState_OpeningTp,
		ChickenState_UsingTp
	};
	
	struct Skill
	{
		char name[100];
		int owner;
		int base;
		int bonus;
		int level;
		int type;
	};

	struct Player
	{
		std::list<Skill> skills;	
		char name[16];
		char account[16];
		char nRef[16];
		char aRef[16];
		char type[12];
		char lastSpoken[4138];
		int spoken;
		int level;
		int id;
		int typeId;
		int lifeP;
		int joinNum;
		DWORD _lastFlash;
		bool flashTarget;
		bool inTown;
		bool shithead;
		bool visible;
		bool here;
		bool isHostile;
		short xPos;
		short yPos;
		short party;
		short status; //0=neutral, 1=partied, 2=hostile
		//item _helm,_armor,_ammy,_rring,_lring,_rhand,_lhand,_boots,_belt,_gloves;
	};

	struct TownStruct
	{
		short id;
		short minX;
		short minY;
		short maxX;
		short maxY;
	};

	enum StatType
	{
      Strength,
      Energy,
      Dexterity,
      Vitality,
      StatPoints,
      SkillPoints,
      Life,
      MaxLife,
      Mana,
      MaxMana,
      Stamina,
      MaxStamina,
      Level,
      Experience,
      Gold,
      GoldBank,
      DefensePercent,
      MaxDamagePercent,
      MinDamagePercent,
      ToHit,
      ToBlock,
      MinDamage,
      MaxDamage,
      SecondaryMinDamage,
      SecondaryMaxDamage,
      DamagePercent,
      ManaRecovery,
      ManaRecoveryBonus,
      StaminaRecoveryBonus,
      LastExperience,
      NextExperience,
      ArmorClass,
      ArmorClassVsMissile,
      ArmorClassVsMelee,
      DamageReduction,
      MagicDamageReduction,
      DamageResist,
      MagicResist,
      MaxMagicResist,
      FireResist,
      MaxFireResist,
      LightResist,
      MaxLightResist,
      ColdResist,
      MaxColdResist,
      PoisonResist,
      MaxPoisonResist,
      DamageAura,
      FireMinDamage,
      FireMaxDamage,
      LightMinDamage,
      LightMaxDamage,
      MagicMinDamage,
      MagicMaxDamage,
      ColdMinDamage,
      ColdMaxDamage,
      ColdLength,
      PoisonMinDamage,
      PoisonMaxDamage,
      PoisonLength,
      LifeDrainMinDamage,
      LifeDrainMaxDamage,
      ManaDrainMinDamage,
      ManaDrainMaxDamage,
      StamDrainMinDamage,
      StamDrainMaxDamage,
      StunLength,
      VelocityPercent,
      AttackRate,
      OtherAnimRate,
      Quantity,
      Value,
      Durability,
      MaxDurability,
      LifeRegen,
      MaxDurabilityPercent,
      MaxLifePercent,
      MaxManaPercent,
      AttackerTakesDamage,
      GoldFind,
      MagicFind,
      Knockback,
      TimeDuration,
      ClassSkillsBonus,
      UnsentParam1,
      AddExperience,
      HealAfterKill,
      ReducedPrices,
      DoubleHerbDuration,
      LightRadius,
      LightColor,
      LowerRequirementsPercent,
      LowerLevelRequirement,
      FasterAttackRate,
      LowerLevelRequirementPercent,
      LastBlockFrame,
      FasterMoveVelocity,
      NonClassSkill,
      State,
      FasterHitRecovery,
      MonsterPlayerCount,
      SkillPoisonOverrideLength,
      FasterBlockRate,
      SkillBypassUndead,
      SkillBypassDemons,
      FasterCastRate,
      SkillBypassBeasts,
      SingleSkill,
      RestInPeace,
      CurseResistance,
      PoisonLengthReduction,
      NormalDamage,
      Howl,
      HitBlindsTarget,
      DamageToMana,
      IgnoreTargetDefense,
      FractionalTargetAC,
      PreventHeal,
      HalffReezeDuration,
      ToHitPercent,
      DamageTargetAC,
      DemonDamagePercent,
      UndeadDamagepercent,
      DemonToHit,
      UndeadToHit,
      Throwable,
      ElementalSkillBonus,
      AllSkillsBonus,
      AttackerTakesLightingDamage,
      IronMaidenLevel,
      LifeTapLevel,
      ThornsPercent,
      BoneArmor,
      BoneArmorMax,
      Freeze,
      OpenWounds,
      CrushingBlow,
      KickDamage,
      ManaAfterKill,
      HealAfterDemonKill,
      ExtraBlood,
      DeadlyStrike,
      AbsorbFirePercent,
      AbsorbFire,
      AbsorbLightingPercent,
      AbsorbLight,
      AbsorbMagicPercent,
      AbsorbMagic,
      AbsorbColdPercent,
      AbsorbCold,
      Slow,
      Aura,
      Indesctructible,
      CannotBeFrozen,
      StaminaDrainPercent,
      Reanimate,
      Pierce,
      MagicArrow,
      ExplosiveArrow,
      ThrowMinDamage,
      ThrowMaxDamage,
      SkillHandOfAthena,
      SkillStaminaPercent,
      SkillPassiveStaminaPercent,
      SkillConcentration,
      SkillEnchant,
      SkillPierce,
      SkillConviction,
      SkillChillingArmor,
      SkillFrenzy,
      SkillDecrepify,
      SkillArmorPercent,
      Alignment,
      Target0,
      Target1,
      GoldLost,
      ConversionLevel,
      ConversionMaxHP,
      UnitDoOverlay,
      AttackVsMonsterType,
      DamageVsMonsterType,
      Fade,
      ArmorOverridePercent,
      Unused183,
      Unused184,
      Unused185,
      Unused186,
      Unused187,
      SkillTabBonus,
      Unused189,
      Unused190,
      Unused191,
      Unused192,
      Unused193,
      Sockets,
      SkillOnAttack,
      SkillOnKill,
      SkillOnDeath,
      SkillOnStriking,
      SkillOnLevelUp,
      Unused200,
      SkillOnGetHit,
      Unused202,
      Unused203,
      ChargedSkill,
      Unused204,
      Unused205,
      Unused206,
      Unused207,
      Unused208,
      Unused209,
      Unused210,
      Unused211,
      Unused212,
      ArmorPerLevel,
      ArmorPercentPerLevel,
      LifePerLevel,
      ManaPerLevel,
      MaxDamagePerLevel,
      MaxDamagePercentPerLevel,
      StrengthPerLevel,
      DexterityPerLevel,
      EnergyPerLevel,
      VitalityPerLevel,
      ToHitPerLevel,
      ToHitPercentPerLevel,
      ColdDamageMaxPerLevel,
      FireDamageMaxPerLevel,
      LightningDamageMaxPerLevel,
      PoisonDamageMaxPerLevel,
      ResistColdPerLevel,
      ResistFirePerLevel,
      ResistLightningPerLevel,
      ResistPoisonPerLevel,
      AbsorbColdPerLevel,
      AbsorbFirePerLevel,
      AbsorbLightningPerLevel,
      AbsorbPoisonPerLevel,
      ThornsPerLevel,
      GoldFindPerLevel,
      MagicFindPerLevel,
      RegenStaminaPerLevel,
      StaminaPerLevel,
      DamageDemonPerLevel,
      DamageUndeadPerLevel,
      ToHitDemonPerLevel,
      ToHitUndeadPerLevel,
      CrushingBlowPerLevel,
      OpenWoundsPerLevel,
      KickDamagePerLevel,
      DeadlyStrikePerLevel,
      FindGemsPerLevel,
      ReplenishDurability,
      ReplenishQuantity,
      ExtraStack,
      FindItem,
      SlashDamage,
      SlashDamagePercent,
      CrushDamage,
      CrushDamagePercent,
      ThrustDamage,
      ThrustDamagePercent,
      AbsorbSlash,
      AbsorbCrush,
      AbsorbThrust,
      AbsorbSlashPercent,
      AbsorbCrushPercent,
      AbsorbThrustPercent,
      ArmorByTime,
      ArmorPercentByTime,
      LifeByTime,
      ManaByTime,
      MaxDamageByTime,
      MaxDamagePercentByTime,
      StrengthByTime,
      DexterityByTime,
      EnergyByTime,
      VitalityByTime,
      ToHitByTime,
      ToHitPercentByTime,
      ColdMaxDamageByTime,
      FireMaxDamageByTime,
      LightningMaxDamageByTime,
      PoisonMaxDamageByTime,
      ResistColdByTime,
      ResistFireByTime,
      ResistLightningByTime,
      ResistPoisonByTime,
      AbsorbColdByTime,
      AbsorbFireByTime,
      AbsorbLightningByTime,
      AbsorbPoisonByTime,
      FindGoldByTime,
      FindMagicByTime,
      RegenStaminaByTime,
      StaminaByTime,
      DamageDemonByTime,
      DamageUndeadByTime,
      ToHitDemonByTime,
      ToHitUndeadByTime,
      CrushingBlowByTime,
      OpenWoundsByTime,
      KickDamageByTime,
      DeadlyStrikeByTime,
      FindGemsByTime,
      PierceCold,
      PierceFire,
      PierceLightning,
      PiercePoison,
      DamageVsMonster,
      DamagePercentVsMonster,
      ToHitVsMonster,
      ToHitPercentVsMonster,
      DefenseVsMonster,
      DefensePercentVsMonster,
      FireLength,
      BurningMin,
      BurningMax,
      ProgressiveDamage,
      ProgressiveSteal,
      ProgressiveOther,
      ProgressiveFire,
      ProgressiveCold,
      ProgressiveLightning,
      ExtraCharges,
      ProgressiveToHit,
      PoisonCount,
      DamageFramerate,
      PierceIdx,
      PassiveFireMastery,
      PassiveLightningMastery,
      PassiveColdMastery,
      PassivePoisonMastery,
      PassiveFirePierce,
      PassiveLightningPierce,
      PassiveColdPierce,
      PassivePoisonPierce,
      PassiveCriticalStrike,
      PassiveDodge,
      PassiveAvoid,
      PassiveEvade,
      PassiveWarmth,
      PassiveMasteryMeleeToHit,
      PassiveMasteryMeleeDamage,
      PassiveMasteryMeleeCritical,
      PassiveMasteryThrowToHit,
      PassiveMasteryThrowDamage,
      PassiveMasteryThrowCritical,
      PassiveWeaponBlock,
      PassiveSummon_resist,
      ModifierListSkill,
      ModifierListLevel,
      LastSentLifePercent,
      SourceUnitType,
      SourceUnitID,
      ShortParam1,
      QuestItemDifficulty,
      PassiveMagicMastery,
      PassiveMagicPierce
   };

//New Item Management
	enum iType{
		tpScroll,		//0
		hPot,			//1
		mPot,			//2
		jPot			//3
	};
	struct invItem{
		int id;			//0
		iType type;		//1
	};
	int useId;
	bool useInventory;
	std::list<invItem> _inventory;	
	std::list<invItem> _belt;	
//End

	struct Account {
		char accountName[16];
	};

	const char* _chatName;
	item TownPortalBook;
	bool _hostile;
	bool _inStash;
	bool _justClosed;
	bool _dontSpam;
	int _joinCount;
	int _targetStage;
	int _currentTarget;
	int _targetParty;
	int _baseMaxLife;
	int _maxLife;
	int _life;
	int _safeLife;
	int _lifePercent;
	int _mana;
	int _maxMana;
	int _manaPercent;
	int _safeMana;
	int _currentArea;
	int _quantity;
	bool _hasBO;
	bool _hasOak;
	bool _hasWolf;
	bool _hasBear;
	bool _bonusOff;
	bool _redEmpty;
	bool _blueEmpty;
	bool _purpleEmpty;
	bool _joined;
	bool _viewing;
	bool _exit;
	char _currentTargetName[16];
	bool _haveMerc;
	int _mercLife;
	int _mercId;
	std::list<Player> _players;	
	std::list<Skill> _skillPool;
	std::list<Account> _filterList;
	std::list<Account> _shitList;
	std::list<Account> _shitListP;
	std::list<Player> _Leave;
	IProxy* _proxy;
	Player _hero;
	TownStruct _town;
	ChickenState _state;
	//settings values
	int _chickenHealth;
	int _chickenMerc;
	int _chickenPing;
	int _exitHealth;
	int _exitMerc;
	int _exitPing;
	int _chickenTown;
	int _chickenExit;
	int _townHostile;
	int _townDirect;
	int _townCoord;
	int _TPPK;
	int _townIron;
	int _townMercIron;
	int _parseText;
	int _parseGame;
	int _bossTalk;
	int _pecho;
	int _wecho;
	int _secho;
	int _lecho;
	int _cHide;
	int _shit;
	int _aParty;
	int _displayStatus;
	int _spamFilter;
	//autopot settings
	int _drinker;
	int _lifepot;
	int _manapot;
	int _juvepot;
	int merc_life;
	int merc_juve;
	DWORD drink_delay;
	DWORD lastDrink;
	DWORD lastMerc;
	DWORD lastLeave;
	DWORD statusPulse;
	DWORD lastChicken;
	DWORD _ping;
	DWORD _newPing;
	DWORD _lastPing;
	DWORD _lastFlash;
	int _teleSelect;
	int _dirtyFix;
	int _flashing;
	int _blockFlash;
	int _targets[8];
	bool _whirl;

	void Condom::CastTp();
	void Condom::UsePortal(int portalId);
	void Condom::UseObject(int objectType, int objectId);
	void Condom::InvInteract(int objectId);
	void Condom::BeltInteract(int objectId);
	void Condom::GiveMerc(int objectId);
	void Condom::Chat(const char* name, bool whisper, const char* format, ...);
	void Condom::OverheadDisplay(int id, int type, const char* text);
	void Condom::Speak(const char* text);
	void Condom::AddPlayer(const char* playerName, int playerLevel, int playerId, int type, bool shithead);
	void Condom::RemovePlayer(const char* playerName);
	void Condom::HostilePlayer(int playerId);
	void Condom::HostileParty();
	void Condom::UseRightSkillOnObject(int objectType, int objectId);
	void Condom::UseLeftSkillOnObject(int objectType, int objectId);
	void Condom::UseRightSkillOnLocation(short locX, short locY);
	void Condom::UseLeftSkillOnLocation(short locX, short locY);
	const char* Condom::boolToString(int b);

	bool Condom::Drink(iType type);
	bool Condom::DrinkMerc(iType type);

	void Condom::Exit();
	void Condom::freeze(int Id);
	void Condom::unfreeze(int Id);
	void Condom::showSet();
	void Condom::getFilter();
	void Condom::getShitList();
	void Condom::getShitListP();
	void Condom::shitAdd(const char*accountName);
	void Condom::shitAddP(const char*playerName);
	void Condom::listPlayers();
	const char* Condom::flashCheck(bool flashing);
	void Condom::flash(int playerId);
	void Condom::spoofTP(int state,int areaId,int Id);
	void Condom::partyInvite(int Id);
	void Condom::partyAccept(int Id);
	void Condom::markPlayer(int Id);
	void Condom::removeMark(int Id);
	void Condom::Resynch();
	int Condom::typeAttack(int attack);
	const char* Condom::convertAttack(int attack);
	void Condom::SelectSkill(int skillId);
	void Condom::teleTarg(short x,short y);
	void Condom::teleCast(short x,short y);
	void Condom::squelch(int Id);
		//NEW Autopot
	void Condom::invAdd(int id, iType type, bool belt);
	void Condom::invRem(int id);
	bool Condom::invSearch(iType type, bool includeInv, bool*useInventory, int*id);

	bool _stdcall GetChat(const char* playerName, char* accountName, short status, bool shithead, const char* text,int playerID);
	bool _stdcall OnChat(const char* text);
};
