Experior.dll

An Experience measurement plugin for RedVex by Turlok!

This plugin keeps stats about your experience and kills in a game, and estimates when you will level.

************************************************************

Installing Experior.dll:
Step 1: Put Experior.dll into your Plugins folder
Step 2: Update RedVex
Step 3: High-Five! Your done!

************************************************************

in-game commands:

.exp -> Shows you you're total experience stats and estimates when you will level.
.track -> Toggles experience tracking

NOTE: Your stats will be cleared every time you leave a game, if your doing consistant runs type .exp at the end of your run for the most realistic results.

************************************************************