#include "Autologon.h"

Autologon* Autologon::BNCS;
Autologon* Autologon::D2GS;
Autologon* Autologon::MCP;
Autologon* Autologon::Data;

string Autologon::sXMLFile;
string Autologon::sXMLSection;
string Autologon::sAccount;
string Autologon::sPass;
string Autologon::sTitle;
string Autologon::sCharacter;

HWND Autologon::hD2Wnd = NULL;
HANDLE Autologon::hLogin;
HANDLE Autologon::hCharSelect;

bool Autologon::bAutologon = false;
bool Autologon::bBNCSAuthPassed = false;
bool Autologon::bMCPAuthPassed = false;
bool Autologon::bSendLogin = false;
bool Autologon::bSelectChar = false;
bool Autologon::bInChat = false;
bool Autologon::bIconic = false;
bool Autologon::bBNCSConnected = false;
bool Autologon::bMCPConnected = false;
bool Autologon::bD2GSConnected = false;

int Autologon::iMode;
int Autologon::iSelectDelay;

List<char*> Autologon::CharList;

DWORD WINAPI LogonThread(LPVOID lpParameter)
{
	while(true)
	{			
		if( Autologon::bSendLogin == true )
		{
			//if(Autologon::hD2Wnd == NULL)
			Autologon::hD2Wnd = Autologon::Data->_auto->Window( Autologon::sTitle.c_str() );

			// Slight delay
			Sleep(1500);

			// Make sure we are connected to bncs and not connected to mcp and finally that we are not in chat yet.
			if( Autologon::bBNCSConnected == true && Autologon::bMCPConnected == false && Autologon::bInChat == false )
			{
				// Make sure we passed our checkrevision and cdkey checks.
				if(Autologon::bBNCSAuthPassed == true)
				{
					// Log ourselves in.
					Autologon::Data->_auto->SendKey( Autologon::hD2Wnd, VK_TAB );
					Autologon::Data->_auto->SendKey( Autologon::hD2Wnd, VK_DELETE );
					Autologon::Data->_auto->SendInput( Autologon::hD2Wnd, Autologon::sAccount.c_str() );
					Autologon::Data->_auto->SendKey( Autologon::hD2Wnd, VK_TAB );
					Autologon::Data->_auto->SendInput( Autologon::hD2Wnd, Autologon::sPass.c_str() );
					Autologon::Data->_auto->SendKey( Autologon::hD2Wnd, VK_RETURN );

					if(IsIconic(Autologon::hD2Wnd) != 0)
					{
						ShowWindow( Autologon::hD2Wnd , SW_HIDE );
						ShowWindow( Autologon::hD2Wnd , SW_RESTORE );
						ShowWindow( Autologon::hD2Wnd , SW_HIDE );
						Autologon::bIconic = true;
					}

					// Kill everything
					Autologon::bSendLogin = false;
					TerminateThread( Autologon::hLogin, 0 );
					CloseHandle( Autologon::hLogin );
					Sleep(50);
					return 0;
				} else {
					// Kill everything
					Autologon::bSendLogin = false;
					TerminateThread( Autologon::hLogin, 0 );
					CloseHandle( Autologon::hLogin );
					Sleep(50);
					return 0;
				}
			}
		} else {
			// Kill everything
			Autologon::bSendLogin = false;
			TerminateThread( Autologon::hLogin, 0 );
			CloseHandle( Autologon::hLogin );
			Sleep(50);
			return 0;
		}
	}
	Sleep(50);
	return 0;
}
DWORD WINAPI SelectCharThread(LPVOID lpParameter)
{
	while(true)
	{
		if( ( Autologon::bSelectChar == true ) && ( Autologon::bMCPConnected == true ) && ( Autologon::bMCPAuthPassed == true ) )
		{
			if(Autologon::hD2Wnd == NULL)
				Autologon::hD2Wnd = Autologon::Data->_auto->Window( Autologon::sTitle.c_str() );

			int iSlot = -1;
			// Sort out what character slot to click.
			iSlot = Autologon::Data->StrChar2Slot( Autologon::sCharacter.c_str() );

			// Delay some give us a chance to select a character manually.
			// Double check that the delay is safe
			if( Autologon::iSelectDelay <= 500 )
			{
				// force the delay to a minimum if it was bad
				Sleep( 500 );
			} else {
				/// Allow the  users delay
				Sleep( Autologon::iSelectDelay );
			}

			// Make sure we have not logged out or selected a character manually.
			if( ( Autologon::bBNCSConnected == true ) && ( Autologon::bInChat == false ) )
			{
				// Select the character
				if( iSlot == 0 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 300, 140 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 1 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 540, 140 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 2 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 300, 230 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 3 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 540, 230 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 4 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 300, 315 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 5 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 540, 315 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 6 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 300, 425 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else if( iSlot == 7 )
				{					
					Autologon::Data->_auto->SendClick( Autologon::hD2Wnd, Autologon::MCP->_auto->DOUBLE_LCLICK, 500, 425 );
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
				else 
				{
					// No matches found say so
					Autologon::Data->mBox("Error: StrChar2Slot failed.");
					// Kill everything
					Autologon::bSelectChar = false;
					TerminateThread( Autologon::hCharSelect, 0 );
					CloseHandle( Autologon::hCharSelect );
					Sleep(50);
					return 0;
				}
			}
		} else {
			// Kill everything
			Autologon::bSelectChar = false;
			TerminateThread( Autologon::hCharSelect, 0 );
			CloseHandle( Autologon::hCharSelect );
			Sleep(50);
			return 0;
		}
	}
	Sleep(50);
	return 0;
}

Autologon::Autologon()
{
	//Autologon::Data->InitXML("Autologon.xml","Changeme");
}

Autologon::Autologon(IProxy* proxy,ModuleKind kind) :
	_proxy( proxy ),
	_kind( kind )
{
	switch( _kind )
	{
		case ChatModule:
		{
			Autologon::bBNCSConnected = true;
			Autologon::Data->InitXML("Autologon.xml","Changeme");
		}
		break;
		case RealmModule:
		{
			Autologon::bMCPConnected = true;
			//mBox("MCP Connected");
		}
		break;
		case GameModule:
		{
			Autologon::bD2GSConnected = true;
			//mBox("D2GS Connected");
		}
		break;
	}
}

void __stdcall Autologon::Destroy()
{
	if( Autologon::BNCS == this )
	{
		Autologon::bBNCSConnected = false;
		Autologon::bBNCSAuthPassed = false;
	}
	if( Autologon::MCP == this )
	{
		Autologon::bMCPConnected = false;
		Autologon::bMCPAuthPassed = false;
	}
	if( Autologon::D2GS == this )
	{
		Autologon::bD2GSConnected = false;
	}
	delete this;
}

void Autologon::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>( packet->GetData() );
	UINT iPacket;
	if( GameModule == _kind )
	{
		iPacket = bytes[0];
	}
	if( ChatModule == _kind )
	{
		iPacket = bytes[1];

		// 0x10
		if( iPacket == SID_LEAVECHAT )
		{
			// left chat
			Autologon::bInChat = false;
		}

	}
	if( RealmModule == _kind )
	{
		iPacket = bytes[2];
	}
}

void Autologon::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>( packet->GetData() );
	UINT iPacket;
	if( GameModule == _kind )
	{
		iPacket = bytes[0];
	}
	if( ChatModule == _kind )
	{
		iPacket = bytes[1];

		// 0x0A
		if( iPacket == SID_ENTERCHAT )
		{
			// in chat
			Autologon::bInChat = true;
		}
		
		// 0x33
		if( iPacket == SID_GETFILETIME )
		{
			if( Autologon::bInChat == false )
			{
				if( Autologon::bAutologon == true )
				{
					Autologon::bSendLogin = true;
					Autologon::hLogin = CreateThread( 0, 0, LogonThread, 0, 0, 0 );
				}
			}
		}

		// 0x51
		if( iPacket == SID_AUTH_CHECK )
		{
			unsigned long dwResult =  *(unsigned long *)( bytes + 4 );
			switch( dwResult )
			{
				// 0x0000
				case AUTH_PASSED:
				{
					// success let's continue forward
					Autologon::bBNCSAuthPassed = true;
					Autologon::Data->InitXML("Autologon.xml","Changeme");
				}
				break;

				// Anything but success
				default:
				{
					// problem turn things off
					Autologon::bBNCSAuthPassed = false;
				}
				break;
			}
		}
	}
	if( RealmModule == _kind )
	{
		iPacket = bytes[2];

		// 0x01
		if( iPacket == MCP_STARTUP )
		{
			/*
			Known return values:
				0x00: Success 
				0x0C: No Battle.net connection detected 
				0x7E: CDKey banned from realm play (UNVERIFIED) 
				0x7F: Temporary IP ban \"Your connection has been temporarily restricted from this realm. Please try to log in at another time\"
			*/
			unsigned long dwResult =  *(unsigned long *)( bytes + 4 );
			switch( dwResult )
			{
				case 0x00:
				{
					// success
					Autologon::bMCPAuthPassed = true;
				}
				break;
				default:
				{
					// problem so turn things off
					Autologon::bMCPAuthPassed = false;
				}
				break;
			}
		}

		// 0x19
		if( iPacket == MCP_CHARLIST2 )
		{
			//unsigned short wRequest = *(SHORT*)&bytes[3];
			//unsigned long dwTotal = *(DWORD*)&bytes[5];
			Autologon::CharList.Clear();
			unsigned short wResult = *(SHORT*)&bytes[9];		
			// The first expriration date
			int iPos = 11;
			for( int i = 0; i < wResult; i++ )
			{
				// Charactername = iPos + DWORD
				iPos = ( iPos + sizeof(unsigned long) );
				// Grab the Character name
				const char* szChar = reinterpret_cast<const char*>( bytes + iPos );
				Autologon::CharList.Add( const_cast<char*>( szChar ) );
				iPos += (int)( strlen(szChar) + 35 );
			}
			// we should be sitting in the character select screen
			Autologon::bSelectChar = true;
			Autologon::hCharSelect = CreateThread( 0, 0, SelectCharThread, 0, 0, 0 );
			
			if(Autologon::bIconic == true)
			{
				ShowWindow( Autologon::hD2Wnd , SW_MINIMIZE );
				ShowWindow( Autologon::hD2Wnd , SW_SHOW );
				Autologon::bIconic = false;
			}
			
		}
	}
}

void Autologon::Update()
{
}

bool Autologon::InitXML(char* szFile,char*szSection)
{
	bool bReturn = false;
	Reset();	
	Autologon::sXMLFile.assign(szFile);
	Autologon::sXMLSection.assign(szSection);
	while( Autologon::Data->DataHandler( LOAD ) != true )
	{
		Autologon::Data->DataHandler( CREATE );
	}
	return bReturn;
}

bool Autologon::DataHandler(int nAction)
{
	bool bReturn = false;
	switch( nAction )
	{
		case CREATE:
		{
			Autologon::Data->xMainNode = Autologon::Data->openFileHelper( Autologon::sXMLFile.c_str() );
			Autologon::Data->xData = Autologon::Data->xMainNode.addChild( "xData" );
			Autologon::Data->xData.addAttribute( "version", "1.0" );
			Autologon::Data->xData.addAttribute( "load", Autologon::sXMLSection.c_str() );
			Autologon::Data->xProfile = Autologon::Data->xData.addChild( Autologon::sXMLSection.c_str() );
			Autologon::Data->xProfile.addAttribute( "password", "changeme" );
			Autologon::Data->xProfile.addAttribute( "title", "Diablo II" );
			Autologon::Data->xOption = Autologon::Data->xProfile.addChild( "Autologon" );
			Autologon::Data->xOption.addAttribute( "value", "false" );
			Autologon::Data->xOption.addAttribute( "delay", "5000" );
			Autologon::Data->xOption.addAttribute( "character", "changeme" );
			Autologon::Data->xMainNode.writeToFile( Autologon::sXMLFile.c_str() );
			bReturn = true;
		}
		break;
		case LOAD:
		{
			Autologon::Data->xMainNode = Autologon::Data->openFileHelper( Autologon::sXMLFile.c_str() );
			int nCount = Autologon::Data->xMainNode.nChildNode();
			if( nCount <= 0 )
			{
				bReturn = false;
			} else {
				Autologon::Data->xMainNode = Autologon::Data->openFileHelper( Autologon::sXMLFile.c_str() );
				Autologon::Data->xData = Autologon::Data->xMainNode.getChildNode( "xData" );
				Autologon::Data->xProfile = Autologon::Data->xData.getChildNode( Autologon::Data->xData.getAttribute( "load" ) );
				Autologon::sXMLSection.assign( Autologon::Data->xProfile.getName() );

				// Set the account to login to
				Autologon::sAccount.assign( Autologon::sXMLSection.data() );

				// Set the account password
				Autologon::sPass.assign( Autologon::Data->xProfile.getAttribute( "password" ) );

				// Set the window title
				Autologon::sTitle.assign( Autologon::Data->xProfile.getAttribute( "title" ) );
				if(Autologon::hD2Wnd == NULL)
					Autologon::hD2Wnd = Autologon::Data->_auto->Window( Autologon::sTitle.c_str() );

				Autologon::Data->xOption = Autologon::Data->xProfile.getChildNode( "Autologon" );	

				// Set the character name
				Autologon::sCharacter.assign( const_cast<char*>( Autologon::Data->xOption.getAttribute( "character" ) ) );
				
				// Set the autologon value
				Autologon::bAutologon = Str2Bool( Autologon::Data->xOption.getAttribute( "value" ) );

				Autologon::iSelectDelay = Str2Delay( Autologon::Data->xOption.getAttribute( "delay" ) );

				// Set the mode string
				Autologon::iMode = 1;//Autologon::Data->Str2nMode( "xpac" );

				bReturn = true;
			}
		}
		break;
	}
	return bReturn;
}

int Autologon::Str2nMode(char* szData)
{
	int nRet;
	if( stricmp( szData , "classic" ) == 0 ) {
		nRet = CLASSIC;
		//mBox("Mode: Classic");
	}
	else if( stricmp( szData , "xpac" ) == 0 ) {
		nRet = XPAC;
		//mBox("Mode: XPac");
	}
	else {
		nRet = XPAC;
		//mBox("Mode: Defaulted to XPAC");
	}
	return nRet;
}

char* Autologon::nMode2Str(int nMode)
{
	char* szReturn = new char[32];
	switch(nMode)
	{
		case CLASSIC:
			strncpy( szReturn, "classic", ( strlen( "classic" ) + 1 ) );
		break;
		case XPAC:
			strncpy( szReturn, "xpac", ( strlen( "xpac" ) + 1 ) );
		break;
		default:
			strncpy( szReturn, "xpac", ( strlen( "xpac" ) + 1 ) );
		break;
	}
	return szReturn;
}

bool Autologon::StrMatch(char* szOne, char* szTwo)
{			// case sensitive match				// non case sensitive match
	if( ( strcmp( szOne, szTwo  ) == 0 ) || ( stricmp( szOne, szTwo ) == 0 ) )
		return true;
	else 
		return false;	
}

bool Autologon::Str2Bool(const char* szBool)
{
	if( ( stricmp( szBool, "1" ) == 0 ) || ( stricmp( szBool, "true" ) == 0 ) || ( stricmp( szBool, "yes" ) == 0 ) )
	{
		return true;;
	} else {
		return false;
	}
}

void Autologon::mBox(char* szMsg)
{
	::MessageBoxA( NULL, szMsg, "Info", MB_OK );
}

int Autologon::StrChar2Slot(const char* szChar)
{
	int iRet = -1; // look for -1 to be an error character was not found
	for(int i = 0; i < Autologon::CharList.Count(); i++ )
	{
		if( stricmp( szChar, Autologon::CharList.Get(i) ) == 0 )
		{
			iRet = i;
		}
	}
	return iRet;
}

int Autologon::Str2Delay(const char* szInt)
{
	int nReturn;
	if( isdigit( atoi( szInt ) ) )
	{
		nReturn = atoi( szInt );
	} else {
		nReturn = 5000;
	}
	return nReturn;
}

void Autologon::Reset()
{
	Autologon::sXMLFile.clear();
	Autologon::sXMLSection.clear();
	Autologon::sAccount.clear();
	Autologon::sPass.clear();
	Autologon::sTitle.clear();
	Autologon::hD2Wnd = NULL;
	Autologon::sCharacter.clear();

	Autologon::bAutologon = false;
	Autologon::bSendLogin = false;
	Autologon::bSelectChar = false;
	Autologon::bInChat = false;
	Autologon::iMode = NULL;
	Autologon::iSelectDelay = NULL;
	Autologon::bIconic = false;
}
