#pragma once
#include <windows.h>
#include <string>
#include "IModule.h"
#include "IPacket.h"
#include "IProxy.h"
#include ".\\Utilities\\xmlParser.h"
#include ".\\Utilities\\Automate.h"
#include ".\\Utilities\\List.h"
#include ".\\Utilities\\PacketDefs.h"

using namespace std;

#pragma warning (disable:4996) // typesafe string manipulation warnings

class Autologon :
	public IModule,
	public XMLNode
{
public:
	Autologon();
	Autologon(IProxy* proxy,ModuleKind kind);
	void __stdcall Destroy();
	void _stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void _stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void _stdcall Update();

	// Class static Instances
	static Autologon* BNCS;
	static Autologon* D2GS;
	static Autologon* MCP;
	static Autologon* Data;

	// Static members
	static string sXMLFile;
	static string sXMLSection;
	static string sAccount;
	static string sPass;
	static string sTitle;
	static string sCharacter;
	
	static HWND hD2Wnd;

	static HANDLE hLogin;
	static HANDLE hCharSelect;

	static bool bAutologon;
	static bool bBNCSAuthPassed;
	static bool bMCPAuthPassed;
	static bool bSendLogin;
	static bool bSelectChar;
	static bool bInChat;
	static bool bIconic;
	static bool bBNCSConnected;
	static bool bMCPConnected;
	static bool bD2GSConnected;

	static int iMode;
	static int iSelectDelay;

	static List<char*> CharList;

	// XMLNode Structs
	XMLNode xMainNode;
	XMLNode xData;	
	XMLNode xProfile;
	XMLNode xOption;

	// shortcuts
	enum DATA_ACTIONS {
		CREATE,
		LOAD,
		ADD,
		REMOVE,
		UPDATE,
	};
	enum LOGIN_MODES
	{
		CLASSIC,
		XPAC,
		UNKNOWN,
	};
	enum CHAR_SLOTS
	{
		CHAR_ZERO,
		CHAR_ONE,
		CHAR_TWO,
		CHAR_THREE,
		CHAR_FOUR,
		CHAR_FIVE,
		CHAR_SIX,
		CHAR_SEVEN,
	};

	// Plugin Function
	bool InitXML(char* szFile,char*szSection);
	bool DataHandler(int nAction);
	int Str2nMode(char* szData);
	char* nMode2Str(int iMode);
	bool StrMatch(char* szOne, char* szTwo);
	bool Str2Bool(const char* szBool);
	void mBox(char* szMsg);
	int StrChar2Slot(const char* szChar);
	int Str2Delay(const char* szInt);
	void Reset();

	Automate* _auto;

private:
	IProxy* _proxy;
	ModuleKind _kind;
protected:
};
