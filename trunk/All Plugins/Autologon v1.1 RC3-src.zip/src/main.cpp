#include <windows.h>
#include "Autologon.h"
#include "PluginTypes.h"
#include "IModule.h"

PluginInfo Info;
bool bLoaded = false;

int __stdcall DllMain(HINSTANCE instance, int reason, void* reserved)
{
	if(bLoaded == false)
	{
		Autologon::Data = new Autologon();
		bLoaded = true;
	}
	return 1;
}

void __stdcall FreePlugin(PluginInfo* Info)
{
   //Cleanup Stuff
}

IModule* __stdcall CreateModule(IProxy* proxy, ModuleKind kind)
{
	switch(kind)
	{
		case ChatModule: 
		{
			Autologon::BNCS = new Autologon(proxy,kind);
			return Autologon::BNCS; 
		} 
		break; 

		case GameModule:  
		{ 
			Autologon::D2GS = new Autologon(proxy,kind);
			return Autologon::D2GS;  
		} 
		break;

		case RealmModule:  
		{ 
			Autologon::MCP = new Autologon(proxy,kind);  
			return Autologon::MCP;  
		}
		break;
	}

	return 0;
}


extern "C"
{
	__declspec(dllexport) PluginInfo* __stdcall InitPlugin(RedVexInfo* Funcs)
	{ 
		Info.Name = "Autologon v1.1 RC3";
		Info.Author = "Leo-X";
		Info.SDKVersion = 3;
		Info.Destroy = (DestroyPlugin)&FreePlugin;
		Info.Create = &CreateModule;
		return &Info;
	}
}