Title: Autologon 1.1 (RC3)
Author: Leo-X
Released: 09/09/2007
Updated: 11/21/2007

Instructions:
1) Drop Autologon.dll into your plugins directory
2) Next load and start redvex then run Diablo II and click the button to login, this will generate an xml file named Autologon.xml in your redvex folder.
2) Shutdown and close redvex and close diablo II.
3) Open up and edit Autologon.xml
4) If the Autologon.xml file cannot be found unload all other plugins and run Autologon by itself once so that it can generate the xml file correctly.

Autologon.xml Explanation:
1) Ignore and leave this alone: <?xml version="1.0" encoding="ISO-8859-1"?>
2) The "load" string in the line <xData version="1.0" load="Changeme"> tells the plugin what profile section to get and use.
- so if that line said load="Example" it would look for <Example> and load it and all data within <Example>
*Note: Make sure if you open a tag such as <Example> that you also close it </Example>
3) The Section names should be a name that corrisponds to the Account name you wish to logon to.
4) Everything else should be pretty self explanitory if it is not let me know.
5) Again as with the first Autologon release we need to know what title your D2 client will be using so please make sure that is filled in correctly.


Notes:
98.0% Done
1% = need to check stability and find any bugs.
1% = add the extra commands, to load a profile, set a character and a command to hop onto that character.

Example Autologon.xml:
<?xml version="1.0" encoding="ISO-8859-1"?>
<xData version="1.0" load="Tester">
<Tester password="xxx" title="Diablo II">
<Autologon value="true" delay="5000" character="Tester"/>
</Tester>
</xData>

That would load the profile "Tester" which contains details for the account "Tester" and is set to login automatically.
Remember to set your Diablo II window title correctly here, the default is "Diablo II"
If you use more than one d2 instance you "SHOULD" change the window titles.

[Changlog]
11/21/2007
~ Minor update to allow the plugin to access the character select screen when the d2 window is minimized (iconic).
* Note: Possibly change this in the future see how this seems work.
* Look into adding a hotkey to toggle "show/hide" the d2 window manually.

11/17/2007
+ Added the select character delay to the .xml file defaults to 5000(5 seconds) if something invalid was used.
+ Added a proper Reset function to clear account/character data.
~ Rewrote the character select thread handler this should improve things alot.
~ Updated how and where the account/character data is loaded.
~ Moved RC revision forward to RC3
- Removed the xpac/classic choice will add classic support later possibly.
* Hopefully this update fixes most issues related to the select character screen and it's thread (we shall see).
* If this seems to fix most problems I will add a userlist and a some commands soon.
* Updated the sources.

11/12/2007
~ Minor update it should no longer loose track of data now it loads everything each time bncs starts up, and clears everything when bncs is removed.(keep an eye on this)
* Updated the sources.

11/09/2007
~ Minor update should be alot more stable now less crashing.
~ Moved RC revision forward to RC2
* Updated the sources.

11/07/2007
- Removed the channel portions as they don't really relate to logging in (I will release that seperately).
* Pretty much rewrote and improved most everything else.
* Updated the sources.

09/09/2007
+ Initial release date.

Changelog Guide:
+ Addition.
- Removal.
~ Update.
* Note.