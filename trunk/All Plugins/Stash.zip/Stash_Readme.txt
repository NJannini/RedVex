Stash.dll

An item mover for RedVex by Turlok!

This plugin allows you to move and sort your inventory and stash items

************************************************************

Installing Stash.dll:
Step 1: Put Stash.dll into your Plugins folder
Step 2: Update RedVex
Step 3: High-Five! Your done!

************************************************************

in-game commands:

Basic Commands
--------------
.stash		-> sends all default items from the inventory to the stash
.get		-> sends all default items from the stash to the inventory
.drop		-> sends all default items from the inventory to ground
.trash		-> sends all default items from the stash and inventory to the ground
.cursor		-> gives you information about the item you are holding with your mouse, including it's iCode

"What are default items?"  These are items that meet my default stashing conditions, that is:
they are ANY item EXCEPT for the following: Quest Items, Scrolls, Scroll Books, Potions, Keys, and IDENTIFIED Charms.

Commands for moving items by Type
---------------------------------
.stash [iType]		-> sends all items of iType from the inventory to the stash
.get [iType]		-> sends all items of iType from the stash to the inventory
.drop [iType]		-> sends all items of iType from the inventory to the ground
.trash [iType]		-> sends all items of iType from the stash and inventory to the ground

"what is an iType?"  These are my predefined catagories for items.  The following is a list of all the iTypes:

essence		-> ingredients for the respec token
key,		-> ingredients for the uber organ portals
charm,		-> UNIDENTIFIED charms only
gem,
jewel,
rune,
ring,
amulet,
armor,
axe,
belt,
boots,
bow,		-> includes Crossbows and Amazon-Only Bows
claw,
dagger,
gloves,
helm,		-> includes Circlets, Barbarian-Only Helmets, and Druid-Only Pelts
circlet,
mace,
polearm,
scepter,
shield,		-> includes Necromancer Heads and Paladin-Only Shields
spear,		-> includes Amazon-Only Spears
staff,
sword,
throwing,	-> includes Javelins and Amazon-Only Javelins
wand,
orb,
magic,		-> All Magic-Quality Items EXCEPT IDENTIFIED Charms
set,		-> All Set-Quality Items
rare,		-> All Rare-Quality Items
unique,		-> All Unique-Quality Items EXCEPT IDENTIFIED Charms
crafted,	-> All Crafted-Quality Items
ama,		-> Amazon-Only weapons	
bar,		-> Barbarian-Only Helmets
head,		-> Necromancer-Only Heads
pal,		-> Paladin-Only Shields
pelt,		-> Druid-Only Pelts


Commands for moving items by Code
---------------------------------
.stashcode [iCode]	-> sends all items of iCode from the inventory to the stash
.getcode [iCode]	-> sends all items of iCode from the stash to the inventory
.dropcode [iCode]	-> sends all items of iCode from the inventory to the ground
.trashcode [iCode]	-> sends all items of iCode from the stash and inventory to the ground

"what is an iCode?"  This is the three-character string Diablo II uses to distinguish between items.
You can find out an item's iCode with the .cursor command.

Commands for sorting items
--------------------------
.ssort			-> organizes the items in your stash
.isort			-> organizes the items in your inventory

*The sort commands require AT LEAST a 2x4 empty area to work, and still may fail depending on the items you're carrying.
For the best results, create a 2x4 empty area in the top-left corner of the area you are sorting, and another free space.

************************************************************

WARNING:

Use of the Horadric Cube will cause this plug-in to function incorrectly.  You are allowed to have a Horadric Cube,
but no items are allowed to go in or out of the Cube.  If any item has been inside your Horadric Cube at any point
in your current game, then use of Stash's commands may boot you from the game, and may result in a Temporary Suspension.

If you have items in your cube, just take them all out and rejoin the game before using this.

************************************************************