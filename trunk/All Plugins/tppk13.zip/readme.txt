RedVex Tppk Plugin
Version 1.1 by FooSoft
----------------------

Tppk is a hack which allows the player to take advantage of a flaw in Diablo II's 
player hostility system, allowing them to kill hardcore players with ease. Basically,
the PKer shoots a series of projectiles (ice blasts, tornadoes, bone spirits, etc)
at a friendly player, opens a town portal, goes to town, and hostiles their target 
before the projectiles pass them. If this is done right, the projectiles will hit
and kill the now hostiled player. This module allows all of these steps to take
place in less than a second, maximizing the chance for success. However, this hack
can be used without the hostility functionality as well for simply an ultra-fast
town portal that can be used to escape dangerous situations.

Upon running Tppk for the first time a file called "Tppk.ini" will be created 
in the RedVex directory. It will contain the following default settings which 
can be modified by you:

TriggerSkill
   This is the skill that will be the trigger to cause the tppk plugin to activate.
   When this skill is selected (you don't need to use it, just select it via hotkey),
   you will cast a TP, go through it, and if necesssary, hostile all of the players
   in the current game. This will happen extremely fast. This value defaults to 3,
   which is the unsummon skill.

UseHostile
   This setting determines whether or not all of the players in the game should be
   hostiled when the player enters town through the fast TP. By default this is on
   (after all, this is a tppk hack), but you can optionally choose to disable it
   by setting it to 0, if you just want to use this module as a fast TP hack.

It is pretty easy to use this Tppk module - just make sure that you have a town portal
tome in your inventory, and that you have the "Unsummon" skill hotkeyed (or whatever
you set the "TriggerSkill" option to). When you are outside of town, press the hotkey
associated with this trigger skill, you will instantly go to town and hostile everyone.
Your projectiles can now hit and kill other players if they were aimed before you
town portaled.