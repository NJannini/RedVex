#include "IProxy.h"
#include "IPacket.h"

/*								hostile(id,true/false):
	This function hostiles(true)/unhostiles(false) player of id.  Must be in town to hostile.  Hostile has
	a server-side cooldown.
*/
void setHostile(int id, bool set);

/*								partyInvite(id):
	This function invites player of id to your party.
*/
void partyInvite(int id);

/*								partyCancel(id):
	This function cancels your party invite to player of id.
*/
void partyCancel(int id);

/*								partyAccept(id):
	This function accepts a party invite from player of id.  Only works if they invited you.
*/
void partyAccept(int id);

/*								setLoot(id,true/false):
	This function allows(true) or disallows(false) player of id to loot your corpse.  Only works in Hardcore mode.
*/
void setLoot(int id, bool set);

/*								setTalk(id,true/false):
	This function allows(true) or disallows(false) player of id to see what you type to in-game chat.
*/
void setTalk(int id, bool set);

/*								setSquelch(id,true/false):
	This function squelches(true) or unsquelches(false) player of id's in-game chat.  (squelch = ignore).
*/
void setSquelch(int id, bool set);


void setHostile(int id, bool set)
{
	int offset = 0;
	unsigned char buffer[7];
	buffer[offset++] = 0x5D;
	buffer[offset++] = 0x04;
	buffer[offset++] = set ? 0x01 : 0x00;
	*reinterpret_cast<int*>(buffer+offset) = id;
	offset+= sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void partyInvite(int id)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x5e;
	buffer[offset++] = 0x06;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void partyCancel(int id)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x5e;
	buffer[offset++] = 0x07;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void partyAccept(int id)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = 0x5e;
	buffer[offset++] = 0x08;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void setLoot(int id, bool set)
{
	unsigned char buffer[7];
	int offset = 0;

	buffer[offset++] = 0x5d;
	buffer[offset++] = 0x01;
	buffer[offset++] = set? 0x01 : 0x00;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void setTalk(int id, bool set)
{
	unsigned char buffer[7];
	int offset = 0;

	buffer[offset++] = 0x5d;
	buffer[offset++] = 0x02;
	buffer[offset++] = set? 0x01 : 0x00;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void setSquelch(int id, bool set)
{
	unsigned char buffer[7];
	int offset = 0;

	buffer[offset++] = 0x5d;
	buffer[offset++] = 0x03;
	buffer[offset++] = set? 0x01 : 0x00;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}