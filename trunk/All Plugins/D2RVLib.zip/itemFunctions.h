#include "IProxy.h"
#include "IPacket.h"

/*							drop(itemId):
	This function drops item of itemId from your cursor to the ground.
*/
void drop(int itemId);

/*							dropGold(id,amount):
	This function drops amount of gold from your inventory to the ground.  You must have enough
	gold in your inventory to drop.  You must specify your character's unit id.
*/
void dropGold(int id, int amount);

/*							invInteract(itemId,x,y):
	This function uses item of itemId in your inventory: potions, scrolls, etc.  x and y must
	represent your character's (x,y) coordinates.
*/
void invInteract(int itemId, int x, int y);

/*							beltInteract(itemId):
	This function uses item of itemId in your belt: potions, scrolls, etc.
*/
void beltInteract(itemId);

/*							pickUp(itemId,true/false):
	This function picks up item of itemId from the ground, and puts it in cursor(true) or
	automatically places in inventory(false).
*/
void pickUp(int itemId, bool cursor);

/*							beltUp(itemId):
	This function picks up item of itemId from the belt, and puts it in the cursor.
*/
void beltUp(int itemId);

/*							placeBelt(itemId,beltPos):
	This function places an item(potion/scroll) of itemId FROM THE CURSOR into the belt at
	beltPos.  You must have a large enough belt to support items being placed into beltPos.
	beltPositions:
					12	13	15	16
					8	9	10	11
					4	5	6	7
					0	1	2	3
*/	
void placeBelt(int itemId, int beltPos);

/*							replaceBelt(newId,oldId):
	This function replaces item IN BELT of oldId with item IN CURSOR of newId.  Item of oldId
	will be sent to the cursor.
*/	
void replaceBelt(int newId, int oldId);

/*							invToBelt(itemId):
	This function automatically places inventory item of itemId in the belt via d2's autosorting.
*/
void invToBelt(int itemId);

/*							idItem(itemId,idId):
	This function identifies an item of itemId using scroll or tomb of idId.  You must have scroll
	or non-empy tome.
*/
void idItem(int itemId, int idId);

/*							placeStorage(itemId,x,y,storage):
	This function places an item of itemId FROM THE CURSOR into the coord (x,y) of the storage screen.
	storage id's and dimensions:
	Item to Inventory(storage = 0x00) or TradeScreen(storage = 0x02):
		0	1	2	3	4	5	6	7	8	9
	0
	
	1
	
	2
	
	3
	Item to Horadric Cube(storage = 0x02):	 NOTE: Cannot send to cube with tradescreen open.  Horadric cube MUST BE OPEN.
		0	1	2
	0
	
	1
	
	2
	
	3
	Item to Stash(storage = 0x04):
		0	1	2	3	4	5
	0
	
	1
	
	2
	
	3
	
	4
	
	5
*/
void placeStorage(int itemId, int x, int y, int storage);

/*							storeUp(itemId):
	This function picks up item of itemId from storage, and puts it in the cursor.
*/
void storeUp(int itemId);

/*							replaceStorage(newId,oldId,x,y):
	This function replaces item IN STORAGE of oldId with item IN CURSOR of newId.  Item of oldId
	will be sent to the cursor.  Coordinates (x,y) must match space to contain newId overlapping 
	coords where oldId is resting.  THIS FUNCTION UNAVAILABLE IN TRADE SCREEN - WILL R/D.
*/
void replaceStorage(int newId, int oldId, int x, int y);

/*							placeCube(itemId,cubeId):
	This function automatically places item of itemId FROM CURSOR into cube of cubeId.  Cube must be CLOSED.
*/
void placeCube(int itemId, int cubeId);

void drop(int itemId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x17;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void dropGold(int id, int amount)
{
	unsigned char buffer[9];
	int offset = 0;
	buffer[offset++] = 0x50;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = amount;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void invInteract(int itemId, int x, int y)
{
	int offset = 0;
	unsigned char buffer[13];
	buffer[offset++] = 0x20;
	*reinterpret_cast<int*>(buffer+offset) = itemId;
	offset+= sizeof(int);
	*reinterpret_cast<int*>(buffer+offset) = x;
	offset+= sizeof(int);
	*reinterpret_cast<int*>(buffer+offset) = y;
	offset+= sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void beltInteract(int itemId)
{
	int offset = 0;
	unsigned char buffer[12];
	buffer[offset++] = 0x26;
	*reinterpret_cast<int*>(buffer+offset) = itemId;
	offset+= sizeof(int);
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void pickUp(int itemId, bool cursor)
{
	unsigned char buffer[13];
	int offset = 0;
	buffer[offset++] = 0x16;
	buffer[offset++] = 0x04;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	buffer[offset++] = cursor ? 0x01 : 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void beltUp(int itemId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x24;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void placeBelt(int itemId, int beltPos)
{
	unsigned char buffer[9];
	int offset = 0;

	buffer[offset++] = 0x23;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = beltPos;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void replaceBelt(int newId, int oldId)
{
	unsigned char buffer[9];
	int offset = 0;
	buffer[offset++] = 0x25;
	*reinterpret_cast<int*>(buffer + offset) = newId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = oldId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void invToBelt(int itemId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x63;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void idItem(int itemId, int idId)
{
	unsigned char buffer[9];
	int offset = 0;
	buffer[offset++] = 0x27;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = idId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void placeStorage(int itemId, int x, int y, int storage);
{
	unsigned char buffer[17];
	int offset = 0;
	buffer[offset++] = 0x18;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = x;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = y;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = storage;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void storeUp(int itemId)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x19;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void replaceStorage(int newId, int oldId, int x, int y)
{
	unsigned char buffer[17];
	int offset = 0;
	buffer[offset++] = 0x1F;
	*reinterpret_cast<int*>(buffer + offset) = newId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = oldId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = x;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = y;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void placeCube(int itemId, int cubeId)
{
	unsigned char buffer[9];
	int offset = 0;
	buffer[offset++] = 0x2A;
	*reinterpret_cast<int*>(buffer + offset) = itemId;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = cubeId;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}