#include "IProxy.h"
#include "IPacket.h"

/*									exit():
	This function will quickly exit you from the game (probably showing Connection Iterrupted message).
*/
void exit();

/*									switchWeapons():
	This function will perform a weaponswitch for your character.
*/
void switchWeapons();

/*									flash(id):
	This function will flash player id's screen.
*/
void flash(int id);

/*									useObject(objId,type):
	This function will use object objId.  You must specify the correct type of the object you're using.
	0x00 = Request trade Interaction with another player
	0x01 = Interact with a Town Folk
	0x02 = Interact with Object's like stash, teleports, shrines, chest's and waypoints etc
	0x04 = Interact with an Item <- relates to some items/quest items i think
	0x05 = Walk Through a Doorway
*/
void useObject(int objId, int type);

void exit()
{
	//exit game to server
	unsigned char buffer[1];
	buffer[0] = 0x69;
	IPacket* packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
	//game over from server
	buffer[0] = 0xB0;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
	//unload done from server
	buffer[0] = 0x05;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
	//success from server
	buffer[0] = 0x06;
	packet = _proxy->CreatePacket(buffer, 1);
	packet->SetFlag(IPacket::PacketFlag_Finalized);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}
void switchWeapons()
{
	unsigned char buffer[1];
	int offset = 0;

	buffer[offset++] = 0x60;

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void flash(int id)
{
	unsigned char buffer[9];

	buffer[0] = 0x4b;
	*reinterpret_cast<int*>(buffer + 1) = 0;
	*reinterpret_cast<int*>(buffer + 5) = id;

	IPacket* packet = _proxy->CreatePacket(buffer, sizeof(buffer));
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void useObject(int objId, int type)
{
	unsigned char buffer[9];
	int offset = 0;

	buffer[offset++] = 0x13;
	*reinterpret_cast<int*>(buffer + offset) = type;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = objId;
	offset += sizeof(int);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}