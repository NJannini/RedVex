#include "IProxy.h"
#include "IPacket.h"

/*								moveTo(objId,true/false):
	This function makes your character run(true) or walk(false) to object objId.
*/
void moveTo(int objId, bool run);

/*								moveHere(x,y,true/false):
	This function makes your character run(true) or walk(false) to coord (x,y).
*/
void moveHere(short x,short y, bool run);

/*								updatePosition(id,x,y):
	This function imitates information the server would send the client about a player's movement.
	If you are moving with moveHere(), then you must call this function afterwards to sync the client 
	with the server and actually move.
*/
void updatePosition(int id, int x,int y);

/*								useWP(id,area):
	This function will allow your character to use waypoint id, and send you to the zone area.  You
	must have the waypoint to the zone you attempt to travel to.
	area(s):
		0x00 = Close Waypoint Menu
		0x01 = Rogue Encampment
		0x03 = Cold Plains
		0x04 = Stony Fields
		0x05 = Dark Wood
		0x06 = Black Marsh
		0x1B = Outer Cloister
		0x1D = Jail Level 1
		0x20 = Inner Cloister
		0x23 = CataCombs Level 2
		0x28 = Lut Gholein
		0x30 = Sewers Level 2
		0x2A = Dry Hills
		0x39 = Halls Of The Dead Level 2
		0x2B = Far Oasis
		0x2C = Lost City
		0x34 = Palace Cellar Level 1
		0x4A = Arcain Sanctuary
		0x2E = Canyon Of The Magi
		0x4B = Kurast Docks
		0x4C = Spider Forest
		0x4D = Great Marsh
		0x4E = Flayer Jungle
		0x4F = Lower Kurast
		0x50 = Kurast Bazaar
		0x51 = Upper Kurast
		0x53 = Travincal
		0x65 = Durance Of Hate Level 2
		0x67 = The Pandeminoum Fortress
		0x6A = City Of The Damned
		0x6B = River Of Flame
		0x6D = Harrogath
		0x6F = Frigid Highlands
		0x70 = Arreat Plateau
		0x71 = Crystalline Passage
		0x73 = Glacial Trail
		0x7B = Halls Of Pain
		0x75 = Frozen Tundra
		0x76 = The Ancient's Way
		0x81 = Worldstone Keep Level 2
*/
void useWP(int id,int area);

/*									bringMerc(id):
	This function brings your merc through a tp/wp with you.  Parameter is merc's id.  Sending
	this for your merc will avoid some problems taking wps/tps.  Only applies for mercenaries,
	not summoned units.
*/
void bringMerc(int id);

void moveTo(int objId, bool run)
{
	unsigned char buffer[9];
	int offset = 0;

	buffer[offset++] = run ? 0x04 : 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = objId;
	offset += sizeof(int);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void moveHere(short x,short y, bool run)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = run ? 0x03 : 0x01;
	*reinterpret_cast<short*>(buffer + offset) = x;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = y;
	offset += sizeof(short);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void updatePosition(int id, int x,int y)
{
	unsigned char buffer[11];
	int offset = 0;

	buffer[offset++] = 0x15;
	buffer[offset++] = 0x00;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	*reinterpret_cast<short*>(buffer + offset) = x;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = y;
	offset += sizeof(short);
	buffer[offset++] = 0x01;

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToClient(packet, this);
	delete packet;
}
void useWP(int id,int area)
{
	unsigned char buffer[8];
	int offset = 0;

	buffer[offset++] = 0x49;
	*reinterpret_cast<int*>(buffer + offset) = id;
	offset += sizeof(int);
	buffer[offset++] = area;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void bringMerc(int id)
{
	unsigned char buffer[9];

	buffer[0] = 0x4b;
	*reinterpret_cast<int*>(buffer + 1) = 0x01;
	*reinterpret_cast<int*>(buffer + 5) = id;

	IPacket* packet = _proxy->CreatePacket(buffer, sizeof(buffer));
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}