#include "IProxy.h"
#include "IPacket.h"

/*								selectSkill(true/false,skillId):
	This function changes the selected skill on right hand(true) or left hand(false) to skillId
*/
void selectSkill(bool rightHand, short skillId);

/*								attackObject(true/false,objectType,objectId):
	This function attacks(namelock) objectId with right hand(true) or left hand(false) skill.  objectType must accurately 
	represent objectId's type.
	0x00 = player
	0x01 = monster
	0x02 = Object (TP, WP, Shrines, Etc).
*/
void attackObject(bool rightHand, int objectType, int objectId);

/*								attackLocation(true/false,x-coord,y-coord):
	This function attacks location (x,y) with right hand(true) or left hand(false) skill.
*/
void attackLocation(bool rightHand, short x, short y);

void selectSkill(bool rightHand, short skillId)
{
	unsigned char buffer[9];
	int offset = 0;

	buffer[offset++] = 0x3c;
	*reinterpret_cast<short*>(buffer + offset) = skillId;
	offset += sizeof(short);
	buffer[offset++] = 0x00;
	buffer[offset++] = rightHand ? 0x00 : 0x80;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;
	buffer[offset++] = 0xff;

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void attackObject(bool rightHand, int objectType, int objectId)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = rightHand ? 0x0d : 0x06;
	*reinterpret_cast<int*>(buffer + offset) = objectType;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = objectId;
	offset += sizeof(int);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void attackLocation(bool rightHand, short x, short y)
{
	unsigned char buffer[5];
	int offset = 0;

	buffer[offset++] = rightHand ? 0x0c : 0x05;
	*reinterpret_cast<short*>(buffer + offset) = x;
	offset += sizeof(short);
	*reinterpret_cast<short*>(buffer + offset) = y;
	offset += sizeof(short);

	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}