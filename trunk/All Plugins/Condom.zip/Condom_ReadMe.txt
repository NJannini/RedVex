Condom.dll

Plugin for RedVex by Turlok!  For your protection!  Wear one every time!

This plugin is NOT provided as a replacement for caution or common sense.  It is in no way fail-safe and I will not take any responsibility for dead characters or closed accounts.  This is intended only as a supplement to your gaming experience, beware of dependency.

************************************************************

Features:

*Fast auto-tp-to-town when situation is getting hot
*Automatically drink potions for you and your merc
*Automatically exit game when life is too low
*Auto-Aim and TPPK features
*In-Game notifications on BO, Oaksage, Enchant, Iron Maiden and when they wear off
*Shows player's account name when they type (if available)
*Shows player names in color codes based on alliance status
*Shows in-game players when you join
*Shows overhead messages players visible on the automap (distance w/o party)
*Logs PK character names and account names and displays a [PK] tag for these people
*Filters spam from in-game messages
*Displays recently seen games of all difficulties

************************************************************

Installing Condom.dll:

Step 1: Put Condom.dll into your Plugins folder
Step 2: Put Condom.ini into your RedVex folder
Step 3: Put squelch.txt into your RedVex folder
Step 4: Edit and save Condom.ini
Step 5: Update your in-game key-configuration for each character
Step 6: High-Five! Your done!

************************************************************

Setting up Condom.ini:

Toggles: 1=ON, 0=OFF
[Realm]
RememberGames=1 //Write remembered games of all difficulties to the gamelist
[Chat]
HomeChannel=Condom Chat //Channel to automatically join

[Chicken]
ChickenTown=1 //Chicken to town when life reaches ChickenLife or below
ChickenExit=1 //Chicken out of game when life reaches ExitLife or below (but is still above 0)
ChickenMerc=0 //Chicken out of the game when merc's life reaches ExitMerc or below
ChickenPing=0 //Chicken out of game if ping is higher than ExitPing
TownOnIronMaiden=1 //Chicken to town when you are cursed with Iron Maiden
TownOnMercIronMaiden=1 //Chicken to town when your merc is cursed with Iron Maiden
TownOnHostile=1 //Chicken to town when someone hostiles you
TownOnDirectAttack=1 //Chicken to town when someone Direct-Attacks you
TownOnCOORDAttack=1 //Chicken to town when someone attacks the position your standing on
ChickenLife=60 //%life you will chicken to town at/below
ExitLife=50 //%life you will chicken from game at/below (but still above 0)
ExitMerc=20 //%life of merc you will chicken from game at/below
ExitPing=5000 //if ping is at least this high, you will exit from the game

[Potions]
AutoPot=1 //Drink Potions automatically
DrinkDelay=3500 //Minimum Delay between drinking two potions (milliseconds) (merc is double this)
PotLife=80 //%life you will drink a health potion
PotMana=20 //%mana you will drink a mana potion
RejuveLife=70 //%life you will drink a rejuve potion
RejuveMana=10 //%mana you will drink a rejuve potion
MercPotLife=80 //%merclife you will give your merc a health potion
MercRejuveLife=40 //%merclife you will give your merc a rejuve potion

[Messages]
ParseText=1 //Add Account,statuscolor,and pk tag to players names when they speak
ParseGame=1 //Add CharacterType,Level,and pk color to players names when they join/leave/drop/silent-exit
BossTalk=1 //Show Boss' speech indicating what special move they are about to use
PotionEchoes=1 //Show potion messages
WarningEchoes=1 //Show warning messages
StatusEchoes=1 //Show status messages
LevelEchoes=1 //Show level-up messages
DisplayStatus=1 //Show overhead character status messages
SpamFilter=1 //Filter spamming via squelch list and repeats

[Other]
TPPKMode=1 //Enable TPPK Features
ListPKs=1 //Save PK Names and Accounts to list and Tag them
AutoParty=1 //Automatically invite/accept party invitations from/to people who are NOT listed as PKs
HideCorpses=1 //Hide monster corpses

************************************************************

In-Game Commands:

.cube -> open cube from anywhere (deposit only!)
.stash -> open stash from anywhere (view only!)
.ninja -> perform a silent-exit from game
.resynch -> resynch's your character position with the game server
.settings -> displays current settings
.ctown -> toggles chicken-to-town on life value
.cexit -> toggles chicken-exit on life value
.townim -> toggles chicken-to-town on iron maiden
.townmim -> toggles chicken-to-town on merc iron maiden
.townh -> toggles chicken-to-town on hostile
.townd -> toggles chicken-to-town on direct-attack
.townc -> toggles chicken-to-town on coord-attack
.tppk -> toggles tppk mode
.drink -> toggles auto pot
.parse -> toggles chat parsing
.boss -> toggles boss speech
.pecho -> toggles potion messages
.wecho -> toggles warning messages
.secho -> toggles status messages
.lecho -> toggles level messages
.chide -> toggles hiding corpses
.list -> toggles adding players who hostile you to pk lists
.party -> toggles auto party
.display -> toggles overhead status displays
.filter -> toggles spam filter
.clife x -> sets chicken-to-town life to x percent
.elife x -> sex chicken-exit life to x percent
.drinkd x -> sets drink-delay to x milliseconds
.plife x -> sets auto-drink life pot to x percent life
.pmana x -> sets auto-drink mana pot to x percent mana
.pjuve x -> sets auto-drink juve pot to x percent life
.mlife x -> sets auto-merc-drink life pot to x percent life
.mjuve x -> sets auto-merc-drink juve pot to x percent life

************************************************************

Configuring Hotkeys:

To configure what keys do this, you must reconfigure your IN-GAME key configuration.

*Open TP: speech key for 'help'
*Fast-TP to town: speech key for 'retreat'

************************************************************

Configuring TPPK Hotkeys:

To configure your hotkeys for TPPKing, first ensure that TPPKMode is ON.  Setting auto-aim and fast-tp&hostile hotkeys must be done via your IN-GAME key configuration.

*Switch Target: speech key for 'follow me'
*AA/left skill: speech key for 'die'
*AA/right skill: speech key for 'this is for you'
*auto-tp and hostile: speech key for 'goodbye'

************************************************************

Important TPPK Information:

The AA on this plugin will attack it's target's coords instead of the target's object, allowing your attacks to go undetected by most anti-tppk triggers.  Using this method, it is possible to fire projectiles much faster than you breakpoints will allow - you should note that if you are firing too quickly by very much the server will ignore your attacks, and even though they will be visible to other players they will not count. 

*************************************************************