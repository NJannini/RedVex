View.dll

An item viewer for RedVex by Turlok!

This plugin allows you to get a general idea of what other people who were in your game are wearing.

************************************************************

Installing View.dll:
Step 1: Put View.dll into your Plugins folder
Step 2: Update RedVex
Step 3: High-Five! Your done!

************************************************************

in-game commands:

.view name -> displays what name was wearing last time you saw them
.view item -> displays item and ilvl of the item in your cursor

************************************************************

Display format:

The Item line will be displayed in the color of its quality(ie white,green,yellow,gold,orange).  Format is as follows:

equipmentPosition:ItemType(SocketsFilled)[ItemLevel]

************************************************************