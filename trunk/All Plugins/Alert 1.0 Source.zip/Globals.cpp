#include "Globals.h"

// not really used yet reserved for possible future use