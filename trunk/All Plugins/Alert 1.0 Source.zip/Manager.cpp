#include "Manager.h"

bool Manager::bChatConnected = false;
bool Manager::bChatAuthed = false;
bool Manager::bGameConnected = false;
bool Manager::bRealmConnected = false;
bool Manager::bRealmAuthed = false;

Manager::Manager()
{
	Cleanup();
}

Manager::~Manager()
{
	Cleanup();
}

void Manager::Cleanup()
{
	bChatConnected = false;
	bChatAuthed = false;
	bGameConnected = false;
	bRealmConnected = false;
	bRealmAuthed = false;
}