#include "Realm.h"
#include <Windows.h>
#include <string>

void Realm::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const BYTE* bytes = static_cast<const BYTE*>( packet->GetData() );
	UINT iPacket;
	iPacket = bytes[2];

	switch (iPacket) {
		case 0x07:
		// game logon
		// assume that window is in foreground
		std::string name(reinterpret_cast<const char*>(bytes+3));
		_manager->d2Windows[name] = GetForegroundWindow();
		break;
	}
}