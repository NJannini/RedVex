#include "Game.h"

void Game::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const BYTE* bytes = static_cast<const BYTE*>( packet->GetData() );
	UINT iPacket;
	iPacket = bytes[0];
	switch(iPacket) {
		case 0x68:
			charname = string(reinterpret_cast<const char*>(bytes+21));
		break;
	}
	// Add your code
}