#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED
#pragma once

#include "Globals.h"

#include "IModule.h"
#include "IPacket.h"
#include "IProxy.h"

#include "Manager.h"

#include <string>
#include <map>

struct  alertData {
	bool join;
	bool portal;
	bool trade;
	bool chat;
	bool whisper;	
	//bool party;
};

class Game :
	public IModule
{
public:
	Game(IProxy* proxy,Manager* manager);
	void __stdcall Destroy();
	void _stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void _stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void _stdcall Update();
	void Init();
	void flash();

private:
	string charname;
	unsigned int myID;
	alertData alert;
	IProxy* _proxy;
	Manager* _manager;
};

#endif