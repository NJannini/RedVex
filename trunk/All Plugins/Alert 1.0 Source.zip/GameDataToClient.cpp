#include "Game.h"

void Game::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	const BYTE* bytes = static_cast<const BYTE*>( packet->GetData() );
	UINT iPacket;
	iPacket = bytes[0];
	switch(iPacket) {
		case 0x0B: // game entry
			myID = *reinterpret_cast<const unsigned int*>(bytes + 2);
			Init(); // reload .ini file
		break;
		case 0x5A: // player joined/left/dropped
			if ((alert.join)&&(bytes[1]==0x02)) {flash();}
		break;
		case 0x26: // gamechat/whisper
			if ((alert.chat) && ((bytes[1]==0x01) || (bytes[1]==0x05))) {flash();}
			if ((alert.whisper) && (bytes[1]==0x02)) {flash();}
		break;
		case 0x82: //portal
			if ((alert.portal) && (*reinterpret_cast<const unsigned int*>(bytes+1)!=myID)) {flash();}
		break;
		case 0x77: //trade
			if ((alert.trade) && (bytes[1]==0x01)) {flash();}
		break;
		//case 0x07: // pp
		//	if ((alert.party) && (bytes[6]==0x05)) {flash();}
		//break; // actually sod this
	}
}