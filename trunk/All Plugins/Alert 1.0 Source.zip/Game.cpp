#include "Game.h"
#include "IniReadWrite.h"
#include <Windows.h>

Game::Game(IProxy* proxy,Manager* manager) :
	_proxy(proxy),
	_manager(manager)
{ 
	// Add your code
	Manager::bGameConnected = true;
}

void Game::flash()
{
	if (_manager->d2Windows.find(charname) != _manager->d2Windows.end()) {
		if (GetForegroundWindow()!=_manager->d2Windows[charname]) {
			FlashWindow(_manager->d2Windows[charname], true);
		}
	}
}

void Game::Init()
{

	// ini load
	IniReadWrite Ini("\\Plugins\\Alert.ini");
	//Chat("debug",false,Ini.path);
 
	int b = atoi(Ini.Read("alert", "join", "1"));
				   if (b==1) {alert.join = true;} 
						else {alert.join = false;}

	b = atoi(Ini.Read("alert", "portal", "1"));
		       if (b==1) {alert.portal = true;} 
			        else {alert.portal = false;}
	
		b = atoi(Ini.Read("alert", "trade", "1"));
		       if (b==1) {alert.trade = true;} 
			        else {alert.trade = false;}
	
	b = atoi(Ini.Read("alert", "chat", "1"));
		       if (b==1) {alert.chat = true;} 
			        else {alert.chat = false;}
	
	b = atoi(Ini.Read("alert", "whisper", "1"));
		       if (b==1) {alert.whisper = true;} 
			        else {alert.whisper = false;}
/*
	b = atoi(Ini.Read("alert", "party", "1"));
		       if (b==1) {alert.party = true;} 
			        else {alert.party = false;}	*/
}

void __stdcall Game::Destroy()
{
	// Add your code
	Manager::bGameConnected = false;
	delete this;
}

void Game::Update()
{
	// Add your code
}