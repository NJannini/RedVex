Dump.dll

An item move for RedVex by Turlok!

This plugin allows you to move a large amount of items from your inventory in seconds.

************************************************************

Installing View.dll:
Step 1: Put Dump.dll into your Plugins folder
Step 2: Update RedVex
Step 3: High-Five! Your done!

************************************************************

in-game commands:

Basic Commands
--------------
.dump ground -> drops your current window to the ground
.dump trade -> drops your current window to the trade window
.dump stash -> drops your current window to the stash
.dump inventory -> drops your current window to the inventory

Specific Commands
-----------------
.dump [window] [destination] -> will dump items from [window] to [destination] if possible

************************************************************

WARNING:

Don't Dump items in a place where they will overlap - you will drop and probably suffer R/D

************************************************************