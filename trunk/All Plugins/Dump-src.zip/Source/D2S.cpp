#include "Dump.h"
#include "IPacket.h"

void Dump::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>(packet->GetData());
	int packetId = bytes[0];

	switch(packetId)
	{
		case 0x15:
		{
			const char* text = reinterpret_cast<const char*>(bytes + 3);
			if (OnChat(text))
			{
				packet->SetFlag(IPacket::PacketFlag_Virtual);
			}
		}
		break;
		case 0x4F: //Trade Stuffs
		{
			switch(bytes[1]){
				//case 0x02: Chat("",false,"RESET 1");reset(); _inTrade=false; break;
				case 0x03: /*Chat("",false,"Accept Trade");*/_inTrade=true; break;
				case 0x12: /*Chat("",false,"Closed Stash");*/_inStash=false; break;
			}
		}
		break;
	}
}