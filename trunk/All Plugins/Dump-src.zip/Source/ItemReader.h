#pragma once
#include "Item.h"

class ItemReader
{
	public:
		void* data;
		ItemReader();
	
		
		item Read(unsigned char* ItemPacket);
		item ReadFlags(int flags);
		

};
