#include <windows.h>
#include "Dump.h"
#include "PluginTypes.h"
#include "IModule.h"


PluginInfo Info;

int __stdcall DllMain(HINSTANCE instance, int reason, void* reserved)
{
	return 1;
}

void __stdcall FreePlugin(PluginInfo* Info)
{
   //Cleanup Stuff
}

IModule* __stdcall CreateModule(IProxy* proxy, ModuleKind Kind)
{

switch(Kind)
	{
		case GameModule: return new Dump(proxy); break;
	}

return 0;
}


extern "C"
{
	__declspec(dllexport) PluginInfo* __stdcall InitPlugin(RedVexInfo* Funcs)
	{
	Info.Name = "Dump";
	Info.Author = "Turlok";
	Info.SDKVersion = 3;
	Info.Destroy = (DestroyPlugin)&FreePlugin;
	Info.Create = &CreateModule;
	return &Info;
	}
}