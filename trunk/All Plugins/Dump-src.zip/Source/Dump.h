#pragma once
#include <list>
#include <map>
#include "IModule.h"
#pragma comment(lib, "WS2_32.lib")
#include <windows.h>

class Dump :
	public IModule
{
public:
	Dump(IProxy* proxy);
	//~Dump();

	void _stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void _stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void _stdcall Update();
	void _stdcall Destroy();

private:
	IProxy* _proxy;

	static const char _chatName[];

	enum target{ground,cursor,invent,stash,trade};

	struct inventory{
		int id;
		int xPos;
		int yPos;
	};

	struct action{
		int id;
		int xPos;
		int yPos;
		int sends;
		target destination;
		DWORD sent;
		bool fromTrade;
	};

	inventory inv[40];
	inventory sta[40];
	inventory tra[40];
	bool _inTrade;
	bool _inStash;

	std::list<inventory> _inv;
	std::list<inventory> _sta;
	std::list<inventory> _tra;
	std::list<action> _actions;

	void _stdcall Chat(const char* name, bool whisper, const char* format, ...);
	void _stdcall Speak(const char* text);
	bool _stdcall GetChat(const char* playerName, const char* text);
	bool _stdcall OnChat(const char* text);
	void _stdcall pickUp(int item);
	void _stdcall place(int item,int x,int y,int dest);
	void _stdcall drop(int item);
	void _stdcall refreshTrade();
	void _stdcall dumpGround();
	void _stdcall dumpTrade();
	void _stdcall dumpStash();
	void _stdcall dumpInventory();
	void _stdcall dumpStashGround();
	void _stdcall dumpTradeInventory();
	void _stdcall confirmAction(int id, target destination);
	action _stdcall createAction(int id, int xPos, int yPos, target destination, bool fromTrade);
	inventory _stdcall createItem(int id, int xPos, int yPos);
	void _stdcall purgeItem(int id);
	void _stdcall reset();
	void _stdcall closeTrade();
};