// itemreader.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include "BitField.h"
#include <conio.h>
#include "ItemReader.h"
#include "BitField.h"
#include <string>
#include <iostream>


ItemReader::ItemReader()
{
}

item ItemReader::Read(unsigned char* ItemPacket)
{
	data = reinterpret_cast<void*>(ItemPacket);

	BitField field(data, sizeof(data));

	int currentPos = 0;
	int i = 0;
	
	const int sizes[] =
	{
		8, 8, 8, 8, 32, 8, 32, 32, 8, 2, 3, 16, 16, 4,
		4, 3, 4, 3, 7, 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7, 8,8,8,8, 1, 32, 12, 3, 7, 4, 1,3, 1,11, 
	};

	item thisItem;

	int action = field.ReadBits(currentPos, sizes[i]);
		switch (action)
		{
		printf("%u\n", action );
		case OwnedItem:
			{
				thisItem.PacketType = OwnedItem;
				break;
			}

		case WorldItem:
			{
				thisItem.PacketType = WorldItem;
				break;
			}
		}


		currentPos += sizes[i];
		i++;
		int ThisAction = field.ReadBits(currentPos, sizes[i]);
		switch (ThisAction)
		{
		case AddToGround:
			{
				thisItem.Action = AddToGround;
				break;
			}
		case GroundToCursor:
			{
				thisItem.Action = GroundToCursor;
				break;
			}
		case DropToGround:
			{
				thisItem.Action = DropToGround;
				break;
			}
		case OnGround:
			{
				thisItem.Action = OnGround;
				break;
			}
		case PutInContainer:
			{
				thisItem.Action = PutInContainer;
				break;
			}
		case RemoveFromContainer:
			{
				thisItem.Action = RemoveFromContainer;
				break;
			}
		case Equip:
			{
				thisItem.Action = Equip;
				break;
			}
		case IndirectlySwapBodyItem:
			{
				thisItem.Action = IndirectlySwapBodyItem;
				break;
			}
		case Unequip:
			{
				thisItem.Action = Unequip;
				break;
			}
		case SwapBodyItem:
			{
				thisItem.Action = SwapBodyItem;
				break;
			}
		case AddQuantity:
			{
				thisItem.Action = AddQuantity;
				break;
			}
		case AddToShop:
			{
				thisItem.Action = AddToShop;
				break;
			}

		case RemoveFromShop:
			{
				thisItem.Action = RemoveFromShop;
				break;
			}
		case SwapInContainer:
			{
				thisItem.Action = SwapInContainer;
				break;
			}
		case PutInBelt:
			{
				thisItem.Action = PutInBelt;
				break;
			}
		case RemoveFromBelt:
			{
				thisItem.Action = RemoveFromBelt;
				break;
			}
		case SwapInBelt:
			{
				thisItem.Action = SwapInBelt;
				break;
			}
		case AutoUnequip:
			{
				thisItem.Action = AutoUnequip;
				break;
			}
		case RemoveFromHireling:
			{
				thisItem.Action = RemoveFromHireling;
				break;
			}
		case ItemInSocket:
			{
				thisItem.Action = ItemInSocket;
				break;
			}
		case UNKNOWN1:
			{
				thisItem.Action = UNKNOWN1;
				break;
			}
		case UpdateStats:
			{
				thisItem.Action = UpdateStats;
				break;
			}
		case UNKNOWN2:
			{
				thisItem.Action = UNKNOWN2;
				break;
			}
		case WeaponSwitch:
			{
				thisItem.Action = WeaponSwitch;
				break;
			}
		}

		
		currentPos += sizes[i];
		i++;

		thisItem.PacketLength = field.ReadBits(currentPos, sizes[i]);



		currentPos += sizes[i];
		i++;

		switch (field.ReadBits(currentPos, sizes[i]))
		{
		case Helm:
			{
				thisItem.Category = Helm;
				break;
			}
		case Armor:
			{
				thisItem.Category = Armor;
				break;
			}
		case Weapon:
			{
				thisItem.Category = Weapon;
				break;
			}
		case Weapon2:
			{
				thisItem.Category = Weapon2;
				break;
			}
			case Shield:
			{
				thisItem.Category = Shield;
				break;
			}
			case Special:
				{
					thisItem.Category = Special;
					break;
				}
			case Misc:
				{
					thisItem.Category = Misc;
					break;
				}
		}


		currentPos += sizes[i];
		i++;
		

		thisItem.Id = field.ReadBits(currentPos, sizes[i]);



		currentPos += sizes[i];
		i++;

		if (thisItem.PacketType == OwnedItem)
		{
			switch (field.ReadBits(currentPos, sizes[i]))
			{
			case Player:
				{
					thisItem.OwnerType = Player;
					break;
				}
			case NPC:
				{
					thisItem.OwnerType = NPC;
					break;
				}
			case Object:
				{
					thisItem.OwnerType = Object;
					break;
				}
			case Missile:
				{
					thisItem.OwnerType = Missile;
					break;
				}
			case Item:
				{
					thisItem.OwnerType = Item;
					break;
				}
			case WP:
				{
					thisItem.OwnerType = WP;
					break;
				}
			}

			
			currentPos += sizes[i];
			i++;

			thisItem.OwnerId = field.ReadBits(currentPos, sizes[i]);

			currentPos += sizes[i];
			i++;
		}

		else
		{
			thisItem.OwnerId = -1;
			thisItem.OwnerType = None;
			i+= 2;
		}
		//Reading flags this might be ugly
		int j = 0;
		int flagPos = currentPos;
		ItemFlags thisFlags;
		int flagSizes[] = {
							1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
							1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 4
						   };

		thisFlags.Equipped = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN1 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.InSocket = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Identified = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN2 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.SwitchedIn = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.SwitchedOut = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Broken = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN3 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Potion = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Socketed = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN4 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.InStore = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.NotInSocket = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN5 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Ear = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.StartItem = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN6 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.SimpleItem = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Ethereal = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Any = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Personalized = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Gamble = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.Runeword = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN7 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisFlags.UNKNOWN8 = field.ReadBits(flagPos, flagSizes[j]);
		flagPos += flagSizes[j];
		j++;

		thisItem.Flags = thisFlags;

							

		currentPos+= sizes[i];
		i++;

		thisItem.Version = field.ReadBits(currentPos, sizes[i]);

		currentPos += sizes[i];
		i++;

		int unk1 = field.ReadBits(currentPos, sizes[i]);
		thisItem.Unknown1 = unk1;
		currentPos += sizes[i];
		i++;

		int dest = field.ReadBits(currentPos, sizes[i]);
		switch (dest)
		{
		case Unspecified:
			{
				thisItem.Destination = Unspecified;
				printf("Dest is: %u\n", dest);
				break;
			}
		case Equipment:
			{
				thisItem.Destination = Equipment;
				printf("Dest is: %u\n", dest);
				break;
			}
		case Belt:
			{
				thisItem.Destination = Belt;
				printf("Dest is: %u\n", dest);
				break;
			}
		case Ground:
			{
				thisItem.Destination = Ground;
				printf("Dest is: %u\n", dest);
				break;
			}
		case Cursor:
			{
				thisItem.Destination = Cursor;
				printf("Dest is: %u\n", dest);
				break;
			}
		case InItem:
			{
				thisItem.Destination = InItem;
				break;
			}
		}

		currentPos += sizes[i];
		i++;

		if (thisItem.Destination == Ground)
		{
			Position pos;
			pos.xPos = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			pos.yPos = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			thisItem.Pos = pos;
			i+=4;
		}
		else
		{
			i+=2;

			switch (field.ReadBits(currentPos, sizes[i]))
			{
			case Eq_NotApplicable:
				{
					thisItem.EquipLoc = Eq_NotApplicable;
					break;
				}
			case Eq_Helm:
				{
					thisItem.EquipLoc = Eq_Helm;
					break;
				}
			case Eq_Amulet:
				{
					thisItem.EquipLoc = Eq_Amulet;
					break;
				}
			case Eq_Armor:
				{
					thisItem.EquipLoc = Eq_Armor;
					break;
				}
			case Eq_RightHand:
				{
					thisItem.EquipLoc = Eq_RightHand;
					break;
				}
			case Eq_LeftHand:
				{
					thisItem.EquipLoc = Eq_LeftHand;
					break;
				}
			case Eq_RightHandRing:
				{
					thisItem.EquipLoc = Eq_RightHandRing;
					break;
				}
			case Eq_LeftHandRing:
				{
					thisItem.EquipLoc = Eq_LeftHandRing;
					break;
				}
			case Eq_Belt:
				{
					thisItem.EquipLoc = Eq_Belt;
					break;
				}
			case Eq_Boots:
				{
					thisItem.EquipLoc = Eq_Boots;
					break;
				}
			case Eq_Gloves:
				{
					thisItem.EquipLoc = Eq_Gloves;
					break;
				}
			case Eq_RightHandSwitch:
				{
					thisItem.EquipLoc = Eq_RightHandSwitch;
					break;
				}
			case Eq_LeftHandSwitch:
				{
					thisItem.EquipLoc = Eq_LeftHandSwitch;
					break;
				}
			}
			currentPos += sizes[i];
			i++;

			Position pos;
			pos.xPos = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			pos.yPos = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			thisItem.Pos = pos;

			switch (field.ReadBits(currentPos, sizes[i]))
			{
			case Inventory:
				{
					thisItem.Container = Inventory;
					break;
				}
			case Trade:
				{
					thisItem.Container = Trade;
					break;
				}
			case Cube:
				{
					thisItem.Container = Cube;
					break;
				}
			case Stash:
				{
					thisItem.Container = Stash;
					break;
				}
			}
			currentPos += sizes[i];
			i++;

		}

		if (thisItem.Flags.Ear == 1)
		{
			thisItem.EarStats.charClass = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;

			thisItem.EarStats.charLevel = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;

			std::string Name("");
			for (int j=0; j < 15; j++)
			{
				const char nextChar = char(field.ReadBits(currentPos, sizes[i]));
				if (nextChar != 0)
				{
					Name.append(1, nextChar);
					printf(".. %c\n", nextChar);
					currentPos += sizes[i];
				}

				i++;
			}

			thisItem.EarStats.charName = Name;

			return thisItem;
		}

		else
		{
			i += 17;
		}

		std::string baseItemName = "";
		for (int j=0; j < 3; j++)
		{
			const char nextChar = char(field.ReadBits(currentPos, sizes[i]));
			baseItemName.append(1, nextChar);
			currentPos += sizes[i];
			i++;
		}

		currentPos += sizes[i];
		i++;

		thisItem.BaseItem = baseItemName;

		if (stricmp(thisItem.BaseItem.c_str(), "gld") == 0)
		{
			int bigpile = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;

			int goldAmount;
			if (bigpile == 1)
			{
				goldAmount = field.ReadBits(currentPos, sizes[i]);
				i+=2;
			}
			else
			{
				i++;
				goldAmount = field.ReadBits(currentPos, sizes[i]);
				currentPos += sizes[i];
				i++;

			}
			thisItem.GoldAmount = goldAmount;

			return thisItem;
		}
		else
		{
			i+= 3;
		}


		int usedSockets = field.ReadBits(currentPos, sizes[i]);
		currentPos += sizes[i];
		i++;
		thisItem.UsedSockets = usedSockets;

		if (thisItem.Flags.SimpleItem | thisItem.Flags.Gamble == 1)
		{
			return thisItem;
		}

		int itemLevel = field.ReadBits(currentPos, sizes[i]);
		thisItem.ItemLevel = itemLevel;
		currentPos += sizes[i];
		i++;

		int quality = field.ReadBits(currentPos, sizes[i]);
		switch (quality)
		{
		case Inferior:
			{
				thisItem.Quality = Inferior;
				break;
			}
		case Normal:
			{
				thisItem.Quality = Normal;
				break;
			}
		case Superior:
			{
				thisItem.Quality = Superior;
				break;
			}
		case Magic:
			{
				thisItem.Quality = Magic;
				break;
			}
		case Set:
			{
				thisItem.Quality = Set;
				break;
			}
		case Rare:
			{
				thisItem.Quality = Rare;
				break;
			}
		case Unique:
			{
				thisItem.Quality = Unique;
				break;
			}
		case Crafted:
			{
				thisItem.Quality = Crafted;
				break;
			}
		}
		currentPos += sizes[i];
		i++;

		int hasGraphic = field.ReadBits(currentPos, sizes[i]);
		currentPos += sizes[i];
		i++;

		if (hasGraphic == 1)
		{
			int graphic = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			thisItem.Graphic = graphic;
		}
		else
		{
			i++;
		}


		int hasColor = field.ReadBits(currentPos, sizes[i]);
		currentPos += sizes[i];
		i++;

		if (hasColor == 1)
		{
			int color = field.ReadBits(currentPos, sizes[i]);
			currentPos += sizes[i];
			i++;
			thisItem.Color = color;
		}
		else
		{
			i++;
		}

		if (thisItem.Flags.Identified == 1)
		{
			int Affix[2];
			int uId;
			int offset = 0;
			switch (thisItem.Quality)
			{
			case Inferior:
				{
					offset = 3;
					Affix[0] = field.ReadBits(currentPos, offset);
					Affix[1] = -1;
					break;
				}		
			case Superior:
				{
					offset = 3;
					Affix[0] = field.ReadBits(currentPos, offset);
					Affix[1] = -1;
					break;
				}
			case Magic:
				{
					offset = 22;
					Affix[0] = field.ReadBits(currentPos, 11);
					currentPos += 11;
					Affix[1] = field.ReadBits(currentPos, 11);
					currentPos +=11;
					break;
				}
			case Rare:
				{
					offset = 16;
					Affix[0] = field.ReadBits(currentPos, 8);
					currentPos += 8;
					Affix[1] = field.ReadBits(currentPos, 8);
					currentPos += 8;
					break;
				}
			case Crafted:
				{
					offset = 16;
					Affix[0] = field.ReadBits(currentPos, 8);
					currentPos += 8;
					Affix[1] = field.ReadBits(currentPos, 8);
					currentPos += 8;
					break;
				}
			case Set:
				{
					offset = 12;
					Affix[0] = field.ReadBits(currentPos, 12);
					Affix[1] = -2;
					currentPos += offset;
					break;
				}
			case Unique:
				{
					offset = 12;
					Affix[0] = field.ReadBits(currentPos, 12);
					Affix[1] = -3;
					currentPos += offset;
					break;
				}
			}
			thisItem.ItemAffix[0] = Affix[0];
			thisItem.ItemAffix[1] = Affix[1];
		}



					



		



			
		return thisItem;





}
