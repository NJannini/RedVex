#include "Dump.h"
#include "IProxy.h"
#include "IPacket.h"
#include <stdarg.h>

/* Chat Function, writes text to screen */
void Dump::Chat(const char* name, bool whisper, const char* format, ...)
{
	char text[4096];

	va_list arguments;
	va_start(arguments, format);
	vsprintf_s(text, sizeof(text), format, arguments);
	va_end(arguments);	

	int length = static_cast<int>(strlen(text) + strlen(name)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = whisper ? 0x02 : 0x01;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = whisper ? 0x01 : 0x05;

	for (int i = 0; name[i] != '\0'; i++)
	{
		buffer[offset++] = name[i];
	}
	buffer[offset++] = 0x00;

	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	}
	buffer[offset++] = 0x00;

	IPacket* packet = _proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}

/* Speak text in the game to everyone */
void Dump::Speak(const char* text)
{
	if (strlen(text) > 0)
	{
		int size = static_cast<int>(strlen(text)) + 6;
		char* buffer = new char[size];
		int offset = 0;

		buffer[offset++] = 0x15;
		buffer[offset++] = 0x01;
		buffer[offset++] = 0x00;

		for (int i = 0; text[i] != '\0'; i++)
		{
			buffer[offset++] = text[i];
		}
		buffer[offset++] = 0x00;

		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, size);
		_proxy->RelayDataToServer(packet, this);
		delete packet;

		delete[] buffer;
	}
}
