#include "Dump.h"
#include "Command.h"

/* This function will detect what you typed and process it */
bool Dump::OnChat(const char* text)
{
	Command command(text);
	const char* commandName = command.GetParameter(0);

	if (_stricmp(commandName, ".dump") == 0)
	{
		if(command.GetParameterCount()==2)
		{
			if (_stricmp(command.GetParameter(1), "ground") == 0)
				if(!_inTrade)
				{
					if(_inStash)
						dumpStashGround();
					else
						dumpGround();
				}
				else
					Chat("",false,"�c1Do you �c8WANT �c1a Realm Down?");
			if (_stricmp(command.GetParameter(1), "trade") == 0)
				if(_inTrade)
					dumpTrade();
				else
					Chat("",false,"�c1You're not even in the �c8Trade Screen�c1, genius");
			if (_stricmp(command.GetParameter(1), "stash") == 0)
				if(_inStash)
					dumpStash();
				else
					Chat("",false,"�c1You're not even in the �c8Stash�c1, genius");
			if (_stricmp(command.GetParameter(1), "inventory") == 0)
				if(_inStash)
					dumpInventory();
				else if(_inTrade)
					dumpTradeInventory();
				else
					Chat("",false,"�c1nowhere to dump from");
		}
		if(command.GetParameterCount()>2)
		{
			if (_stricmp(command.GetParameter(1), "ground") == 0)
				Chat("",false,"�c1Pick it up yourself!");
			if (_stricmp(command.GetParameter(1), "trade") == 0)
			{
				if(_inTrade)
				{
					if (_stricmp(command.GetParameter(2), "ground") == 0)
						Chat("",false,"�c1Do you �c8WANT �c1a Realm Down?");
					if (_stricmp(command.GetParameter(2), "trade") == 0)
						Chat("",false,"�c1Duhh... OK?");
					if (_stricmp(command.GetParameter(2), "stash") == 0)
						Chat("",false,"�c1Do you �c8WANT �c1a Realm Down?");
					if (_stricmp(command.GetParameter(2), "inventory") == 0)
						dumpTradeInventory();
				}
				else
					Chat("",false,"�c1You're not even in the �c8Trade Screen�c1, genius");
			}
			if (_stricmp(command.GetParameter(1), "stash") == 0)
			{
				if(_inStash)
				{
					if (_stricmp(command.GetParameter(2), "ground") == 0)
						dumpStashGround();
					if (_stricmp(command.GetParameter(2), "trade") == 0)
						Chat("",false,"�c1Do you �c8WANT �c1a Realm Down?");
					if (_stricmp(command.GetParameter(2), "stash") == 0)
						Chat("",false,"�c1Duhh... OK?");
					if (_stricmp(command.GetParameter(2), "inventory") == 0)
						dumpInventory();
				}
				else
					Chat("",false,"�c1You're not even in the �c8Stash�c1, genius");
			}
			if (_stricmp(command.GetParameter(1), "inventory") == 0)
			{
				if (_stricmp(command.GetParameter(2), "ground") == 0)
					if(!_inTrade)
						dumpGround();
					else
						Chat("",false,"�c1Do you �c8WANT �c1a Realm Down?");
				if (_stricmp(command.GetParameter(2), "trade") == 0)
					if(_inTrade)
						dumpTrade();
					else
						Chat("",false,"�c1You're not even in the �c8Trade Screen�c1, genius");
				if (_stricmp(command.GetParameter(2), "stash") == 0)
					if(_inStash)
						dumpStash();
					else
						Chat("",false,"�c1You're not even in the �c8Stash�c1, genius");
				if (_stricmp(command.GetParameter(2), "inventory") == 0)
					Chat("",false,"�c1Duhh... OK?");
			}
		}
		return true;
	}
	return false;
}