#include "Dump.h"
#include "IPacket.h"
#include "IProxy.h"
//#include <winsock2.h>
//#include <windows.h>

const char Dump::_chatName[] = "�c4Dump";

Dump::Dump(IProxy* proxy) :
	_proxy(proxy),
	_inTrade(false),
	_inStash(false)
{
 //initialize stuff
}

void __stdcall Dump::Destroy()
{
	delete this;
}

/*Dump::~Dump()
{

}*/
void Dump::pickUp(int item)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x19;
	*reinterpret_cast<int*>(buffer + offset) = item;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Dump::place(int item,int x,int y,int dest)//0=inventory,1=trade,2=stash
{
	unsigned char buffer[17];
	int offset = 0;
	buffer[offset++] = 0x18;
	*reinterpret_cast<int*>(buffer + offset) = item;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = x;
	offset += sizeof(int);
	*reinterpret_cast<int*>(buffer + offset) = y;
	offset += sizeof(int);
	switch(dest){
		case 0: buffer[offset++] = 0x00;break;
		case 1: buffer[offset++] = 0x02;break;
		case 2: buffer[offset++] = 0x04;break;
	}
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Dump::drop(int item)
{
	unsigned char buffer[5];
	int offset = 0;
	buffer[offset++] = 0x17;
	*reinterpret_cast<int*>(buffer + offset) = item;
	offset += sizeof(int);
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}
void Dump::refreshTrade()
{
	unsigned char buffer[7];
	int offset = 0;
	buffer[offset++] = 0x4F;
	buffer[offset++] = 0x07;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
	offset = 0;
	buffer[offset++] = 0x4F;
	buffer[offset++] = 0x08;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
}
void Dump::dumpGround()
{
	Chat("",false,"�c1Dumping �c8Inventory �c1to the �c8Ground...");
	for (std::list<inventory>::iterator i = _inv.begin(); i != _inv.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,false);
		action action2=createAction(i->id,i->xPos,i->yPos,ground,false);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}
}
void Dump::dumpTrade()
{
	Chat("",false,"�c1Dumping �c8Inventory �c1to the �c8Trade Screen...");
	for (std::list<inventory>::iterator i = _inv.begin(); i != _inv.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,false);
		action action2=createAction(i->id,i->xPos,i->yPos,trade,false);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}
}
void Dump::dumpStash()
{
	Chat("",false,"�c1Dumping �c8Inventory �c1to the �c8Stash...");
	for (std::list<inventory>::iterator i = _inv.begin(); i != _inv.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,false);
		action action2;
		if(i->xPos<=5)
			action2=createAction(i->id,i->xPos,i->yPos,stash,false);
		else
			action2=createAction(i->id,i->xPos-6,i->yPos+4,stash,false);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}
}
void Dump::dumpInventory()
{
	int dumped=0;
	Chat("",false,"�c1Dumping �c8Stash �c1to the �c8Inventory...");
	for (std::list<inventory>::iterator i = _sta.begin(); i != _sta.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,false);
		action action2;
		if(i->yPos<=3)
			action2=createAction(i->id,i->xPos,i->yPos,invent,false);
		else
			action2=createAction(i->id,i->xPos+6,i->yPos-4,invent,false);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}
}
void Dump::dumpStashGround()
{
	int dumped=0;
	Chat("",false,"�c1Dumping �c8Stash �c1to the �c8Ground...");
	for (std::list<inventory>::iterator i = _sta.begin(); i != _sta.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,false);
		action action2=createAction(i->id,i->xPos,i->yPos,ground,false);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}
}
void Dump::dumpTradeInventory()
{
	int dumped=0;
	Chat("",false,"�c1Dumping �c8Trade �c1to the �c8Inventory...");
	closeTrade();
	Chat("",false,"�c2Dump Finished");
	/* I've had enough temporary suspensions!
	for (std::list<inventory>::iterator i = _tra.begin(); i != _tra.end(); i++)
	{
		action action1=createAction(i->id,i->xPos,i->yPos,cursor,true);
		action action2=createAction(i->id,i->xPos,i->yPos,invent,true);
		_actions.push_back(action1);
		_actions.push_back(action2);
	}*/
}

void Dump::confirmAction(int id, target destination)
{
	if(!_actions.empty())
		if(id==_actions.front().id && destination==_actions.front().destination)
		{
			char dest[16];
			switch(destination){
				case ground: strcpy(dest,"ground"); break;
				case cursor: strcpy(dest,"cursor"); break;
				case invent: strcpy(dest,"inventory"); break;
				case stash: strcpy(dest,"stash"); break;
				case trade: strcpy(dest,"trade"); break;
				default: strcpy(dest,"somewhere"); break;
			}
			Chat("",false,"�c3Sent �c8%u �c3to �c8%s",id,dest);
			_actions.erase(_actions.begin());
			if(_actions.empty())
				Chat("",false,"�c2Dump Finished");
		}
}

Dump::action Dump::createAction(int id, int xPos, int yPos, target destination, bool fromTrade)
{
	action thisAction;
	thisAction.id=id;
	thisAction.xPos=xPos;
	thisAction.yPos=yPos;
	thisAction.sends=0;
	thisAction.destination=destination;
	thisAction.sent=GetTickCount();
	thisAction.fromTrade=fromTrade;
	return thisAction;
}

Dump::inventory Dump::createItem(int id, int xPos, int yPos)
{
	inventory thisInventory;
	thisInventory.id=id;
	thisInventory.xPos=xPos;
	thisInventory.yPos=yPos;
	return thisInventory;
}

void Dump::purgeItem(int id)
{
	if(!_sta.empty())
		for (std::list<inventory>::iterator i = _sta.begin(); i != _sta.end(); i++)
			if(i->id==id){
				_sta.erase(i);
				break;
			}
	if(!_inv.empty())
		for (std::list<inventory>::iterator i = _inv.begin(); i != _inv.end(); i++)
			if(i->id==id){
				_inv.erase(i);
				break;
			}
	if(!_tra.empty())
		for (std::list<inventory>::iterator i = _tra.begin(); i != _tra.end(); i++)
			if(i->id==id){
				_tra.erase(i);
				break;
			}
}

void Dump::reset()
{
	_sta.clear();
	_tra.clear();
	_inv.clear();
}

void Dump::closeTrade()
{
	unsigned char buffer[7];
	int offset = 0;
	buffer[offset++] = 0x4F;
	buffer[offset++] = 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	IPacket* packet = _proxy->CreatePacket(buffer, offset);
	_proxy->RelayDataToServer(packet, this);
	delete packet;
}