#include "Dump.h"
//#include <windows.h>

/* This function is called when Redvex has nothing else to do */
void Dump::Update()
{
	if(!_actions.empty()){
		if(GetTickCount()-_actions.front().sent>150){
			if(_actions.front().sends<11){
				char dest[16];
				switch(_actions.front().destination){
					case ground: strcpy(dest,"ground"); break;
					case cursor: strcpy(dest,"cursor"); break;
					case invent: strcpy(dest,"inventory"); break;
					case stash: strcpy(dest,"stash"); break;
					case trade: strcpy(dest,"trade"); break;
					default: strcpy(dest,"somewhere"); break;
				}
				if(_actions.front().sends>0)
					Chat("",false,"�c9Resending �c8%s action �c9due to latency... %u",dest,_actions.front().id);
				switch(_actions.front().destination){
					case ground: drop(_actions.front().id); _actions.front().sent=GetTickCount(); break;
					case cursor: pickUp(_actions.front().id); _actions.front().sent=GetTickCount(); break;
					case invent: place(_actions.front().id,_actions.front().xPos,_actions.front().yPos,0); _actions.front().sent=GetTickCount(); break;
					case stash: place(_actions.front().id,_actions.front().xPos,_actions.front().yPos,2); _actions.front().sent=GetTickCount(); break;
					case trade: place(_actions.front().id,_actions.front().xPos,_actions.front().yPos,1); _actions.front().sent=GetTickCount(); break;
				}
				if(_actions.front().fromTrade)
					refreshTrade();
				_actions.front().sends++;
			}
			else{
				_actions.clear();
				Chat("",false,"�c1Dumping �c8Failed�c1...");
			}
		}
	}
}