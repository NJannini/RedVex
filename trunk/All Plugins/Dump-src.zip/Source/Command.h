#pragma once
#include <vector>

class Command
{
public:
	Command(const char* commandLine);
	Command();
	~Command();

	int _stdcall Parse(const char* commandLine, const char* delimiters = " \t\n");
	void _stdcall Clear();
	char* GetParameter(int index, char* parameter, int size) const;
	const char* GetParameter(int index) const;
	int _stdcall GetParameterCount() const;

private:
	std::vector<const char*> _parameters;
	char* _tokens;
};
