#include "Dump.h"
#include "IPacket.h"
#include "Item.h"
#include "ItemReader.h"
#include "BitField.h"
#include <shlwapi.h>

void Dump::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>(packet->GetData());
	int packetId = bytes[0];
	switch(packetId)
	{
		case 0x9c: //world item action
		{
			unsigned char* buffer = new unsigned char[packet->GetSize()];
			memcpy(buffer, packet->GetData(), packet->GetSize());
			item thisItem = ItemReader::ItemReader().Read(buffer);
			delete[] buffer;
			if(thisItem.Action==DropToGround && !_actions.empty()){
				confirmAction(thisItem.Id,ground);
				purgeItem(thisItem.Id);
			}
			if(thisItem.Action == PutInContainer && thisItem.Container == 11 && !_inTrade)
			{
				confirmAction(thisItem.Id,stash);
				purgeItem(thisItem.Id);
				inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
				_sta.push_back(thisInventory);
			}
			if(thisItem.Action == PutInContainer && thisItem.Container == Inventory)
			{
				confirmAction(thisItem.Id,invent);
				purgeItem(thisItem.Id);
				inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
				_inv.push_back(thisInventory);
			}
			if(thisItem.Action == PutInContainer && thisItem.Container == 11 && _inTrade)
			{
				confirmAction(thisItem.Id,trade);
				purgeItem(thisItem.Id);
				inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
				_tra.push_back(thisInventory);
			}
			if(thisItem.Action == SwapInContainer)
			{
				if(thisItem.Destination == Cursor)
				{
					confirmAction(thisItem.Id,cursor);
					purgeItem(thisItem.Id);
				}
				if(thisItem.Container==2)
				{
					inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
					_inv.push_back(thisInventory);
				}
				if(thisItem.Container==11){
					if(_inTrade){
						inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
						_tra.push_back(thisInventory);
					}
					if(!_inTrade){
						inventory thisInventory=createItem(thisItem.Id,thisItem.Pos.xPos,thisItem.Pos.yPos);
						_sta.push_back(thisInventory);
					}
				}
			}
		}	
		break;
		case 0x9d: //owned item action
		{
			unsigned char* buffer = new unsigned char[packet->GetSize()];
			memcpy(buffer, packet->GetData(), packet->GetSize());
			item thisItem = ItemReader::ItemReader().Read(buffer);
			delete[] buffer;
			if(thisItem.Action == RemoveFromContainer)
			{
				confirmAction(thisItem.Id,cursor);
				purgeItem(thisItem.Id);
			}
		}
		break;
		case 0x77: //More Trade Stuffs
		{
			switch(bytes[1]){
				case 0x09:/*Chat("",false,"Oops, no room");*/break;
				case 0x10:/*Chat("",false,"Stash is Open");*/_inStash=true;break;
				case 0x0C: if(_inTrade){/*Chat("",false,"RESET 2");*/ reset(); _inTrade=false;} break;
				//case 0x0D: Chat("",false,"RESET 3"); reset(); _inTrade=false; break;
			}
		}
		break;
		case 0x78: //Even More Trade Stuffs
		{
			//Chat("",false,"_inTrade=true");
			_inTrade=true;
		}
		break;
	}
}