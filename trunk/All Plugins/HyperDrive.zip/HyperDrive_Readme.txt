HyperDrive.dll

A teleport extender for RedVex by Turlok!

This plugin allows you to teleport further.

************************************************************

Installing Stash.dll:
Step 1: Put HyperDrive.dll into your Plugins folder
Step 2: Put HyperDrive.ini into your RedVex folder
Step 3: Edit and save HyperDrive.ini
Step 4: Update RedVex
Step 5: High-Five! Your done!

************************************************************

in-game commands:

Commands
--------------
.boost		-> toggles boosting teleports on/off

************************************************************

Setting up HyperDrive.ini:

[Default]		//This is the setting  for All characters besides additional entries created below
BoostTeleport=1		//Set this to 1 to boost all characters teleports by default, 0 to disable

[MyCharacterName]	//change MyCharacterName to the name of your character for character-specific settings
BoostTeleport=0		//Set this to 1 to boost MyCharacterName's teleports by default, 0 to disable
			
[MyOtherChar]		//You can create as many single character settings as you want
BoostTeleport=1		//just remember that names are CaSeSeNsItIvE
