Automaton.dll

A follow bot for Redvex by Turlok!

This plugin allows you to use a character like a mercenary, following you and protecting you from a minimized screen!

************************************************************

Installing Automaton.dll:
Step 1: Put Automaton.dll into your Plugins folder
Step 2: Put automatons folder into your Redvex folder
Step 3: Create a copy Default.ini named YoUrChArAcTeRnAmE.ini
Step 4: Configure YoUrChArAcTeRnAmE.ini
Step 5: Put YoUrChArAcTeRnAmE.ini into automatons folder
Step 6: Update RedVex
Step 7: High-Five! Your done!

************************************************************

in-game commands (from your window):
Below commands are activated from the window of the desired character:

.follow <player> -> runs the Automaton script to follow/assist <player>.
		 -> <player> must be in your party, and will not be allowed
		 -> to issue verbal commands.
.follow		 -> toggles the Automaton script on/off
.guard		 -> causes your character to stand/fight in place.

************************************************************

in-game commands (from master's window):
Below commands are activated verbally by the master of the desired character:

follow		 -> runs the Automaton script to follow/assist the master
		 -> master must be in the same party.
chill		 -> turns the Automaton script off completely.
guard		 -> causes the Automaton to stand/fight in place.
safe		 -> causes the Automaton to take it's own TP.
1		 -> causes the Automaton to take it's master's TP.
tp		 -> causes the Automaton to open a TP.
town		 -> causes the Automaton to open a TP and take it to wait in town.
bail		 -> causes the Automaton to leave the game.
shop		 -> starts the Automaton shopping sequence (must be near a valid vendor)
hold		 -> Automaton will accept a trade from master only.
hate		 -> Automaton will go hostile with those not in party

************************************************************

CONFIGURATION:

[Main]
Master=Turlok	// The name of the master (only one who may give spoken commands)
AutoRelease=1	// Toggle Automatically release corpse on death on/off
Speak=1		// Toggle overhead responses on/off
UseTeleport=0	// Toggle teleporting on/off
Melee=0		// Toggle Melee mode on/off (only attack monsters within leash range)
Leash=15	// max distance(yards) automaton is allowed to fight/roam
TeleLeash=30	// max distance(yards) before automaton is forced to teleport
Spacing=5	// min distance(yards) automaton is allowed to stand by you (out of fights)
HideFromPKs=1	// if a player becomes hostile, this feature will have the automaton go to town and stay there, if it cannot go to town it will exit.
PickTP=1	// automaton will pick up TPs until it's tome is full, 0=off
PickGold=1	// automaton will pick up gold, 0=off
PickMana=4	// automaton will pick up mana potions until it has this many, 0=off
PickLife=4	// automaton will pick up life potions until it has this many, 0=off
PickJuve=4	// automaton will pick up juve potions until it has this many, 0=off
PickBolts=0	// automaton will pick up bolts until it has this many, 0=off
PickArrows=0	// automaton will pick up arrows until it has this many, 0=off

[Shrines]
ManaRecharge=0	// preference level of shrine, 0=never pick up
Armor=1		// preference level of shrine, 0=never pick up
Combat=0	// preference level of shrine, 0=never pick up
Experience=3	// preference level of shrine, 0=never pick up
Skill=2		// preference level of shrine, 0=never pick up
Stamina=1	// preference level of shrine, 0=never pick up
ResistFire=1	// preference level of shrine, 0=never pick up
ResistCold=1	// preference level of shrine, 0=never pick up
ResistLighting=1// preference level of shrine, 0=never pick up
ResistPoison=1	// preference level of shrine, 0=never pick up

[Amazon]
Decoy=0		// Amazon will keep a decoy active in battle, 0=off
Valkyrie=0	// Amazon will keep a valkyrie active, 0=off

[Assassin]
MainTrap=0	// skillID(Attacks.txt) of your main trap (3/5 of your traps) to keep active in battle, 0=off
OffTrap=0	// skillID(Attacks.txt) of your secondary trap (2/5 of your traps) to keep active in battle, 0=off
ShadowWarrior=0 // Assassin will keep a shadow warrior active, 0=off
ShadowMaster=0	// Assassin will keep a shadow master active, 0=off

[Necromancer]
UseCurse=0	// skillID(Attacks.txt) of the curse the Necromancer will use in battle (free from sequenced attacks), 0=off
CurseCooldown=0 // cooldown(milliseconds) of casting the curse
NecroSkeli=0	// number of skeleton warriors to keep summoned, 0=off
NecroMage=0	// number of skeleton mages to keep summoned, 0=off
Revive=0	// number of revives to keep summoned, 0=off
ClayGolem=0	// Necromancer will keep this golem summoned, 0=off
BloodGolem=0	// Necromancer will keep this golem summoned, 0=off
FireGolem=0	// Necromancer will keep this golem summoned, 0=off

[Barbarian]
FindItems=0	// Barbarian will find items from corpses after battle, 0=off

[Paladin]
FightAura=0	// Paladin will use this aura during a fight, 0=off
ClearAura=0	// Paladin will use this aura when the coast is clear, 0=off
MoveAura=0	// Paladin will use this aura while moving, 0=off
Cleric=0	// Paladin will cast holy bolt at friendly players below 90% life, 0=off

[Sorceress]
Enchanter=0	// Sorceress will keep enchant up on friendly players/minions

[Druid]
Raven=0		// Druid will keep this many ravens summoned
SpiritWolf=0	// Druid will keep this many spirit wolves summoned
DireWolf=0	// Druid will keep this many dire wolves summoned
Grizzly=0	// Druid will keep this many grizzlys summoned
OakSage=0	// Druid will keep oak sage summoned
HeartOfTheWolverine=0	// Druid will keep heart of the wolverine summoned
SpiritOfBarbs=0	// Druid will keep spirit of barbs summoned
PoisonCreeper=0 // Druid will keep poison creeper summoned
CarrionVine=0	// Druid will keep carrion vine summoned
SolarCreeper=0	// Druid will keep solar creeper summoned

[Precast]
Timer=120000	// Time(milliseconds) between repeating the precast sequence
Precast1=0	// skillID(Attacks.txt) of precast spell, 0=off
Precast2=0	// skillID(Attacks.txt) of precast spell, 0=off
Precast3=0	// skillID(Attacks.txt) of precast spell, 0=off
Precast4=0	// skillID(Attacks.txt) of precast spell, 0=off

[Attack]
Hand1=0		// 0=no attack, 1=left-click attack, 2=right-click attack
Hand2=0		// 0=no attack, 1=left-click attack, 2=right-click attack
Hand3=0		// 0=no attack, 1=left-click attack, 2=right-click attack
Hand4=0		// 0=no attack, 1=left-click attack, 2=right-click attack
Attack1=0	// skillID(Attacks.txt) of attack spell
Attack2=0	// skillID(Attacks.txt) of attack spell
Attack3=0	// skillID(Attacks.txt) of attack spell
Attack4=0	// skillID(Attacks.txt) of attack spell
Repeat1=0	// number of times to use this attack in sequence
Repeat2=0	// number of times to use this attack in sequence
Repeat3=0	// number of times to use this attack in sequence
Repeat4=0	// number of times to use this attack in sequence
Cooldown1=500	// Time(milliseconds) to wait before proceeding to the next attack in sequence
Cooldown2=500	// Time(milliseconds) to wait before proceeding to the next attack in sequence
Cooldown3=500	// Time(milliseconds) to wait before proceeding to the next attack in sequence
Cooldown4=500	// Time(milliseconds) to wait before proceeding to the next attack in sequence

************************************************************

SPECIAL CASE SPELLS/ATTACKS:

Telekinesis	-> Automaton will automatically detect this spell, and widen the pickup range
		-> and use telekinesis to pick up potions/gold/etc
Novas/Infernos	-> Automaton will automatically detect the range for these spells, and only use
		-> them in sequence if monsters are in range, or close enough to move in range
		-> of and cast without outstepping the bounds of the running leash
Static Field	-> Automaton will automatically detect the range for this spell, and only use it
		-> if monsters are in range.  It will not, however, move into range.
Corpse Explosion-> Automaton will automatically detect the range for this spell, and only use it
		-> on corpses in range of hostile targets.

************************************************************

GATEWAY LOGIC IMPROVEMENTS:

->You no longer have to "run to" the gateways(doors/stairs) for automaton to attempt to follow.  It now
uses a logical heirarchy of remembered gateways.  However, doing so will still tag the correct gateway
and ensure it doesn't make a mistake.

->Automaton will not attempt to follow you through a waypoint unless it has the destination waypoint.  additionally,
if you come accross a waypoint in an area it does not yet own, automaton will automatically attempt to grab the waypoint
when the coast is clear.  Simply stand on/nearby wps that your automaton character doesn't have for a few moments.

************************************************************

RECOVERY STATES:

If the bot becomes "lost", it may enter a certain logic "state" and adapt certain behaviors:

LOST (OUT OF TOWN) -> Automaton will wait to be picked up for 10 seconds, then attempt to portal to town
LOST (INSIDE TOWN) -> Automaton will wait to be picked up for 10 seconds, then ask the master for a town portal (if allowed to speak)
WAITING FOR TP	   -> After asking for a town portal, the bot will now take the next TP the master makes (if in range)
WAITING FOR PK	   -> If configured to hide from PKs, the Automaton will wait in town until no players are aggressive to it.

************************************************************

CHAT LOG:

Automaton will log useful information about what it's doing to the screen/chat log.