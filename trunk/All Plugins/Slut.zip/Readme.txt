Slut.dll

A follow bot for Redvex by Turlok!  It is always advisable to use a condom when involved with a slut!  Download Condom.dll just to be safe!

This plugin allows you to use a character like a mercenary, following you and protecting you from a minimized screen!

************************************************************

Installing Slut.dll:
Step 1: Put Slut.dll into your Plugins folder
Step 2: Put sluts folder into your Redvex folder
Step 3: Create a copy Template.ini named YOURCHARACTERNAME.ini
Step 4: Configure YOURCHARACTERNAME.ini
Step 5: Put YOURCHARACTERNAME.ini into sluts folder
Step 6: Update RedVex
Step 7: High-Five! Your done!

************************************************************

in-game commands:

Commands will only be executed when the bot's designated Master says them.
follow -> initiates the bot, which will now follow and protect you
guard -> tells the bot to stop following you, but still fight nearby monsters
switch -> tells the bot to switch weapons (w)
precast -> tells the bot to cast its precasting skills
chill -> turns off the bot, which will leave your character idle
bail -> tells the bot to exit the game
1 -> tells the bot to take your TP, the bot must be near your TP
safe -> tells the bot to take it's own TP (in case of chicken-to-town)
unsummon -> tells the bot to unsummon all necro summons (will not interrupt this process)

************************************************************

configuring YOURCHARACTERNAME.ini:
This file must be named for the character it refers to.  The file name is CaSe SeNsItIvE.
Use Attacks.txt to look up skill IDs.

[Main]
Master=My_Master //this is the name of your character's master, this is CaSe SeNsItIvE.
Speak=1 //Toggle for speech
UseTeleport=0 //set to 1 if your character has teleport, 0 if it does not
UseAura=0 //set to the skill ID of the aura you want to use w/o wasting an attack
NecroSkeli=0 //set to the number of maximum skeletons you can summon
NecroMage=0 //set to the number of maximum skeleton mages you can summon
Revive=0 //set to the number of maximum revives you can summon
Leash=10 //maximum distance before you will be pulled out of attack sequence to follow master
TeleLeash=20 //maximum distance before you will use teleport to catch up to master
PickGold=1 //set to 1 if you want slut to pick up gold piles
PickMana=1 //set to 1 if you want slut to pick up mana potions until belt full
PickLife=1 //set to 1 if you want slut to pick up life potions until belt full
PickJuve=0 //set to 1 if you want slut to pick up juve potions until belt full
[Precast]
Precast1=0 //skill ID of your precast in the sequence.  Set to 0 if this is the end of your precasts
Precast2=0 //skill ID of your precast in the sequence.  Set to 0 if this is the end of your precasts
Precast3=0 //skill ID of your precast in the sequence.  Set to 0 if this is the end of your precasts
Precast4=0 //skill ID of your precast in the sequence.  Set to 0 if this is the end of your precasts
[Attack]
Hand1=0 //What hand are you attacking with?  Make sure you're allowed to have your skill on this hand, 0=end of sequence, 1=left, 2=right
Hand2=0 //What hand are you attacking with?  Make sure you're allowed to have your skill on this hand, 0=end of sequence, 1=left, 2=right
Hand3=0 //What hand are you attacking with?  Make sure you're allowed to have your skill on this hand, 0=end of sequence, 1=left, 2=right
Attack1=0 //skill ID of your attack in the sequence.  look these up in Attacks.txt
Attack2=0 //skill ID of your attack in the sequence.  look these up in Attacks.txt
Attack3=0 //skill ID of your attack in the sequence.  look these up in Attacks.txt
Repeat1=0 //how many times will you repeat this attack before moving on to the next one in the sequence?
Repeat2=0 //how many times will you repeat this attack before moving on to the next one in the sequence?
Repeat3=0 //how many times will you repeat this attack before moving on to the next one in the sequence?
Cooldown1=0 //how long (MILLISECONDS) do you need to wait before casting again after this attack?
Cooldown2=0 //how long (MILLISECONDS) do you need to wait before casting again after this attack?
Cooldown3=0 //how long (MILLISECONDS) do you need to wait before casting again after this attack?

************************************************************

Changing Areas:
It is important that you 'run into' doorways/tps of new areas if you want the bot to follow you.  This means you have to click the tp/doorway with enough space so that your character must walk/run before you enter the new area, otherwise the bot will not know where you have gone.

************************************************************