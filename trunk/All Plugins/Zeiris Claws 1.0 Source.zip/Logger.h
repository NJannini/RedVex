#pragma once


void LogItem(const char* path, item& Item);
void Log(const char* path, const char* format, ...);
//void SilentLog(const char* filename, const char* format, ...);