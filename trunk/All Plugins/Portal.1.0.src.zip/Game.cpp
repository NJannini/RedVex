#include "Game.h"

Game::Game(IProxy* proxy,Manager* manager) :
	_proxy(proxy),
	_manager(manager)
{ 
	// Add your code
	Manager::bGameConnected = true;
}

void __stdcall Game::Destroy()
{
	// Add your code
	Manager::bGameConnected = false;
	delete this;
}

void Game::Update()
{
	// Add your code
}