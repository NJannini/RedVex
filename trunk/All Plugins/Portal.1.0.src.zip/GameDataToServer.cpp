#include "Game.h"


void Game::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const BYTE* bytes = static_cast<const BYTE*>( packet->GetData() );
	UINT iPacket;
	iPacket = bytes[0];
	switch (iPacket) {
		//chat packet
		case 0x15: {
			if ((bytes[3]=='.') &
				(bytes[4]=='t') &
				(bytes[5]=='p')) {
				
				//send "run" packet
				unsigned char* buffer1 = new unsigned char[5];

				buffer1[0] = 0x03; //run packet ID

				*(unsigned short*)&buffer1[1] = tpX-1;
				*(unsigned short*)&buffer1[3] = tpY-1;

				IPacket* sendpacket = _proxy->CreatePacket(buffer1, 5);
   				_proxy->RelayDataToServer(sendpacket, this);
   				delete sendpacket;
 				delete[] buffer1;
					
				//send "run" packet
				unsigned char* buffer = new unsigned char[16];

				buffer[0] = 0x0f; //run packet ID
				buffer[1] = 0x00;
				*(unsigned int*)&buffer[2] = myID;
				buffer[6] = 0x17;
				*(unsigned short*)&buffer[7] = tpX-1;
				*(unsigned short*)&buffer[9] = tpY-1;
				buffer[11] = 0x00;
				*(unsigned int*)&buffer[12] = 0x0000;

				IPacket* sendcpacket = _proxy->CreatePacket(buffer, 16);
   				_proxy->RelayDataToClient(sendcpacket, this);
   				delete sendcpacket;
 				delete[] buffer;
					
					
				packet->SetFlag(packet->PacketFlag_Dead);
				Chat("Necrophile", false, "walking behind last town portal to enter sight range");
			}
			} break;
	}

	
}

void Game::Chat(const char* name, bool whisper, const char* format, ...)
{
   char text[4096];

   va_list arguments;
   va_start(arguments, format);
   vsprintf_s(text, sizeof(text), format, arguments);
   va_end(arguments);   

   int length = static_cast<int>(strlen(text) + strlen(name)) + 12;
   unsigned char* buffer = new unsigned char[length];
   int offset = 0;

   buffer[offset++] = 0x26;
   buffer[offset++] = whisper ? 0x02 : 0x01;
   buffer[offset++] = 0x00;
   buffer[offset++] = 0x02;
   buffer[offset++] = 0x00;
   buffer[offset++] = 0x00;
   buffer[offset++] = 0x00;
   buffer[offset++] = 0x00;
   buffer[offset++] = 0x00;
   buffer[offset++] = whisper ? 0x01 : 0x05;

   for (int i = 0; name[i] != '\0'; i++)
   {
      buffer[offset++] = name[i];
   }
   buffer[offset++] = 0x00;

   for (int i = 0; text[i] != '\0'; i++)
   {
      buffer[offset++] = text[i];
   }
   buffer[offset++] = 0x00;

   IPacket* packet = _proxy->CreatePacket(buffer, length);
   packet->SetFlag(IPacket::PacketFlag_Hidden);
   _proxy->RelayDataToClient(packet, this);
   delete packet;

   delete[] buffer;
}