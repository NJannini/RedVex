#include "Game.h"

void Game::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{
	const BYTE* bytes = static_cast<const BYTE*>( packet->GetData() );
	UINT iPacket;
	iPacket = bytes[0];
	switch (iPacket) {
		case 0x0B:
			myID = *reinterpret_cast<const int*>(bytes + 2); // game entered, init
		break;
		case 0x51:
			if ((bytes[1]==0x02) && (bytes[6]==0x3b) && (bytes[7]==0x00) && (bytes[13]==0x01)) {
				tpX = *reinterpret_cast<const unsigned short*>(bytes + 8);
				tpY = *reinterpret_cast<const unsigned short*>(bytes + 10);
			//	Chat("Portal",false,"Type .tp to hide behind your town portal.");
			}
		break;
	}

}