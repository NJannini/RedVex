Precision.dll

An auto-aim plugin for RedVex by Turlok!

This plugin will redirect missed attacks made nearby enemies as name-lock attacks.
You will know you've scored a name-lock attack when the unit lights up with the set-bonus aura.

************************************************************

Installing Precision.dll:
Step 1: Put Precision.dll into your Plugins folder
Step 2: Put Precision.ini into your RedVex folder
Step 3: Edit and save Precision.ini
Step 4: Update RedVex
Step 5: High-Five! Your done!

************************************************************

in-game commands:

Commands
--------------
.target		-> shows the list of in-game players
.target #	-> sets player with number # to focus, precision will only redirect to this player
.target all	-> sets precision to target all players and monsters
.target player	-> sets precision to target all players
.target off	-> turns off percision
.mr #		-> change the MonsterRadius for this game to # yards
.pr #		-> change the PlayerRadius for this game to # yards
.fr #		-> change the FocusRadius for this game to # yards

