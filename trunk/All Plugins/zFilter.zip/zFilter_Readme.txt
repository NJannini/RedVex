zFilter.dll

A filter plugin for RedVex by Turlok!

This plugin will filter out annoying / useless crap.

************************************************************

Installing zFilter.dll:
Step 1: Put zFilter.dll into your Plugins folder
Step 2: Put zFilter.ini into your RedVex folder
Step 3: Put squelch.txt into your RedVex folder
Step 4: Edit and save zFilter.ini
Step 5: Update RedVex
Step 6: High-Five! Your done!

************************************************************

in-game commands:

Commands
--------------
.corpse		-> toggles filtering corpses for this game
.quality #	-> set the item quality # to filter for this game
.gold #		-> set the gold pile # to filter for this game
.ear		-> toggles filtering ears for this game
.spam		-> toggles filtering spam for this game
.level #	-> set the level # to auto-squelch for this game