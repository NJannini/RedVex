ConnectionProtection.dll

Directory cleanup for RedVex by Turlok!

This plugin automatically removes all the bncache-#.dat files in your d2 directory when you startup redvex.  These files will sometimes prevent the client from connecting to battle.net ie: clientside ban.

************************************************************

Installing ConnectionProtection.dll:
Step 1: Put ConnectionProtection.dll into your Plugins folder
Step 2: Put ConnectionProtection.ini into your RedVex folder
Step 3: Update RedVex
Step 4: High-Five! Your done!

************************************************************

ConnectionProtection.ini

This file is the reference for your D2 Directory path.  The default path is C:\Program Files\Diablo II.  If you have Diablo installed in another directory, you must change it here.

************************************************************