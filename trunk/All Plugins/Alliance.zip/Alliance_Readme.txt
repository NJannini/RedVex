Alliance.dll

An auto-party plugin for RedVex by Turlok!

This plugin will automatically perform party functions.
This plugin will change the format of player leave/join/drop/silent-exit/messages to reflect party status.

************************************************************

Installing Alliance.dll:
Step 1: Put Alliance.dll into your Plugins folder
Step 2: Put Alliance.ini into your RedVex folder
Step 3: Edit and save Alliance.ini
Step 4: Update RedVex
Step 5: High-Five! Your done!

************************************************************

in-game commands:

Commands
--------------
.party	-> toggles auto-party for the current game
.loot	-> toggles auto-loot for the current game
