Chanter.dll

An enchant bot plugin for RedVex by Turlok!

This plugin is a stand-alone chant bot.  It features autoparty and enchanting commands.  NOTE: If a player goes hostile with the chanter's party while in enchanter mode, she will tell them off and squelch them - preventing them from using any commands until they rejoin.

************************************************************

Installing Chanter.dll:
Step 1: Put Chanter.dll into your Plugins folder
Step 2: Put Chanter.ini into your RedVex folder
Step 3: Update RedVex
Step 4: High-Five! Your done!

************************************************************

in-game commands:

.enchant -> toggles enchanter mode on/off *YOU MUST HAVE THE ENCHANT SPELL* [default off]
.party -> toggles auto-party mode on/off (someone keep joining that you dont like?) [default on]
.spam -> toggles auto-squelch-spammers mode on/off (don't enjoy people spamming commands?) [default on]
.list -> toggles shitlist-on-hostile mode on/off (In honor of pks who suck too badly to actually build a character) [default on]

[the following commands work only when enchanter mode is ON]

party (also pp) -> when a player says this, they will receive a party invite
chant -> when a player in the chanters party says this, they will receive a chant
chantmerc -> when a player in the chanters party says this, the chanter will chant that player's merc
chantall -> when a player in the chanters party says this, they will receive a chant for themselves, merc, and summons

************************************************************

Chanter.ini:
Chanter=Turlok //put your chanter's charactername here to automatically load (CaSe-SeNsiTiVe)
AutoParty=1 //toggle default autoparty mode
AutoSquelchSpammers=1 //toggle default spammersquelch mode
ShitlistPKs=1 //toggle default shitlist mode
MessageOnJoin=1 //toggle join messages
MessageOnDeath=1 //toggle death messages
MessageOnLevel=1 //toggle level messages

************************************************************

About shitlist:

Chanter now supports shitlisting for your enemies.  This is very effective against tourrettes kids who have nothing better to do than pk in enchant games.  If you leave your settings at default, when a player hostiles the chanters party their account name will be added to your pkaccount.txt and their player name will be added to pkname.txt, which will be loaded at the beginning of each game.  Players who are on these lists will be squelched and not be able to use any of your bot's commands.  If you or your friend feels like pking in your chant game, you can toggle the shitlist option on and off.  Should you accidently shitlist you or a friend, you can remove them from the lists by opening the file and deleting their name there, or by simply deleting the entire files.  You'll then have to make a new game with the chanter.  If you do not have shitlist files in your redvex folder, Chanter will create them when the time comes for recording assholes.

************************************************************

