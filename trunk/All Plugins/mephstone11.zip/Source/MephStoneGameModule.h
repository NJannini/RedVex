#pragma once
#include "IModule.h"

class MephStoneGameModule :
	public IModule
{
public:
	MephStoneGameModule(IProxy* proxy);
	void __stdcall Destroy();
	void __stdcall OnRelayDataToServer(IPacket* packet, const IModule* owner);
	void __stdcall OnRelayDataToClient(IPacket* packet, const IModule* owner);
	void __stdcall Update();

private:
	enum MephStoneState
	{
		MephStoneState_Idle,
		MephStoneState_Waiting,
		MephStoneState_Ready
	};

	static const char ChatName[];

	bool OnChat(const char* text);
	void CreateMephStone();
	void Chat(const char* name, bool whisper, const char* format, ...);

	MephStoneState _state;
	IProxy* _proxy;
	int _npcId;
};
