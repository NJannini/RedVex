#include <windows.h>
#include "MephStoneGameModule.h"
#include "PluginTypes.h"
#include "IModule.h"


PluginInfo Info;

int __stdcall DllMain(HINSTANCE instance, int reason, void* reserved)
{
	return 1;
}

void __stdcall FreePlugin(PluginInfo* Info)
{
   //Cleanup Stuff
}

IModule* __stdcall CreateModule(IProxy* proxy, int Kind)
{

switch(Kind){
      case GameModule: return new MephStoneGameModule(proxy); break;
		  }

return 0;
}


extern "C"
{
	__declspec(dllexport) PluginInfo* __stdcall InitPlugin(void* Reserved)
	{
	Info.Name = "MephStone 1.1";
	Info.Author = "FooSoft";
	Info.SDKVersion = 3;
	Info.Destroy = (DestroyPlugin)&FreePlugin;
	Info.Create = &CreateModule;
	return &Info;
	}
}