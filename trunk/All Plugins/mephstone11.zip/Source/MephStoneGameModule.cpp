#include "MephStoneGameModule.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include "IProxy.h"
#include "IPacket.h"

const char MephStoneGameModule::ChatName[] = "MephStone";

MephStoneGameModule::MephStoneGameModule(IProxy* proxy) :
	_state(MephStoneState_Idle),
	_proxy(proxy),
	_npcId(-1)
{

}

	void MephStoneGameModule::Destroy()
		{
		delete this;
		}

void MephStoneGameModule::OnRelayDataToServer(IPacket* packet, const IModule* owner)
{
	const unsigned char* bytes = static_cast<const unsigned char*>(packet->GetData());
	int packetId = bytes[0];

	switch (packetId)
	{
	case 0x15:
		{
			const char* text = reinterpret_cast<const char*>(bytes + 3);
			if (OnChat(text))
			{
				packet->SetFlag(IPacket::PacketFlag_Virtual);
			}
		}
		break;

	case 0x2f:
		if (_state == MephStoneState_Waiting)
		{
			Chat(ChatName, false, "Cain has been targeted, you may now create stones");
			_npcId = *reinterpret_cast<const int*>(bytes + 5);
			_state = MephStoneState_Ready;
		}
		break;
	}
}

void MephStoneGameModule::OnRelayDataToClient(IPacket* packet, const IModule* owner)
{

}

void MephStoneGameModule::Update()
{

}

bool MephStoneGameModule::OnChat(const char* text)
{
	if (_stricmp(text, ".cain") == 0)
	{
		Chat(ChatName, false, "Target Cain (Act IV) by talking to him");
		_state = MephStoneState_Waiting;
		return true;
	}

	if (_stricmp(text, ".stone") == 0)
	{
		if (_state == MephStoneState_Ready)
		{
			Chat(ChatName, false, "Stone creation request sent");
			CreateMephStone();
		}

		else
		{
			Chat(ChatName, false, "Cain has not been targeted yet");
		}
		
		return true;
	}

	else if (_stricmp(text, ".help") == 0)
	{
		Chat(ChatName, false, ".cain");
		Chat(ChatName, false, ".stone");
		return true;
	}

	return false;
}

void MephStoneGameModule::CreateMephStone()
{
	if (_state == MephStoneState_Ready)
	{
		unsigned char buffer[9];
		int offset = 0;

		buffer[offset++] = 0x31;
		*reinterpret_cast<int*>(buffer + offset) = _npcId;
		offset += sizeof(int);
		buffer[offset++] = 0xa7;
		buffer[offset++] = 0x02;
		buffer[offset++] = 0x00;
		buffer[offset++] = 0x00;

		IPacket* packet = _proxy->CreatePacket(buffer, offset);
		_proxy->RelayDataToServer(packet, this);
		delete packet;
	}
}

void MephStoneGameModule::Chat(const char* name, bool whisper, const char* format, ...)
{
	char text[4096];

	va_list arguments;
	va_start(arguments, format);
	vsprintf_s(text, sizeof(text), format, arguments);
	va_end(arguments);	

	int length = static_cast<int>(strlen(text) + strlen(name)) + 12;
	unsigned char* buffer = new unsigned char[length];
	int offset = 0;

	buffer[offset++] = 0x26;
	buffer[offset++] = whisper ? 0x02 : 0x01;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x02;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = 0x00;
	buffer[offset++] = whisper ? 0x01 : 0x05;

	for (int i = 0; name[i] != '\0'; i++)
	{
		buffer[offset++] = name[i];
	}
	buffer[offset++] = 0x00;

	for (int i = 0; text[i] != '\0'; i++)
	{
		buffer[offset++] = text[i];
	}
	buffer[offset++] = 0x00;

	IPacket* packet = _proxy->CreatePacket(buffer, length);
	packet->SetFlag(IPacket::PacketFlag_Hidden);
	_proxy->RelayDataToClient(packet, this);
	delete packet;

	delete[] buffer;
}