RedVex MephStone Plugin
Version 1.1 by FooSoft
----------------------

A classic but oh so fun Diablo II quest system exploit. This plugin allows you to
force Cain to spawn any number of Mephisto Soulstones you want in Act IV. Use 
the "cain" command to target Cain and the "stone" command to get him to make 
soulstones for you (make sure you are nearby and in the same act).

Type the following commands in game chat when the plugin is installed:
	.cain
	.stone
	.help