Gamble.dll

A gambling script for RedVex by Turlok!

For when you're tired of clicking cancel, npc, gamble, cancel, npc, gamble...

************************************************************

Installing Gamble.dll:
Step 1: Put Gamble.dll into your Plugins folder
Step 2: Update RedVex
Step 3: High-Five! Your done!

************************************************************

in-game commands:

.gamble [item code] [number(optional)] [rate(optional::milliseconds)]-> Tells the plugin to search out and buy [number(optional)] of [itemcode] at a rate of [rate(optional::milliseconds)] per GAMBLE SEQUENCE.  Default rate is 200ms/gamble.

************************************************************

About gambling:

After giving the command to gamble, talk to a gambling npc and select the 'Gamble' option.
From here, sit back and wait for the plugin to do the work.  It may appear that nothing is happening, but 
Gamble.dll is gambling/searching for your item at a rate of 1screen/rate.  The sequence will continue until
it has bought [number(optional)] of your item from the store, or until you cancel the sequence by simply walking/running.
If you don't give it a number to look for, it will stop after buying the first item it finds.

-important-
search for the BASE_ITEM item code, that is: the code of the lowest quality level of your item - Monarchs and Dragon Shields
do not appear in the gambling window; only kite shields.  The kite shield may become a monarch after it is gambled!

WARNING:
There is no "stupid check" on rates - it is not recommended to gamble any faster than the default rate -- this can and likely will net you a long restricted connection from your IP.

************************************************************

